from pathlib import Path
import re, hashlib, sys
ROOT=Path(__file__).resolve().parent
errors=[]; checks=[]
def ck(name,cond,detail=''):
    checks.append((name,bool(cond),detail))
    if not cond: errors.append(name+((':'+detail) if detail else ''))
def txt(n): return (ROOT/n).read_text(encoding='utf-8')
def raw(n): return (ROOT/n).read_bytes()
def sha_b(b): return hashlib.sha256(b).hexdigest().upper()
def sha(n): return sha_b(raw(n))

FILES={
'DEV_PREFLIGHT':'045_produto_acabado_orquestracao_DEV_PREFLIGHT_REV5_CORRETIVA_1_GAIA.sql',
'HML_PREFLIGHT':'045_produto_acabado_orquestracao_HML_PREFLIGHT_REV5_CORRETIVA_1_GAIA.sql',
'DEV_PROPOSTA':'045_produto_acabado_orquestracao_DEV_PROPOSTA_CORRETIVA_REV5_CORRETIVA_1_GAIA.sql',
'HML_PROPOSTA':'045_produto_acabado_orquestracao_HML_PROPOSTA_CORRETIVA_REV5_CORRETIVA_1_GAIA.sql',
'DEV_VALIDACAO':'045_produto_acabado_orquestracao_DEV_VALIDACAO_REV5_CORRETIVA_1_GAIA.sql',
'HML_VALIDACAO':'045_produto_acabado_orquestracao_HML_VALIDACAO_REV5_CORRETIVA_1_GAIA.sql',
'DEV_ROLLBACK':'045_produto_acabado_orquestracao_DEV_ROLLBACK_CORRETIVO_REV5_CORRETIVA_1_GAIA.sql',
'HML_ROLLBACK':'045_produto_acabado_orquestracao_HML_ROLLBACK_CORRETIVO_REV5_CORRETIVA_1_GAIA.sql',
'MATRIZ':'MATRIZ_STATUS_SAP_PALETE_REV5_CONGELADA.txt',
}
BASELINE_HASHES={'045_produto_acabado_orquestracao_HML_PROPOSTA_CORRETIVA_REV5_GAIA.sql': '0AB5AD80B07D9DD9175F81678E80051DCC3729C2D37D8A4ACD570EC6F8A3A863', '045_produto_acabado_orquestracao_DEV_PROPOSTA_CORRETIVA_REV5_GAIA.sql': 'A5226361455132A8E9671F3E722240387459954E5DEB174DF2C094D0A87FF064', '045_produto_acabado_orquestracao_DEV_PREFLIGHT_REV5_GAIA.sql': '43F0EEEC4D7926D5F18E54DCD7084DF77F97905A3E71633DABEFCBADD0AB50A7', '045_produto_acabado_orquestracao_DEV_ROLLBACK_CORRETIVO_REV5_GAIA.sql': '4D4B78A6E3B5EF502EC79FA010A9367772BC1F44B9074A063B6671EB37F9AC35', '045_produto_acabado_orquestracao_HML_ROLLBACK_CORRETIVO_REV5_GAIA.sql': 'D6FD25326060BB8ED403F7936BA758342DE00784944798F55A75F7BA6F118F5A', '045_produto_acabado_orquestracao_HML_PREFLIGHT_REV5_GAIA.sql': '2BF1A7495487E3268410012BE2B5D10862875DFEA2D9DD2CE56BE4BAE1654024', '045_produto_acabado_orquestracao_DEV_VALIDACAO_REV5_GAIA.sql': 'FF72A1445634C34BBB9FDED3D9A8D443705DBFDBC3C93866618271BE8FB9F4C6', '045_produto_acabado_orquestracao_HML_VALIDACAO_REV5_GAIA.sql': '16289A6A8C5524E9EA2A70B2FF6CC12EDCF496F3327DD18AD40CFBC1A2F24C58'}
BASELINE_MATRIX='45FD21B93D13FA65F7A6CEBF4B82BBBCC148299D5DFEA581E738E0FDF2E00157'
FUNC_HASHES={'fn_pa_045_palete_inserir_evento': '1F403523D6344E61C0F781F0BC08B887A9D818A1BE7C2159E48796EBE118D2BB', 'fn_pa_045_palete_claim_envio': '4F29892958A574BFE1551E8BDA4DF2879A86E2F8A7799DA31799C09E3AF5E900', 'fn_pa_045_palete_reassumir_claim': 'DCC7C3CCEDC123BAD86631D2604C2C7725CB80E5B53CB9E603D32D47C0C2E415', 'fn_pa_045_palete_adquirir_recovery': 'BA2FCC8D5E2B85FA55AD0999F23E148E745ACBA152F4A49AD35AD8E5CE9BBF77', 'fn_pa_045_palete_registrar_erro': '6A7192C10EF9BFCCD75AF39496BA5BA2A2D4F8E36E955AB6310DB89CA6F5A1D4', 'fn_pa_045_palete_registrar_timeout': 'AF875EC28814B29D3166FF1FF7B1052051AFD89F5446103006019539E6B65415', 'fn_pa_045_palete_registrar_reconciliacao': '5A778842098E91A45C4F6ABAF8AFF4CB0C830529731511E47B8AA837919B41B1', 'fn_pa_045_palete_liberar_reprocessamento': '44FCDD2E2AD8CFA4817735B57A577C8FD901569801B57460EF7B4C1345F0A77B'}
TARGETS=['fn_pa_045_palete_inserir_evento', 'fn_pa_045_palete_claim_envio', 'fn_pa_045_palete_reassumir_claim', 'fn_pa_045_palete_adquirir_recovery', 'fn_pa_045_palete_registrar_erro', 'fn_pa_045_palete_registrar_timeout', 'fn_pa_045_palete_registrar_reconciliacao', 'fn_pa_045_palete_liberar_reprocessamento']

for k,f in FILES.items(): ck('ARQUIVO_EXISTE::'+k,(ROOT/f).is_file(),f)
T={k:txt(f) for k,f in FILES.items() if f.endswith('.sql')}
for k,s in T.items():
    ck('DOLLAR_GAIA_BALANCEADO::'+k,s.count('$gaia$')%2==0,str(s.count('$gaia$')))
    ck('DOLLAR_FN_BALANCEADO::'+k,s.count('$fn$')%2==0,str(s.count('$fn$')))
    ck('SEM_EXECUCAO_EXTERNA::'+k,'curl ' not in s.lower() and 'invoke-webrequest' not in s.lower())

# Parse the physical-total checks. These queries count ALL pg_proc fn_pa_045_% rows, not runtime grants.
def physical_total_expected(s,schema):
    pat=(r"SELECT count\(\*\) FROM pg_proc p JOIN pg_namespace n ON n\.oid=p\.pronamespace "
         r"WHERE n\.nspname='"+re.escape(schema)+r"' AND p\.proname LIKE 'fn_pa_045_%'\)<>(\d+)")
    vals=[int(x) for x in re.findall(pat,s)]
    return vals

pt_dev_pre=physical_total_expected(T['DEV_PREFLIGHT'],'desenvolvimento')
pt_hml_pre=physical_total_expected(T['HML_PREFLIGHT'],'homologacao')
pt_dev_prop=physical_total_expected(T['DEV_PROPOSTA'],'desenvolvimento')
pt_hml_prop=physical_total_expected(T['HML_PROPOSTA'],'homologacao')
ck('PREFLIGHT_TOTAL_DEV_29',pt_dev_pre==[29],repr(pt_dev_pre))
ck('PREFLIGHT_TOTAL_HML_29',pt_hml_pre==[29],repr(pt_hml_pre))
ck('PROPOSTA_POSCHECK_TOTAL_DEV_29',pt_dev_prop==[29],repr(pt_dev_prop))
ck('PROPOSTA_POSCHECK_TOTAL_HML_29',pt_hml_prop==[29],repr(pt_hml_prop))

# Runtime execute remains 21 in validations. Explicitly fail if anyone globally changes it to 29.
def runtime_exec_expected(s):
    vals=[int(x) for x in re.findall(r'v_exec<>(\d+)',s)]
    return vals
rv_dev=runtime_exec_expected(T['DEV_VALIDACAO'])
rv_hml=runtime_exec_expected(T['HML_VALIDACAO'])
ck('VALIDACAO_RUNTIME_EXECUTE_DEV_21',rv_dev==[21],repr(rv_dev))
ck('VALIDACAO_RUNTIME_EXECUTE_HML_21',rv_hml==[21],repr(rv_hml))
ck('VALIDACAO_DEV_SEM_v_exec_29','v_exec<>29' not in T['DEV_VALIDACAO'])
ck('VALIDACAO_HML_SEM_v_exec_29','v_exec<>29' not in T['HML_VALIDACAO'])

# Exact delta restriction: restoring only the authorized 29->21 token must reproduce the prior REV5 preflight/proposal byte-for-byte.
old_names={
'DEV_PREFLIGHT':'045_produto_acabado_orquestracao_DEV_PREFLIGHT_REV5_GAIA.sql',
'HML_PREFLIGHT':'045_produto_acabado_orquestracao_HML_PREFLIGHT_REV5_GAIA.sql',
'DEV_PROPOSTA':'045_produto_acabado_orquestracao_DEV_PROPOSTA_CORRETIVA_REV5_GAIA.sql',
'HML_PROPOSTA':'045_produto_acabado_orquestracao_HML_PROPOSTA_CORRETIVA_REV5_GAIA.sql',
'DEV_VALIDACAO':'045_produto_acabado_orquestracao_DEV_VALIDACAO_REV5_GAIA.sql',
'HML_VALIDACAO':'045_produto_acabado_orquestracao_HML_VALIDACAO_REV5_GAIA.sql',
'DEV_ROLLBACK':'045_produto_acabado_orquestracao_DEV_ROLLBACK_CORRETIVO_REV5_GAIA.sql',
'HML_ROLLBACK':'045_produto_acabado_orquestracao_HML_ROLLBACK_CORRETIVO_REV5_GAIA.sql',
}
for k in ('DEV_PREFLIGHT','HML_PREFLIGHT','DEV_PROPOSTA','HML_PROPOSTA'):
    s=T[k]
    target="AND p.proname LIKE 'fn_pa_045_%')<>29 THEN"
    ck('DELTA_UM_TOTAL_29::'+k,s.count(target)==1,str(s.count(target)))
    restored=s.replace(target,"AND p.proname LIKE 'fn_pa_045_%')<>21 THEN",1).encode('utf-8')
    ck('DELTA_RESTAURA_REV5_EXATO::'+k,sha_b(restored)==BASELINE_HASHES[old_names[k]],sha_b(restored))

# Validation and rollback must be byte-for-byte identical to approved REV5.
for k in ('DEV_VALIDACAO','HML_VALIDACAO','DEV_ROLLBACK','HML_ROLLBACK'):
    ck('BYTE_A_BYTE_REV5::'+k,sha(FILES[k])==BASELINE_HASHES[old_names[k]],sha(FILES[k]))

# Frozen status_sap matrix remains byte-for-byte identical.
ck('MATRIZ_STATUS_SAP_CONGELADA_BYTE_A_BYTE',sha(FILES['MATRIZ'])==BASELINE_MATRIX,sha(FILES['MATRIZ']))

# Eight approved business-function bodies cannot change. Also prove DEV/HML symmetry.
def extract_func(s,name):
    m=re.search(r'(?ms)^CREATE OR REPLACE FUNCTION\s+(?:desenvolvimento|homologacao)\.'+re.escape(name)+r'\(.*?^\$fn\$;',s)
    return m.group(0) if m else None
def norm_func(s):
    if s is None: return None
    return s.replace('desenvolvimento','SCHEMA').replace('homologacao','SCHEMA')
for n in TARGETS:
    d=extract_func(T['DEV_PROPOSTA'],n); h=extract_func(T['HML_PROPOSTA'],n)
    ck('FUNCAO_REV5_PRESENTE_DEV::'+n,d is not None)
    ck('FUNCAO_REV5_PRESENTE_HML::'+n,h is not None)
    if d is not None:
        ck('FUNCAO_REV5_INALTERADA_DEV::'+n,sha_b(norm_func(d).encode('utf-8'))==FUNC_HASHES[n],sha_b(norm_func(d).encode('utf-8')))
    if h is not None:
        ck('FUNCAO_REV5_INALTERADA_HML::'+n,sha_b(norm_func(h).encode('utf-8'))==FUNC_HASHES[n],sha_b(norm_func(h).encode('utf-8')))
    ck('FUNCAO_REV5_SIMETRICA_DEV_HML::'+n,d is not None and h is not None and norm_func(d)==norm_func(h))

# Preserve key status_sap contract; no redesign in Corrective 1.
for env in ('DEV_PROPOSTA','HML_PROPOSTA'):
    s=T[env]
    ck(env+'_STATUS_SAP_VARCHAR10_GUARD','PA045_STATUS_SAP_LENGTH_INVALIDO' in s)
    ck(env+'_STATUS_SAP_LOCAL_NULL','PA045_STATUS_SAP_ORIGEM_EXTERNA_INVALIDA' in s)
    ck(env+'_STATUS_SAP_ALLOWED_ONLY',"v_status_sap NOT IN ('CONFIRMADO','ERRO')" in s)
    ck(env+'_POST_FORMACAO_REQUIRED',"upper(btrim(COALESCE(p_tipo_operacao,'')))<>'POST_FORMACAO'" in s)

# Transactional form unchanged/expected.
for env in ('DEV_PREFLIGHT','HML_PREFLIGHT'):
    s=T[env]
    ck(env+'_BEGIN_1',len(re.findall(r'(?im)^\s*BEGIN\s*;\s*$',s))==1)
    ck(env+'_READ_ONLY','SET TRANSACTION READ ONLY;' in s)
    ck(env+'_ROLLBACK_1',len(re.findall(r'(?im)^\s*ROLLBACK\s*;\s*$',s))==1)
    ck(env+'_COMMIT_0',len(re.findall(r'(?im)^\s*COMMIT\s*;\s*$',s))==0)
for env in ('DEV_PROPOSTA','HML_PROPOSTA'):
    s=T[env]
    ck(env+'_BEGIN_1',len(re.findall(r'(?im)^\s*BEGIN\s*;\s*$',s))==1)
    ck(env+'_COMMIT_1',len(re.findall(r'(?im)^\s*COMMIT\s*;\s*$',s))==1)
    ck(env+'_ROLLBACK_0',len(re.findall(r'(?im)^\s*ROLLBACK\s*;\s*$',s))==0)
    ck(env+'_CREATE_OR_REPLACE_8',len(re.findall(r'(?im)^CREATE OR REPLACE FUNCTION\s+',s))==8)
for env in ('DEV_VALIDACAO','HML_VALIDACAO'):
    s=T[env]
    ck(env+'_BEGIN_1',len(re.findall(r'(?im)^\s*BEGIN\s*;\s*$',s))==1)
    ck(env+'_ROLLBACK_1',len(re.findall(r'(?im)^\s*ROLLBACK\s*;\s*$',s))==1)
    ck(env+'_COMMIT_0',len(re.findall(r'(?im)^\s*COMMIT\s*;\s*$',s))==0)

# Clear anti-confusion assertions.
TOTAL_DEV=29 if pt_dev_pre==[29] and pt_dev_prop==[29] else None
TOTAL_HML=29 if pt_hml_pre==[29] and pt_hml_prop==[29] else None
RUNTIME_EXECUTE_DEV=21 if rv_dev==[21] else None
RUNTIME_EXECUTE_HML=21 if rv_hml==[21] else None
ck('TOTAL_DEV=29',TOTAL_DEV==29)
ck('TOTAL_HML=29',TOTAL_HML==29)
ck('RUNTIME_EXECUTE_DEV=21',RUNTIME_EXECUTE_DEV==21)
ck('RUNTIME_EXECUTE_HML=21',RUNTIME_EXECUTE_HML==21)
ck('TOTAL_DIFERENTE_RUNTIME_DEV',TOTAL_DEV!=RUNTIME_EXECUTE_DEV)
ck('TOTAL_DIFERENTE_RUNTIME_HML',TOTAL_HML!=RUNTIME_EXECUTE_HML)

print('CHECKER=CHECK_ESTATICO_045_REV5_CORRETIVA_1_CONTAGEM_FUNCOES')
print('MODO=FILESYSTEM_ONLY')
print('BANCO_ACESSADO=NAO')
print('SQL_EXECUTADO=NAO')
print('SAP_ACESSADO=NAO')
print('CPI_ACESSADO=NAO')
for name,ok,detail in checks:
    print(f"CHECK|{name}|{'OK' if ok else 'ERRO'}"+(f'|{detail}' if detail else ''))
print('FUNCOES_045_TOTAL=29')
print('FUNCOES_045_RUNTIME_EXECUTE=21')
print('TOTAL_DEV='+('29' if TOTAL_DEV==29 else 'BLOQUEADO'))
print('TOTAL_HML='+('29' if TOTAL_HML==29 else 'BLOQUEADO'))
print('RUNTIME_EXECUTE_DEV='+('21' if RUNTIME_EXECUTE_DEV==21 else 'BLOQUEADO'))
print('RUNTIME_EXECUTE_HML='+('21' if RUNTIME_EXECUTE_HML==21 else 'BLOQUEADO'))
print('PREFLIGHT_TOTAL_DEV='+('29' if pt_dev_pre==[29] else 'BLOQUEADO'))
print('PREFLIGHT_TOTAL_HML='+('29' if pt_hml_pre==[29] else 'BLOQUEADO'))
print('PROPOSTA_POSCHECK_TOTAL_DEV='+('29' if pt_dev_prop==[29] else 'BLOQUEADO'))
print('PROPOSTA_POSCHECK_TOTAL_HML='+('29' if pt_hml_prop==[29] else 'BLOQUEADO'))
print('VALIDACAO_RUNTIME_EXECUTE_DEV='+('21' if rv_dev==[21] else 'BLOQUEADO'))
print('VALIDACAO_RUNTIME_EXECUTE_HML='+('21' if rv_hml==[21] else 'BLOQUEADO'))
print('FUNCOES_NEGOCIO_ALTERADAS='+('NAO' if not any('FUNCAO_REV5_INALTERADA' in e or 'FUNCAO_REV5_SIMETRICA' in e for e in errors) else 'SIM_OU_BLOQUEADO'))
print('VALIDACOES_ALTERADAS='+('NAO' if not any('BYTE_A_BYTE_REV5::DEV_VALIDACAO' in e or 'BYTE_A_BYTE_REV5::HML_VALIDACAO' in e for e in errors) else 'SIM'))
print('ROLLBACKS_ALTERADOS='+('NAO' if not any('BYTE_A_BYTE_REV5::DEV_ROLLBACK' in e or 'BYTE_A_BYTE_REV5::HML_ROLLBACK' in e for e in errors) else 'SIM'))
print('DELTA_PREFLIGHT_PROPOSTA_RESTRITO='+('SIM' if not any('DELTA_' in e for e in errors) else 'NAO'))
print('CHECKS_TOTAL='+str(len(checks)))
print('ERROS='+str(len(errors)))
print('CHECK_ESTATICO='+('APROVADO' if not errors else 'BLOQUEADO'))
print('CLASSIFICACAO='+('PACOTE_045_REV5_CORRETIVA_1_APROVADO_ESTATICAMENTE' if not errors else 'PACOTE_045_REV5_CORRETIVA_1_BLOQUEADO'))
if errors:
    print('ERROS_DETALHE='+';'.join(errors))
    sys.exit(1)
