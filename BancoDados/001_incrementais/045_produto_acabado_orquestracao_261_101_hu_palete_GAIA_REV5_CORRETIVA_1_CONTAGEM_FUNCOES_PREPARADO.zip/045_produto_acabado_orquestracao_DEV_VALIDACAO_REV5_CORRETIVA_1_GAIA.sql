\set ON_ERROR_STOP on
\pset pager off
\pset tuples_only off
\pset format aligned
\pset null '<NULL>'

-- ============================================================================
-- FugaPET - Incremental 045 - DEV - VALIDACAO GAIA — REV5 CORRETIVA RUNTIME STATUS PALETE — BASE REV4 + FIXTURE CORRETIVA 1
-- VALIDACAO TRANSACIONAL LOCAL. NAO CHAMA SAP/CPI.
-- PREPARADO, NAO EXECUTADO. Quando futuramente autorizada termina com ROLLBACK.
-- AVISO: triggers de auditoria existentes e funcoes de palete usam sequences;
-- sequences PostgreSQL sao nao transacionais e podem avancar mesmo com ROLLBACK.
-- ============================================================================
\echo 'CLASSIFICACAO_DOCUMENTAL=VALIDACAO_045_REV5_DEV_PREPARADA_NAO_EXECUTADA'

BEGIN;
SET LOCAL search_path TO desenvolvimento, pg_catalog;
SET LOCAL statement_timeout='15min';
SET LOCAL lock_timeout='10s';

DO $gaia$
BEGIN
 IF current_database()<>'fuga_jales_local_desenvolvimento' OR current_user<>'postgres' OR current_schema()<>'desenvolvimento' THEN
   RAISE EXCEPTION 'VALIDACAO_045_BLOQUEADA_AMBIENTE';
 END IF;
 IF to_regclass('desenvolvimento.hu_caixa_etapa_sap') IS NULL
    OR to_regprocedure('desenvolvimento.fn_pa_045_claim_etapa(bigint,character varying,bigint,text)') IS NULL
    OR to_regprocedure('desenvolvimento.fn_pa_045_guard_hu_pos_101()') IS NULL
    OR to_regprocedure('desenvolvimento.fn_pa_045_reassumir_claim_etapa(bigint,character varying,bigint,text)') IS NULL
    OR to_regprocedure('desenvolvimento.fn_pa_045_palete_reassumir_claim(bigint,bigint,text)') IS NULL
    OR to_regprocedure('desenvolvimento.fn_pa_045_adquirir_recovery_etapa(bigint,character varying,bigint,text)') IS NULL
    OR to_regprocedure('desenvolvimento.fn_pa_045_palete_adquirir_recovery(bigint,bigint,text)') IS NULL
    OR to_regclass('desenvolvimento.vw_pa_045_etapa_estado_runtime') IS NULL
    OR to_regclass('desenvolvimento.vw_pa_045_etapa_tentativa_runtime') IS NULL
    OR to_regclass('desenvolvimento.vw_pa_045_etapa_evento_runtime') IS NULL
    OR to_regclass('desenvolvimento.vw_pa_045_palete_estado_runtime') IS NULL
    OR to_regclass('desenvolvimento.vw_pa_045_palete_integracao_runtime') IS NULL THEN
   RAISE EXCEPTION 'VALIDACAO_045_BLOQUEADA_PACOTE_NAO_APLICADO';
 END IF;
END
$gaia$;

-- REV5 deve estar aplicada; status_sap continua varchar(10) e guard semantico existe.
DO $gaia$
DECLARE d text;
BEGIN
 IF (SELECT count(*) FROM information_schema.columns WHERE table_schema='desenvolvimento' AND table_name IN ('hu_palete','hu_palete_integracao_sap') AND column_name='status_sap' AND data_type='character varying' AND character_maximum_length=10)<>2 THEN
   RAISE EXCEPTION 'VALIDACAO_REV5_STATUS_SAP_TIPO_DIVERGENTE'; END IF;
 d:=pg_get_functiondef('desenvolvimento.fn_pa_045_palete_inserir_evento(bigint,text,character varying,jsonb,jsonb,integer,character varying,character varying,text,integer,boolean,bigint,uuid,character varying,uuid,character varying,timestamp with time zone,timestamp with time zone,text)'::regprocedure);
 IF position('PA045_STATUS_SAP_ORIGEM_EXTERNA_INVALIDA' in d)=0 OR position('PA045_STATUS_SAP_LENGTH_INVALIDO' in d)=0 THEN
   RAISE EXCEPTION 'VALIDACAO_REV5_CORRETIVA_RUNTIME_NAO_APLICADA'; END IF;
 RAISE NOTICE 'REV5_RUNTIME_STATUS_PALETE_INSTALADA=SIM';
 RAISE NOTICE 'STATUS_SAP_VARCHAR_10_PRESERVADO=SIM';
END
$gaia$;

CREATE TEMP TABLE tmp_045_contexto AS
SELECT codigo_usuario,
       'GAIA045-'||pg_backend_pid()||'-A' AS terminal_a,
       'GAIA045-'||pg_backend_pid()||'-B' AS terminal_b,
       'GAIA045-'||pg_backend_pid()||'-C' AS terminal_c,
       'GAIA045-'||pg_backend_pid()||'-D' AS terminal_d,
       'GAIA045-'||pg_backend_pid()||'-E' AS terminal_e
FROM desenvolvimento.usuario
WHERE situacao_usuario AND NOT bloqueado_usuario
ORDER BY codigo_usuario
LIMIT 1;

DO $gaia$ BEGIN
 IF (SELECT count(*) FROM tmp_045_contexto)<>1 THEN RAISE EXCEPTION 'VALIDACAO_045_SEM_USUARIO_ATIVO'; END IF;
END $gaia$;


-- ==========================================================================
-- REV4 VALIDACAO CORRETIVA 1 - PRECHECK FAIL-CLOSED DE RESIDUOS
-- Nao limpa, nao deleta e nao corrige. Qualquer residuo bloqueia a validacao.
-- IDs reservados de caixa: -450001..-450005. IDs reservados de palete: -450001,-450002.
-- Tambem protege correlations fixas e os terminais A..E do fixture contra colisao ativa.
-- ==========================================================================
DO $gaia$
DECLARE
    v_caixas bigint;
    v_caixa_filhos bigint;
    v_etapas bigint;
    v_tentativas bigint;
    v_eventos bigint;
    v_paletes bigint;
    v_palete_filhos bigint;
    v_correlations bigint;
    v_terminais bigint;
BEGIN
    SELECT count(*) INTO v_caixas
      FROM desenvolvimento.hu_caixa
     WHERE codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005);

    SELECT
      (SELECT count(*) FROM desenvolvimento.hu_caixa_pesagem WHERE codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005))
      + (SELECT count(*) FROM desenvolvimento.hu_caixa_integracao_sap WHERE codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005))
      + (SELECT count(*) FROM desenvolvimento.hu_caixa_etiqueta WHERE codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005))
      + (SELECT count(*) FROM desenvolvimento.hu_palete_item WHERE codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005))
      INTO v_caixa_filhos;

    SELECT count(*) INTO v_etapas
      FROM desenvolvimento.hu_caixa_etapa_sap
     WHERE codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005);

    SELECT count(*) INTO v_tentativas
      FROM desenvolvimento.hu_caixa_etapa_sap_tentativa t
      JOIN desenvolvimento.hu_caixa_etapa_sap e
        ON e.codigo_hu_caixa_etapa_sap=t.codigo_hu_caixa_etapa_sap
     WHERE e.codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005);

    SELECT count(*) INTO v_eventos
      FROM desenvolvimento.hu_caixa_etapa_sap_evento ev
      JOIN desenvolvimento.hu_caixa_etapa_sap_tentativa t
        ON t.codigo_hu_caixa_etapa_sap_tentativa=ev.codigo_hu_caixa_etapa_sap_tentativa
      JOIN desenvolvimento.hu_caixa_etapa_sap e
        ON e.codigo_hu_caixa_etapa_sap=t.codigo_hu_caixa_etapa_sap
     WHERE e.codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005);

    SELECT count(*) INTO v_paletes
      FROM desenvolvimento.hu_palete
     WHERE codigo_hu_palete IN (-450001,-450002);

    SELECT
      (SELECT count(*) FROM desenvolvimento.hu_palete_item WHERE codigo_hu_palete IN (-450001,-450002))
      + (SELECT count(*) FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete IN (-450001,-450002))
      + (SELECT count(*) FROM desenvolvimento.hu_palete_etiqueta WHERE codigo_hu_palete IN (-450001,-450002))
      INTO v_palete_filhos;

    SELECT
      (SELECT count(*) FROM desenvolvimento.hu_caixa
        WHERE correlation_id IN (
          '04500000-0000-0000-0000-000000000001'::uuid,
          '04500000-0000-0000-0000-000000000002'::uuid,
          '04500000-0000-0000-0000-000000000003'::uuid,
          '04500000-0000-0000-0000-000000000004'::uuid,
          '04500000-0000-0000-0000-000000000005'::uuid))
      + (SELECT count(*) FROM desenvolvimento.hu_palete
        WHERE correlation_id IN (
          '04510000-0000-0000-0000-000000000001'::uuid,
          '04510000-0000-0000-0000-000000000002'::uuid))
      INTO v_correlations;

    SELECT count(*) INTO v_terminais
      FROM desenvolvimento.hu_caixa hc
      CROSS JOIN tmp_045_contexto c
     WHERE hc.situacao_hu_caixa=true
       AND upper(btrim(hc.terminal::text)) IN (
         upper(btrim(c.terminal_a)), upper(btrim(c.terminal_b)), upper(btrim(c.terminal_c)),
         upper(btrim(c.terminal_d)), upper(btrim(c.terminal_e)));

    IF v_caixas<>0 OR v_caixa_filhos<>0 OR v_etapas<>0 OR v_tentativas<>0 OR v_eventos<>0
       OR v_paletes<>0 OR v_palete_filhos<>0 OR v_correlations<>0 OR v_terminais<>0 THEN
       RAISE EXCEPTION
         'VALIDACAO_045_BLOQUEADA_RESIDUOS caixas=% caixa_filhos=% etapas=% tentativas=% eventos=% paletes=% palete_filhos=% correlations=% terminais_ativos=%',
         v_caixas,v_caixa_filhos,v_etapas,v_tentativas,v_eventos,v_paletes,v_palete_filhos,v_correlations,v_terminais;
    END IF;

    RAISE NOTICE 'PRECHECK_RESIDUOS_IDS_RESERVADOS=ZERO';
    RAISE NOTICE 'PRECHECK_CORRELATIONS_RESERVADAS=ZERO';
    RAISE NOTICE 'PRECHECK_TERMINAIS_FIXTURE=ZERO';
END
$gaia$;
-- FIM_REV4_VALIDACAO_CORRETIVA_1_PRECHECK


-- ==========================================================================
-- SNAPSHOT DE SEQUENCES POTENCIALMENTE AVANCADAS PELA VALIDACAO
-- Captura catalogo real; ROLLBACK de dados nao reverte nextval.
-- ==========================================================================
CREATE TEMP TABLE tmp_045_sequences(
    sequence_name text PRIMARY KEY,
    tabela_origem text,
    valor_antes bigint,
    is_called_antes boolean,
    valor_depois bigint,
    is_called_depois boolean,
    delta bigint,
    classificacao text
) ON COMMIT DROP;

DO $gaia$
DECLARE r record; v_last bigint; v_called boolean;
BEGIN
 FOR r IN
   SELECT DISTINCT format('%I.%I',ns.nspname,s.relname) AS seq_name,
          COALESCE(t.relname,'CATALOGO_NOME') AS tabela_origem
   FROM pg_class s
   JOIN pg_namespace ns ON ns.oid=s.relnamespace
   LEFT JOIN pg_depend d ON d.objid=s.oid AND d.classid='pg_class'::regclass AND d.deptype IN ('a','i')
   LEFT JOIN pg_class t ON t.oid=d.refobjid AND t.relkind IN ('r','p')
   LEFT JOIN pg_namespace tn ON tn.oid=t.relnamespace
   WHERE s.relkind='S' AND ns.nspname='desenvolvimento'
     AND (
       (tn.nspname='desenvolvimento' AND (t.relname LIKE 'hu_caixa%' OR t.relname LIKE 'hu_palete%'
            OR t.relname IN ('log_alteracao_cadastral','log_integracao_sap')))
       OR s.relname LIKE 'hu_caixa%' OR s.relname LIKE 'hu_palete%'
       OR s.relname LIKE 'log_alteracao_cadastral%' OR s.relname LIKE 'log_integracao_sap%'
     )
   ORDER BY 1
 LOOP
   EXECUTE format('SELECT last_value,is_called FROM %s',r.seq_name) INTO v_last,v_called;
   INSERT INTO tmp_045_sequences(sequence_name,tabela_origem,valor_antes,is_called_antes)
   VALUES(r.seq_name,r.tabela_origem,v_last,v_called)
   ON CONFLICT (sequence_name) DO NOTHING;
 END LOOP;
 IF NOT EXISTS(SELECT 1 FROM tmp_045_sequences) THEN
   RAISE EXCEPTION 'VALIDACAO_045_SEQUENCES_ALVO_NAO_LOCALIZADAS_NO_CATALOGO';
 END IF;
END
$gaia$;

\echo '=== SEQUENCES_ANTES ==='
SELECT sequence_name AS sequence,tabela_origem,valor_antes,is_called_antes
FROM tmp_045_sequences ORDER BY sequence_name;

-- Cinco caixas locais de teste com IDs negativos. O ROLLBACK remove todos os dados.
INSERT INTO desenvolvimento.hu_caixa(
 codigo_hu_caixa,numero_ordem_producao,item_ordem_producao,correlation_id,
 material,lote,centro,deposito,material_embalagem,origem_material_embalagem,
 peso_bruto,peso_liquido,peso_tara,unidade_peso,quantidade,unidade_quantidade,
 origem_pesagem,codigo_usuario,terminal)
SELECT -450001,'VAL045A','0010','04500000-0000-0000-0000-000000000001'::uuid,
       '4000108','67008561F','3007','PP02','3000009','NORMA_EMBALAGEM_SAP',
       2.500,2.000,0.500,'KG',60.000,'UN','MANUAL',codigo_usuario,terminal_a FROM tmp_045_contexto
UNION ALL
SELECT -450002,'VAL045LEG','0010','04500000-0000-0000-0000-000000000002'::uuid,
       '4000108','67008562F','3007','PP02','3000009','NORMA_EMBALAGEM_SAP',
       2.500,2.000,0.500,'KG',60.000,'UN','MANUAL',codigo_usuario,terminal_b FROM tmp_045_contexto
UNION ALL
SELECT -450003,'VAL045TMO','0010','04500000-0000-0000-0000-000000000003'::uuid,
       '4000108','67008563F','3007','PP02','3000009','NORMA_EMBALAGEM_SAP',
       2.500,2.000,0.500,'KG',60.000,'UN','MANUAL',codigo_usuario,terminal_c FROM tmp_045_contexto
UNION ALL
SELECT -450004,'VAL045HIS','0010','04500000-0000-0000-0000-000000000004'::uuid,
       '4000108','67008564F','3007','PP02','3000009','NORMA_EMBALAGEM_SAP',
       2.500,2.000,0.500,'KG',60.000,'UN','MANUAL',codigo_usuario,terminal_d FROM tmp_045_contexto
UNION ALL
SELECT -450005,'VAL045OWN','0010','04500000-0000-0000-0000-000000000005'::uuid,
       '4000108','67008565F','3007','PP02','3000009','NORMA_EMBALAGEM_SAP',
       2.500,2.000,0.500,'KG',60.000,'UN','MANUAL',codigo_usuario,terminal_e FROM tmp_045_contexto
;

-- ============================================================================
-- A. 261 -> 101 e guard da HU
-- ============================================================================
DO $gaia$
DECLARE v_user bigint; v_term text; v_ok boolean;
BEGIN
 SELECT codigo_usuario,terminal_a INTO v_user,v_term FROM tmp_045_contexto;
 v_ok:=desenvolvimento.fn_pa_045_iniciar_fluxo(-450001,v_user,v_term,'NOVA_ORQUESTRACAO','VALIDACAO_045');
 IF NOT v_ok THEN RAISE EXCEPTION 'VALIDACAO_045_FALHOU_INICIAR_FLUXO'; END IF;
 IF (SELECT count(*) FROM desenvolvimento.hu_caixa_etapa_sap WHERE codigo_hu_caixa=-450001)<>2 THEN
   RAISE EXCEPTION 'VALIDACAO_045_FALHOU_DUAS_ETAPAS'; END IF;
 BEGIN
   PERFORM desenvolvimento.fn_pa_045_preparar_etapa(-450001,'101','{}'::jsonb,v_user,v_term);
   RAISE EXCEPTION 'TESTE_101_SEM_261_NAO_BLOQUEOU';
 EXCEPTION WHEN raise_exception THEN
   IF SQLERRM NOT LIKE '%PA045_101_EXIGE_261_CONFIRMADO%' THEN RAISE; END IF;
 END;
 BEGIN
   UPDATE desenvolvimento.hu_caixa_etapa_sap SET status_etapa='PRONTA_PARA_ENVIO'
    WHERE codigo_hu_caixa=-450001 AND etapa_sap='101';
   RAISE EXCEPTION 'TESTE_GUARD_FISICO_101_SEM_261_NAO_BLOQUEOU';
 EXCEPTION WHEN raise_exception THEN
   IF SQLERRM NOT LIKE '%PA045_101_EXIGE_261_CONFIRMADO_FISICO%' THEN RAISE; END IF;
 END;
 RAISE NOTICE '261_NAO_CONFIRMADO_BLOQUEIA_101=SIM';
 RAISE NOTICE 'PROTECAO_FISICA_261_ANTES_101=SIM';
END
$gaia$;

DO $gaia$
DECLARE v_user bigint; v_term text; v1 integer; v2 integer; v_claim uuid; v_tent integer; v_ok boolean;
BEGIN
 SELECT codigo_usuario,terminal_a INTO v_user,v_term FROM tmp_045_contexto;
 IF NOT desenvolvimento.fn_pa_045_preparar_etapa(-450001,'261','{"GoodsMovementType":"261"}'::jsonb,v_user,v_term) THEN
   RAISE EXCEPTION 'VALIDACAO_045_PREPARAR_261_FALHOU'; END IF;
 SELECT count(*) INTO v1 FROM desenvolvimento.fn_pa_045_claim_etapa(-450001,'261',v_user,v_term);
 SELECT count(*) INTO v2 FROM desenvolvimento.fn_pa_045_claim_etapa(-450001,'261',v_user,v_term);
 IF v1<>1 OR v2<>0 THEN RAISE EXCEPTION 'VALIDACAO_045_CLAIM_261_NAO_ATOMICO primeiro=% segundo=%',v1,v2; END IF;
 SELECT claim_token,numero_tentativa INTO v_claim,v_tent FROM desenvolvimento.hu_caixa_etapa_sap WHERE codigo_hu_caixa=-450001 AND etapa_sap='261';
 v_ok:=desenvolvimento.fn_pa_045_registrar_sucesso(-450001,'261',v_tent,v_claim,201,'5000045261','2026',
        '{"MaterialDocument":"5000045261","MaterialDocumentYear":"2026"}'::jsonb,
        '/MaterialDocument?sap-client=110',v_user,v_term);
 IF NOT v_ok THEN RAISE EXCEPTION 'VALIDACAO_045_SUCESSO_261_FALHOU'; END IF;
 IF NOT desenvolvimento.fn_pa_045_preparar_etapa(-450001,'101','{"GoodsMovementType":"101"}'::jsonb,v_user,v_term) THEN
   RAISE EXCEPTION 'VALIDACAO_045_261_NAO_LIBEROU_101'; END IF;
 RAISE NOTICE 'CLAIM_ATOMICO_261=SIM';
 RAISE NOTICE '261_CONFIRMADO_LIBERA_101=SIM';
 RAISE NOTICE 'CONTRATO_SAP_261_REUTILIZADO_SEM_NOVO_POST=SIM';
END
$gaia$;

DO $gaia$
DECLARE v_user bigint; v_term text; v_claim uuid; v_tent integer; v1 integer; v2 integer; v_ok boolean;
BEGIN
 SELECT codigo_usuario,terminal_a INTO v_user,v_term FROM tmp_045_contexto;
 SELECT count(*) INTO v1 FROM desenvolvimento.fn_pa_045_claim_etapa(-450001,'101',v_user,v_term);
 SELECT count(*) INTO v2 FROM desenvolvimento.fn_pa_045_claim_etapa(-450001,'101',v_user,v_term);
 IF v1<>1 OR v2<>0 THEN RAISE EXCEPTION 'VALIDACAO_045_CLAIM_101_NAO_ATOMICO'; END IF;
 IF NOT desenvolvimento.fn_hu_caixa_finalizar_local(-450001,v_user,v_term) THEN RAISE EXCEPTION 'VALIDACAO_045_FINALIZAR_CAIXA_FALHOU'; END IF;
 BEGIN
   PERFORM desenvolvimento.fn_hu_caixa_salvar_preview(-450001,'{"Material":"4000108"}'::jsonb,'/HandlingUnit?sap-client=110');
   RAISE EXCEPTION 'TESTE_HU_SEM_101_NAO_BLOQUEOU';
 EXCEPTION WHEN raise_exception THEN
   IF SQLERRM NOT LIKE '%PA045_HU_EXIGE_101_CONFIRMADO%' THEN RAISE; END IF;
 END;
 SELECT claim_token,numero_tentativa INTO v_claim,v_tent FROM desenvolvimento.hu_caixa_etapa_sap WHERE codigo_hu_caixa=-450001 AND etapa_sap='101';
 v_ok:=desenvolvimento.fn_pa_045_registrar_sucesso(-450001,'101',v_tent,v_claim,201,'5000045101','2026',
        '{"MaterialDocument":"5000045101","MaterialDocumentYear":"2026"}'::jsonb,
        '/MaterialDocument?sap-client=110',v_user,v_term);
 IF NOT v_ok THEN RAISE EXCEPTION 'VALIDACAO_045_SUCESSO_101_FALHOU'; END IF;
 IF NOT desenvolvimento.fn_hu_caixa_salvar_preview(-450001,'{"Material":"4000108"}'::jsonb,'/HandlingUnit?sap-client=110') THEN
   RAISE EXCEPTION 'VALIDACAO_045_101_NAO_LIBEROU_HU'; END IF;
 RAISE NOTICE 'CLAIM_ATOMICO_101=SIM';
 RAISE NOTICE '101_NAO_CONFIRMADO_BLOQUEIA_HU=SIM';
 RAISE NOTICE '101_CONFIRMADO_LIBERA_HU=SIM';
END
$gaia$;

-- Caixa legada sem vinculo 045 deve manter comportamento 044.
DO $gaia$
DECLARE v_user bigint; v_term text;
BEGIN
 SELECT codigo_usuario,terminal_b INTO v_user,v_term FROM tmp_045_contexto;
 IF EXISTS(SELECT 1 FROM desenvolvimento.hu_caixa_etapa_sap WHERE codigo_hu_caixa=-450002) THEN RAISE EXCEPTION 'LEGADO_RECEBEU_045_INDEVIDAMENTE'; END IF;
 IF NOT desenvolvimento.fn_hu_caixa_finalizar_local(-450002,v_user,v_term) THEN RAISE EXCEPTION 'LEGADO_FINALIZACAO_FALHOU'; END IF;
 IF NOT desenvolvimento.fn_hu_caixa_salvar_preview(-450002,'{"Material":"4000108"}'::jsonb,'/HandlingUnit?sap-client=110') THEN
   RAISE EXCEPTION 'LEGADO_FOI_BLOQUEADO_PELO_GUARD_045'; END IF;
 RAISE NOTICE 'CAIXA_LEGADA_NAO_BLOQUEADA_PELO_GUARD_045=SIM';
 RAISE NOTICE 'LEGADO_044_NAO_REGREDIU=SIM';
END
$gaia$;


-- Ownership REV3: capability secreta, roubo de token pela MESMA role runtime e reassuncao append-only.
-- tmp_045_ownership e uma fixture temporaria exclusiva da VALIDACAO; nao integra o contrato de leitura do aplicativo.
CREATE TEMP TABLE tmp_045_ownership(
 owner_id char(1) PRIMARY KEY, claim_token uuid NOT NULL, tentativa integer NOT NULL
) ON COMMIT DROP;
GRANT SELECT ON TABLE tmp_045_contexto TO fugapet_dev_app;
GRANT INSERT ON TABLE tmp_045_ownership TO fugapet_dev_app;

-- SESSION_A, executando efetivamente como a role runtime, adquire CLAIM_A pelo retorno da funcao controlada.
SET LOCAL ROLE fugapet_dev_app;
DO $gaia$
DECLARE v_user bigint; v_a text; v_b text; v2 integer; v_claim_a uuid; v_tent integer;
BEGIN
 SELECT codigo_usuario,terminal_a,terminal_b INTO v_user,v_a,v_b FROM tmp_045_contexto;
 IF NOT desenvolvimento.fn_pa_045_iniciar_fluxo(-450005,v_user,v_a,'NOVA_ORQUESTRACAO','VALIDACAO_OWNERSHIP') THEN
   RAISE EXCEPTION 'VALIDACAO_045_OWNERSHIP_INICIAR_FALHOU'; END IF;
 IF NOT desenvolvimento.fn_pa_045_preparar_etapa(-450005,'261','{"GoodsMovementType":"261"}'::jsonb,v_user,v_a) THEN
   RAISE EXCEPTION 'VALIDACAO_045_OWNERSHIP_PREPARAR_FALHOU'; END IF;
 SELECT claim_token,numero_tentativa INTO v_claim_a,v_tent
   FROM desenvolvimento.fn_pa_045_claim_etapa(-450005,'261',v_user,v_a);
 IF v_claim_a IS NULL THEN RAISE EXCEPTION 'VALIDACAO_045_SESSION_A_NAO_RECEBEU_CLAIM'; END IF;
 INSERT INTO tmp_045_ownership(owner_id,claim_token,tentativa) VALUES('A',v_claim_a,v_tent);
 SELECT count(*) INTO v2 FROM desenvolvimento.fn_pa_045_claim_etapa(-450005,'261',v_user,v_b);
 IF v2<>0 THEN RAISE EXCEPTION 'VALIDACAO_045_SESSION_B_ADQUIRIU_SIMULTANEAMENTE'; END IF;
 IF desenvolvimento.fn_pa_045_registrar_erro(-450005,'261',v_tent,gen_random_uuid(),500,'{"erro":true}'::jsonb,'token incorreto','/MaterialDocument',v_user,v_b) THEN
   RAISE EXCEPTION 'VALIDACAO_045_TOKEN_INCORRETO_FINALIZOU'; END IF;
 RAISE NOTICE 'SESSION_A_ADQUIRE_CLAIM=SIM';
 RAISE NOTICE 'SESSION_B_SEGUNDO_CLAIM_SIMULTANEO=BLOQUEADO';
 RAISE NOTICE 'TOKEN_INCORRETO_FINALIZA=NAO';
END
$gaia$;
RESET ROLE;

-- SESSION_B usa a mesma role runtime. O contrato permitido informa estado, mas nao revela capability.
SET LOCAL ROLE fugapet_dev_app;
DO $gaia$
DECLARE v_cols integer;
BEGIN
 PERFORM 1 FROM desenvolvimento.vw_pa_045_etapa_estado_runtime WHERE codigo_hu_caixa=-450005 AND etapa_sap='261';
 IF has_table_privilege(current_user,'desenvolvimento.hu_caixa_etapa_sap','SELECT')
    OR has_table_privilege(current_user,'desenvolvimento.hu_caixa_etapa_sap_tentativa','SELECT')
    OR has_table_privilege(current_user,'desenvolvimento.hu_caixa_etapa_sap_evento','SELECT') THEN
   RAISE EXCEPTION 'VALIDACAO_045_RUNTIME_LE_TABELA_SENSIVEL';
 END IF;
 SELECT count(*) INTO v_cols FROM information_schema.columns
 WHERE table_schema='desenvolvimento'
   AND table_name IN ('vw_pa_045_etapa_estado_runtime','vw_pa_045_etapa_tentativa_runtime','vw_pa_045_etapa_evento_runtime')
   AND column_name IN ('claim_token','claim_token_efetivo','recovery_claim_token');
 IF v_cols<>0 THEN RAISE EXCEPTION 'VALIDACAO_045_RUNTIME_VIEW_EXPOE_TOKEN qtd=%',v_cols; END IF;
 RAISE NOTICE 'SESSION_B_CONTRATO_READ_ONLY_TOKEN_NAO_EXPOSTO=SIM';
 RAISE NOTICE 'RUNTIME_LE_CLAIM_TOKEN_ATIVO=NAO';
END
$gaia$;
RESET ROLE;

-- A partir daqui a fixture temporaria e legivel apenas para transportar os valores esperados entre os blocos
-- da mesma validacao. Isso NAO concede acesso a qualquer tabela/view persistente do produto.
GRANT SELECT ON TABLE tmp_045_ownership TO fugapet_dev_app;

-- O validador (postgres) simula passagem do tempo sem esperar cinco minutos.
DO $gaia$
DECLARE v_claim_a uuid;
BEGIN
 SELECT claim_token INTO v_claim_a FROM tmp_045_ownership WHERE owner_id='A';
 UPDATE desenvolvimento.hu_caixa_etapa_sap
    SET claim_obtido_em=clock_timestamp()-interval '10 minutes',claim_expira_em=clock_timestamp()-interval '5 minutes'
  WHERE codigo_hu_caixa=-450005 AND etapa_sap='261' AND claim_token=v_claim_a;
 IF NOT FOUND THEN RAISE EXCEPTION 'VALIDACAO_045_FIXTURE_EXPIRACAO_NAO_APLICADA'; END IF;
END
$gaia$;

-- SESSION_A, ainda como runtime, nao consegue finalizar depois da expiracao.
SET LOCAL ROLE fugapet_dev_app;
DO $gaia$
DECLARE v_user bigint; v_a text; v_claim_a uuid; v_tent integer;
BEGIN
 SELECT codigo_usuario,terminal_a INTO v_user,v_a FROM tmp_045_contexto;
 SELECT claim_token,tentativa INTO v_claim_a,v_tent FROM tmp_045_ownership WHERE owner_id='A';
 IF desenvolvimento.fn_pa_045_registrar_erro(-450005,'261',v_tent,v_claim_a,500,'{"erro":true}'::jsonb,'token expirado','/MaterialDocument',v_user,v_a) THEN
   RAISE EXCEPTION 'VALIDACAO_045_TOKEN_EXPIRADO_FINALIZOU'; END IF;
 RAISE NOTICE 'TOKEN_EXPIRADO_FINALIZA=NAO';
END
$gaia$;
RESET ROLE;

-- SESSION_B reassume legitimamente como a MESMA role runtime e recebe exclusivamente CLAIM_B pelo retorno da funcao.
SET LOCAL ROLE fugapet_dev_app;
DO $gaia$
DECLARE v_user bigint; v_b text; v_claim_a uuid; v_claim_b uuid; v_tent integer;
BEGIN
 SELECT codigo_usuario,terminal_b INTO v_user,v_b FROM tmp_045_contexto;
 SELECT claim_token,tentativa INTO v_claim_a,v_tent FROM tmp_045_ownership WHERE owner_id='A';
 SELECT claim_token,numero_tentativa INTO v_claim_b,v_tent
   FROM desenvolvimento.fn_pa_045_reassumir_claim_etapa(-450005,'261',v_user,v_b);
 IF v_claim_b IS NULL OR v_claim_b=v_claim_a THEN RAISE EXCEPTION 'VALIDACAO_045_REASSUNCAO_NAO_GEROU_NOVO_TOKEN'; END IF;
 INSERT INTO tmp_045_ownership(owner_id,claim_token,tentativa) VALUES('B',v_claim_b,v_tent);
 RAISE NOTICE 'NOVO_OWNER_RECEBE_NOVO_TOKEN=SIM';
END
$gaia$;
RESET ROLE;

-- Prova interna append-only: tentativa original conserva CLAIM_A; reassuncao registra CLAIM_B e seu owner/contexto.
DO $gaia$
DECLARE v_user bigint; v_b text; v_claim_a uuid; v_claim_b uuid; v_tent integer; v_event integer;
BEGIN
 SELECT codigo_usuario,terminal_b INTO v_user,v_b FROM tmp_045_contexto;
 SELECT claim_token,tentativa INTO v_claim_a,v_tent FROM tmp_045_ownership WHERE owner_id='A';
 SELECT claim_token INTO v_claim_b FROM tmp_045_ownership WHERE owner_id='B';
 IF (SELECT count(*) FROM desenvolvimento.hu_caixa_etapa_sap_tentativa t JOIN desenvolvimento.hu_caixa_etapa_sap e ON e.codigo_hu_caixa_etapa_sap=t.codigo_hu_caixa_etapa_sap
     WHERE e.codigo_hu_caixa=-450005 AND e.etapa_sap='261')<>1 THEN
   RAISE EXCEPTION 'VALIDACAO_045_REASSUNCAO_CRIOU_NOVA_TENTATIVA'; END IF;
 IF NOT EXISTS(
   SELECT 1 FROM desenvolvimento.hu_caixa_etapa_sap_tentativa t JOIN desenvolvimento.hu_caixa_etapa_sap e ON e.codigo_hu_caixa_etapa_sap=t.codigo_hu_caixa_etapa_sap
    WHERE e.codigo_hu_caixa=-450005 AND e.etapa_sap='261' AND t.numero_tentativa=v_tent AND t.claim_token=v_claim_a
 ) THEN RAISE EXCEPTION 'VALIDACAO_045_CLAIM_ORIGINAL_FOI_SOBRESCRITO'; END IF;
 SELECT count(*) INTO v_event FROM desenvolvimento.hu_caixa_etapa_sap_evento ev
 JOIN desenvolvimento.hu_caixa_etapa_sap_tentativa t ON t.codigo_hu_caixa_etapa_sap_tentativa=ev.codigo_hu_caixa_etapa_sap_tentativa
 JOIN desenvolvimento.hu_caixa_etapa_sap e ON e.codigo_hu_caixa_etapa_sap=t.codigo_hu_caixa_etapa_sap
 WHERE e.codigo_hu_caixa=-450005 AND e.etapa_sap='261' AND ev.tipo_evento='CLAIM_REASSUMIDO'
   AND ev.resultado='CLAIM_REASSUMIDO' AND ev.claim_token_efetivo=v_claim_b
   AND ev.usuario_operacao=v_user AND ev.terminal_operacao=upper(v_b);
 IF v_event<>1 THEN RAISE EXCEPTION 'VALIDACAO_045_HISTORICO_REASSUNCAO_INEQUIVOCO qtd=%',v_event; END IF;
 RAISE NOTICE 'CLAIM_ORIGINAL_IMUTAVEL=SIM';
 RAISE NOTICE 'HISTORICO_CLAIM_REASSUMIDO_APPEND_ONLY=SIM';
END
$gaia$;

-- Mesmo apos reassuncao, SESSION_A/SESSION_B nao descobrem CLAIM_B por leitura persistente permitida ao runtime.
SET LOCAL ROLE fugapet_dev_app;
DO $gaia$
DECLARE v_cols integer;
BEGIN
 PERFORM 1 FROM desenvolvimento.vw_pa_045_etapa_estado_runtime WHERE codigo_hu_caixa=-450005 AND etapa_sap='261';
 IF has_table_privilege(current_user,'desenvolvimento.hu_caixa_etapa_sap','SELECT')
    OR has_table_privilege(current_user,'desenvolvimento.hu_caixa_etapa_sap_tentativa','SELECT')
    OR has_table_privilege(current_user,'desenvolvimento.hu_caixa_etapa_sap_evento','SELECT') THEN
   RAISE EXCEPTION 'VALIDACAO_045_RUNTIME_LE_TOKEN_POS_REASSUNCAO';
 END IF;
 SELECT count(*) INTO v_cols FROM information_schema.columns
 WHERE table_schema='desenvolvimento'
   AND table_name IN ('vw_pa_045_etapa_estado_runtime','vw_pa_045_etapa_tentativa_runtime','vw_pa_045_etapa_evento_runtime')
   AND column_name IN ('claim_token','claim_token_efetivo','recovery_claim_token');
 IF v_cols<>0 THEN RAISE EXCEPTION 'VALIDACAO_045_RUNTIME_VIEW_EXPOE_TOKEN_POS_REASSUNCAO qtd=%',v_cols; END IF;
 RAISE NOTICE 'TOKEN_NOVO_NAO_EXPOSTO_POR_LEITURA_RUNTIME=SIM';
END
$gaia$;
RESET ROLE;

-- SESSION_A usa CLAIM_A antigo: bloqueado. SESSION_B usa CLAIM_B vigente: sucesso.
SET LOCAL ROLE fugapet_dev_app;
DO $gaia$
DECLARE v_user bigint; v_a text; v_b text; v_claim_a uuid; v_claim_b uuid; v_tent integer; v_ok boolean;
BEGIN
 SELECT codigo_usuario,terminal_a,terminal_b INTO v_user,v_a,v_b FROM tmp_045_contexto;
 SELECT claim_token,tentativa INTO v_claim_a,v_tent FROM tmp_045_ownership WHERE owner_id='A';
 SELECT claim_token INTO v_claim_b FROM tmp_045_ownership WHERE owner_id='B';
 IF desenvolvimento.fn_pa_045_registrar_timeout(-450005,'261',v_tent,v_claim_a,'owner antigo','/MaterialDocument',v_user,v_a) THEN
   RAISE EXCEPTION 'VALIDACAO_045_OWNER_ANTIGO_ALTEROU_APOS_REASSUNCAO'; END IF;
 v_ok:=desenvolvimento.fn_pa_045_registrar_sucesso(-450005,'261',v_tent,v_claim_b,201,'5000045561','2026',
       '{"MaterialDocument":"5000045561","MaterialDocumentYear":"2026"}'::jsonb,'/MaterialDocument',v_user,v_b);
 IF NOT v_ok THEN RAISE EXCEPTION 'VALIDACAO_045_OWNER_VIGENTE_NAO_CONCLUIU'; END IF;
 RAISE NOTICE 'TOKEN_ANTIGO_APOS_REASSUNCAO_FINALIZA=NAO';
 RAISE NOTICE 'OWNER_VIGENTE_FINALIZA=SIM';
END
$gaia$;
RESET ROLE;

-- Resultado final aponta CLAIM_B e a tentativa original continua registrando CLAIM_A.
DO $gaia$
DECLARE v_claim_a uuid; v_claim_b uuid; v_tent integer; v_event integer;
BEGIN
 SELECT claim_token,tentativa INTO v_claim_a,v_tent FROM tmp_045_ownership WHERE owner_id='A';
 SELECT claim_token INTO v_claim_b FROM tmp_045_ownership WHERE owner_id='B';
 SELECT count(*) INTO v_event FROM desenvolvimento.hu_caixa_etapa_sap_evento ev
 JOIN desenvolvimento.hu_caixa_etapa_sap_tentativa t ON t.codigo_hu_caixa_etapa_sap_tentativa=ev.codigo_hu_caixa_etapa_sap_tentativa
 JOIN desenvolvimento.hu_caixa_etapa_sap e ON e.codigo_hu_caixa_etapa_sap=t.codigo_hu_caixa_etapa_sap
 WHERE e.codigo_hu_caixa=-450005 AND e.etapa_sap='261' AND ev.tipo_evento='RESULTADO_POST'
   AND ev.resultado='CONFIRMADO' AND ev.claim_token_efetivo=v_claim_b;
 IF v_event<>1 THEN RAISE EXCEPTION 'VALIDACAO_045_RESULTADO_NAO_IDENTIFICA_CLAIM_VIGENTE qtd=%',v_event; END IF;
 IF NOT EXISTS(
   SELECT 1 FROM desenvolvimento.hu_caixa_etapa_sap_tentativa t JOIN desenvolvimento.hu_caixa_etapa_sap e ON e.codigo_hu_caixa_etapa_sap=t.codigo_hu_caixa_etapa_sap
    WHERE e.codigo_hu_caixa=-450005 AND e.etapa_sap='261' AND t.numero_tentativa=v_tent AND t.claim_token=v_claim_a
 ) THEN RAISE EXCEPTION 'VALIDACAO_045_CLAIM_ORIGINAL_ALTERADO_APOS_RESULTADO'; END IF;
 RAISE NOTICE 'RESULTADO_IDENTIFICA_CLAIM_VIGENTE=SIM';
 RAISE NOTICE 'HISTORICO_REASSUNCAO_INEQUIVOCO=SIM';
END
$gaia$;

-- Reuso de 261 historico: confirma localmente a proveniencia sem executar novo POST 261.
DO $gaia$
DECLARE v_user bigint; v_term text; v_ok boolean; v_event integer;
BEGIN
 SELECT codigo_usuario,terminal_d INTO v_user,v_term FROM tmp_045_contexto;
 IF NOT desenvolvimento.fn_pa_045_iniciar_fluxo(-450004,v_user,v_term,'HISTORICO_EXISTENTE','consumo_material_lancamento:VALIDACAO') THEN
   RAISE EXCEPTION 'VALIDACAO_045_HISTORICO_261_INICIAR_FALHOU'; END IF;
 BEGIN
   PERFORM desenvolvimento.fn_pa_045_preparar_etapa(-450004,'261','{"GoodsMovementType":"261"}'::jsonb,v_user,v_term);
   RAISE EXCEPTION 'TESTE_261_HISTORICO_PERMITIU_NOVO_POST';
 EXCEPTION WHEN raise_exception THEN
   IF SQLERRM NOT LIKE '%PA045_261_HISTORICO_DEVE_USAR_REGISTRO_DE_RESULTADO_EXISTENTE_SEM_POST%' THEN RAISE; END IF;
 END;
 v_ok:=desenvolvimento.fn_pa_045_registrar_261_historico_confirmado(-450004,'5000045260','2026','consumo_material_lancamento:VALIDACAO',v_user,v_term);
 IF NOT v_ok THEN RAISE EXCEPTION 'VALIDACAO_045_HISTORICO_261_CONFIRMAR_FALHOU'; END IF;
 IF NOT desenvolvimento.fn_pa_045_preparar_etapa(-450004,'101','{"GoodsMovementType":"101"}'::jsonb,v_user,v_term) THEN
   RAISE EXCEPTION 'VALIDACAO_045_HISTORICO_261_NAO_LIBEROU_101'; END IF;
 SELECT count(*) INTO v_event
 FROM desenvolvimento.hu_caixa_etapa_sap_evento ev
 JOIN desenvolvimento.hu_caixa_etapa_sap_tentativa t ON t.codigo_hu_caixa_etapa_sap_tentativa=ev.codigo_hu_caixa_etapa_sap_tentativa
 JOIN desenvolvimento.hu_caixa_etapa_sap e ON e.codigo_hu_caixa_etapa_sap=t.codigo_hu_caixa_etapa_sap
 WHERE e.codigo_hu_caixa=-450004 AND e.etapa_sap='261' AND ev.tipo_evento='RESULTADO_HISTORICO'
   AND ev.metodo_http='LOCAL' AND ev.http_status IS NULL;
 IF v_event<>1 THEN RAISE EXCEPTION 'VALIDACAO_045_HISTORICO_261_GEROU_EVENTO_INCORRETO quantidade=%',v_event; END IF;
 RAISE NOTICE 'CONTRATO_SAP_261_REUTILIZADO_SEM_NOVO_POST=SIM';
 RAISE NOTICE 'PROVENIENCIA_261_HISTORICA_PERSISTIVEL=SIM';
END
$gaia$;

-- ============================================================================
-- B. REV4 - RECOVERY SEGURO POS-RESTART 261 E 101
-- Recovery nao incrementa tentativa HTTP, nao executa POST e nao revela claim de envio.
-- Politica REV4: timeout/erro aposentam o lease de envio imediatamente; recovery usa lease separado.
-- ============================================================================
CREATE TEMP TABLE tmp_045_recovery(
 chave text PRIMARY KEY, claim_token uuid NOT NULL, tentativa integer NOT NULL
) ON COMMIT DROP;
GRANT SELECT,INSERT ON TABLE tmp_045_recovery TO fugapet_dev_app;

-- 261: CLAIM_ENVIO_A -> TIMEOUT -> RECOVERY_B -> reconciliacao -> liberacao.
DO $gaia$
DECLARE v_user bigint; v_term text; v_claim_a uuid; v_tent integer; v_qtd integer;
BEGIN
 SELECT codigo_usuario,terminal_c INTO v_user,v_term FROM tmp_045_contexto;
 IF NOT desenvolvimento.fn_pa_045_iniciar_fluxo(-450003,v_user,v_term,'NOVA_ORQUESTRACAO','VALIDACAO_RECOVERY_REV4') THEN
   RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_INICIAR_FLUXO_FALHOU'; END IF;
 IF NOT desenvolvimento.fn_pa_045_preparar_etapa(-450003,'261','{"GoodsMovementType":"261"}'::jsonb,v_user,v_term) THEN
   RAISE EXCEPTION 'VALIDACAO_045_PREPARAR_261_RECOVERY_FALHOU'; END IF;
 SELECT claim_token,numero_tentativa INTO v_claim_a,v_tent FROM desenvolvimento.fn_pa_045_claim_etapa(-450003,'261',v_user,v_term);
 IF v_claim_a IS NULL OR v_tent<>1 THEN RAISE EXCEPTION 'VALIDACAO_045_CLAIM_ENVIO_A_261_AUSENTE'; END IF;
 INSERT INTO tmp_045_recovery(chave,claim_token,tentativa) VALUES('261_ENVIO_A',v_claim_a,v_tent);
 IF NOT desenvolvimento.fn_pa_045_registrar_timeout(-450003,'261',v_tent,v_claim_a,'timeout 261 controlado','/MaterialDocument',v_user,v_term) THEN
   RAISE EXCEPTION 'VALIDACAO_045_TIMEOUT_261_FALHOU'; END IF;
 SELECT count(*) INTO v_qtd FROM desenvolvimento.hu_caixa_etapa_sap_tentativa t
 JOIN desenvolvimento.hu_caixa_etapa_sap e ON e.codigo_hu_caixa_etapa_sap=t.codigo_hu_caixa_etapa_sap
 WHERE e.codigo_hu_caixa=-450003 AND e.etapa_sap='261';
 IF v_qtd<>1 THEN RAISE EXCEPTION 'VALIDACAO_045_TENTATIVA_HTTP_261_DIVERGENTE qtd=%',v_qtd; END IF;
END
$gaia$;

-- Novo processo B, mesma role runtime: nao le CLAIM_A e recebe somente nova capability de recovery.
SET LOCAL ROLE fugapet_dev_app;
DO $gaia$
DECLARE v_user bigint; v_b text; v_r uuid; v_tent integer; v_qtd integer; v_cols integer;
BEGIN
 SELECT codigo_usuario,terminal_b INTO v_user,v_b FROM tmp_045_contexto;
 PERFORM 1 FROM desenvolvimento.vw_pa_045_etapa_estado_runtime WHERE codigo_hu_caixa=-450003 AND etapa_sap='261';
 IF has_table_privilege(current_user,'desenvolvimento.hu_caixa_etapa_sap','SELECT')
    OR has_table_privilege(current_user,'desenvolvimento.hu_caixa_etapa_sap_evento','SELECT') THEN
   RAISE EXCEPTION 'VALIDACAO_045_RUNTIME_LE_TOKEN_ANTIGO_261'; END IF;
 SELECT count(*) INTO v_cols FROM information_schema.columns WHERE table_schema='desenvolvimento'
   AND table_name IN ('vw_pa_045_etapa_estado_runtime','vw_pa_045_etapa_evento_runtime')
   AND column_name IN ('claim_token','claim_token_efetivo','recovery_claim_token');
 IF v_cols<>0 THEN RAISE EXCEPTION 'VALIDACAO_045_RUNTIME_VIEW_EXPOE_RECOVERY_TOKEN_261'; END IF;
 SELECT recovery_claim_token,numero_tentativa INTO v_r,v_tent
   FROM desenvolvimento.fn_pa_045_adquirir_recovery_etapa(-450003,'261',v_user,v_b);
 IF v_r IS NULL OR v_tent<>1 THEN RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_B_261_NAO_ADQUIRIDO'; END IF;
 INSERT INTO tmp_045_recovery(chave,claim_token,tentativa) VALUES('261_RECOVERY_B',v_r,v_tent);
 SELECT count(*) INTO v_qtd FROM desenvolvimento.fn_pa_045_adquirir_recovery_etapa(-450003,'261',v_user,(SELECT terminal_d FROM tmp_045_contexto));
 IF v_qtd<>0 THEN RAISE EXCEPTION 'VALIDACAO_045_SEGUNDO_RECOVERY_261_SIMULTANEO'; END IF;
 RAISE NOTICE 'RUNTIME_LE_TOKEN_ANTIGO=NAO';
 RAISE NOTICE 'RECOVERY_261_NOVO_OWNER_RECEBE_NOVA_CAPABILITY=SIM';
 RAISE NOTICE 'RECOVERY_261_LEASE_EXCLUSIVO=SIM';
END
$gaia$;
RESET ROLE;

DO $gaia$
DECLARE v_user bigint; v_b text; v_a uuid; v_r uuid; v_tent integer; v_qtd integer; v_claim2 uuid; v_tent2 integer;
BEGIN
 SELECT codigo_usuario,terminal_b INTO v_user,v_b FROM tmp_045_contexto;
 SELECT claim_token,tentativa INTO v_a,v_tent FROM tmp_045_recovery WHERE chave='261_ENVIO_A';
 SELECT claim_token INTO v_r FROM tmp_045_recovery WHERE chave='261_RECOVERY_B';
 IF desenvolvimento.fn_pa_045_registrar_reconciliacao(-450003,'261',v_tent,gen_random_uuid(),'CONFIRMADO_NAO_EXISTE',404,NULL,NULL,
       '{"found":false}'::jsonb,'token aleatorio','/MaterialDocument/reconcile',v_user,v_b) THEN
   RAISE EXCEPTION 'VALIDACAO_045_TOKEN_ALEATORIO_RECONCILIOU_261'; END IF;
 IF desenvolvimento.fn_pa_045_registrar_reconciliacao(-450003,'261',v_tent,v_a,'CONFIRMADO_NAO_EXISTE',404,NULL,NULL,
       '{"found":false}'::jsonb,'claim envio aposentado','/MaterialDocument/reconcile',v_user,v_b) THEN
   RAISE EXCEPTION 'VALIDACAO_045_CLAIM_ENVIO_APOS_TIMEOUT_RECONCILIOU_261'; END IF;
 IF NOT desenvolvimento.fn_pa_045_registrar_reconciliacao(-450003,'261',v_tent,v_r,'CONFIRMADO_NAO_EXISTE',404,NULL,NULL,
       '{"found":false}'::jsonb,'documento 261 nao encontrado','/MaterialDocument/reconcile',v_user,v_b) THEN
   RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_B_NAO_RECONCILIOU_261'; END IF;
 SELECT count(*) INTO v_qtd FROM desenvolvimento.hu_caixa_etapa_sap_tentativa t
 JOIN desenvolvimento.hu_caixa_etapa_sap e ON e.codigo_hu_caixa_etapa_sap=t.codigo_hu_caixa_etapa_sap
 WHERE e.codigo_hu_caixa=-450003 AND e.etapa_sap='261';
 IF v_qtd<>1 THEN RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_INCREMENTOU_TENTATIVA_HTTP_261 qtd=%',v_qtd; END IF;
 IF NOT desenvolvimento.fn_pa_045_liberar_reprocessamento(-450003,'261',v_r,'POS_RECONCILIACAO_NAO_ENCONTRADO',
       'liberacao controlada apos recovery 261',v_user,v_b) THEN RAISE EXCEPTION 'VALIDACAO_045_LIBERACAO_RECOVERY_261_FALHOU'; END IF;
 IF NOT desenvolvimento.fn_pa_045_preparar_etapa(-450003,'261','{"GoodsMovementType":"261"}'::jsonb,v_user,v_b) THEN RAISE EXCEPTION 'VALIDACAO_045_REPREPARAR_261_FALHOU'; END IF;
 SELECT claim_token,numero_tentativa INTO v_claim2,v_tent2 FROM desenvolvimento.fn_pa_045_claim_etapa(-450003,'261',v_user,v_b);
 IF v_tent2<>2 OR NOT desenvolvimento.fn_pa_045_registrar_sucesso(-450003,'261',v_tent2,v_claim2,201,'5000045361','2026','{"ok":true}'::jsonb,'/MaterialDocument',v_user,v_b) THEN
   RAISE EXCEPTION 'VALIDACAO_045_SUCESSO_261_T2_FALHOU'; END IF;
 RAISE NOTICE 'RECOVERY_261_101_APOS_RESTART=IMPLEMENTADO';
 RAISE NOTICE 'RECOVERY_INCREMENTA_TENTATIVA_HTTP=NAO';
 RAISE NOTICE 'RECOVERY_EXECUTA_POST=NAO';
END
$gaia$;

-- 101: B adquire recovery, cai; apos expiracao C reassume e somente C reconcilia.
DO $gaia$
DECLARE v_user bigint; v_term text; v_a uuid; v_tent integer;
BEGIN
 SELECT codigo_usuario,terminal_c INTO v_user,v_term FROM tmp_045_contexto;
 IF NOT desenvolvimento.fn_pa_045_preparar_etapa(-450003,'101','{"GoodsMovementType":"101"}'::jsonb,v_user,v_term) THEN
   RAISE EXCEPTION 'VALIDACAO_045_PREPARAR_101_RECOVERY_FALHOU'; END IF;
 SELECT claim_token,numero_tentativa INTO v_a,v_tent FROM desenvolvimento.fn_pa_045_claim_etapa(-450003,'101',v_user,v_term);
 INSERT INTO tmp_045_recovery(chave,claim_token,tentativa) VALUES('101_ENVIO_A',v_a,v_tent);
 IF NOT desenvolvimento.fn_pa_045_registrar_timeout(-450003,'101',v_tent,v_a,'timeout 101 controlado','/MaterialDocument',v_user,v_term) THEN
   RAISE EXCEPTION 'VALIDACAO_045_TIMEOUT_101_FALHOU'; END IF;
END
$gaia$;

SET LOCAL ROLE fugapet_dev_app;
DO $gaia$
DECLARE v_user bigint; v_b text; v_r uuid; v_tent integer;
BEGIN
 SELECT codigo_usuario,terminal_b INTO v_user,v_b FROM tmp_045_contexto;
 SELECT recovery_claim_token,numero_tentativa INTO v_r,v_tent
  FROM desenvolvimento.fn_pa_045_adquirir_recovery_etapa(-450003,'101',v_user,v_b);
 IF v_r IS NULL THEN RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_B_101_NAO_ADQUIRIDO'; END IF;
 INSERT INTO tmp_045_recovery(chave,claim_token,tentativa) VALUES('101_RECOVERY_B',v_r,v_tent);
END
$gaia$;
RESET ROLE;

-- Simula queda de B e expiracao do lease de recovery, sem tocar na tentativa HTTP original.
UPDATE desenvolvimento.hu_caixa_etapa_sap
 SET recovery_claim_obtido_em=clock_timestamp()-interval '10 minutes',
     recovery_claim_expira_em=clock_timestamp()-interval '5 minutes'
WHERE codigo_hu_caixa=-450003 AND etapa_sap='101'
  AND recovery_claim_token=(SELECT claim_token FROM tmp_045_recovery WHERE chave='101_RECOVERY_B');

SET LOCAL ROLE fugapet_dev_app;
DO $gaia$
DECLARE v_user bigint; v_c text; v_r uuid; v_tent integer;
BEGIN
 SELECT codigo_usuario,terminal_d INTO v_user,v_c FROM tmp_045_contexto;
 SELECT recovery_claim_token,numero_tentativa INTO v_r,v_tent
  FROM desenvolvimento.fn_pa_045_adquirir_recovery_etapa(-450003,'101',v_user,v_c);
 IF v_r IS NULL OR v_r=(SELECT claim_token FROM tmp_045_recovery WHERE chave='101_RECOVERY_B') THEN
   RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_C_101_NAO_REASSUMIU'; END IF;
 INSERT INTO tmp_045_recovery(chave,claim_token,tentativa) VALUES('101_RECOVERY_C',v_r,v_tent);
END
$gaia$;
RESET ROLE;

DO $gaia$
DECLARE v_user bigint; v_c text; v_b uuid; v_c_token uuid; v_tent integer; v_qtd integer; v_claim2 uuid; v_tent2 integer;
BEGIN
 SELECT codigo_usuario,terminal_d INTO v_user,v_c FROM tmp_045_contexto;
 SELECT claim_token,tentativa INTO v_b,v_tent FROM tmp_045_recovery WHERE chave='101_RECOVERY_B';
 SELECT claim_token INTO v_c_token FROM tmp_045_recovery WHERE chave='101_RECOVERY_C';
 IF desenvolvimento.fn_pa_045_registrar_reconciliacao(-450003,'101',v_tent,v_b,'CONFIRMADO_NAO_EXISTE',404,NULL,NULL,
       '{"found":false}'::jsonb,'recovery B expirado','/MaterialDocument/reconcile',v_user,v_c) THEN
   RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_B_EXPIRADO_RECONCILIOU_101'; END IF;
 IF NOT desenvolvimento.fn_pa_045_registrar_reconciliacao(-450003,'101',v_tent,v_c_token,'CONFIRMADO_NAO_EXISTE',404,NULL,NULL,
       '{"found":false}'::jsonb,'documento 101 nao encontrado','/MaterialDocument/reconcile',v_user,v_c) THEN
   RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_C_NAO_RECONCILIOU_101'; END IF;
 SELECT count(*) INTO v_qtd FROM desenvolvimento.hu_caixa_etapa_sap_tentativa t
 JOIN desenvolvimento.hu_caixa_etapa_sap e ON e.codigo_hu_caixa_etapa_sap=t.codigo_hu_caixa_etapa_sap
 WHERE e.codigo_hu_caixa=-450003 AND e.etapa_sap='101';
 IF v_qtd<>1 THEN RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_INCREMENTOU_TENTATIVA_HTTP_101 qtd=%',v_qtd; END IF;
 IF NOT desenvolvimento.fn_pa_045_liberar_reprocessamento(-450003,'101',v_c_token,'POS_RECONCILIACAO_NAO_ENCONTRADO',
       'liberacao controlada apos recovery 101',v_user,v_c) THEN RAISE EXCEPTION 'VALIDACAO_045_LIBERACAO_RECOVERY_101_FALHOU'; END IF;
 IF NOT desenvolvimento.fn_pa_045_preparar_etapa(-450003,'101','{"GoodsMovementType":"101"}'::jsonb,v_user,v_c) THEN RAISE EXCEPTION 'VALIDACAO_045_REPREPARAR_101_FALHOU'; END IF;
 SELECT claim_token,numero_tentativa INTO v_claim2,v_tent2 FROM desenvolvimento.fn_pa_045_claim_etapa(-450003,'101',v_user,v_c);
 IF v_tent2<>2 OR NOT desenvolvimento.fn_pa_045_registrar_sucesso(-450003,'101',v_tent2,v_claim2,201,'5000045301','2026','{"ok":true}'::jsonb,'/MaterialDocument',v_user,v_c) THEN
   RAISE EXCEPTION 'VALIDACAO_045_SUCESSO_101_T2_FALHOU'; END IF;
 RAISE NOTICE 'REASSUNCAO_RECOVERY_APOS_EXPIRACAO=SIM';
 RAISE NOTICE 'RECOVERY_ANTIGO_APOS_REASSUNCAO_REJEITADO=SIM';
END
$gaia$;

-- Historico reconstruivel A -> recovery B -> recovery C -> resultado, sem sobrescrever claim original.
DO $gaia$
DECLARE v_a261 uuid; v_b261 uuid; v_b101 uuid; v_c101 uuid; v_events integer;
BEGIN
 SELECT claim_token INTO v_a261 FROM tmp_045_recovery WHERE chave='261_ENVIO_A';
 SELECT claim_token INTO v_b261 FROM tmp_045_recovery WHERE chave='261_RECOVERY_B';
 SELECT claim_token INTO v_b101 FROM tmp_045_recovery WHERE chave='101_RECOVERY_B';
 SELECT claim_token INTO v_c101 FROM tmp_045_recovery WHERE chave='101_RECOVERY_C';
 IF NOT EXISTS(
   SELECT 1 FROM desenvolvimento.hu_caixa_etapa_sap_tentativa t JOIN desenvolvimento.hu_caixa_etapa_sap e ON e.codigo_hu_caixa_etapa_sap=t.codigo_hu_caixa_etapa_sap
    WHERE e.codigo_hu_caixa=-450003 AND e.etapa_sap='261' AND t.numero_tentativa=1 AND t.claim_token=v_a261
 ) THEN RAISE EXCEPTION 'VALIDACAO_045_CLAIM_ORIGINAL_261_ALTERADO'; END IF;
 SELECT count(*) INTO v_events FROM desenvolvimento.hu_caixa_etapa_sap_evento ev
 JOIN desenvolvimento.hu_caixa_etapa_sap_tentativa t ON t.codigo_hu_caixa_etapa_sap_tentativa=ev.codigo_hu_caixa_etapa_sap_tentativa
 JOIN desenvolvimento.hu_caixa_etapa_sap e ON e.codigo_hu_caixa_etapa_sap=t.codigo_hu_caixa_etapa_sap
 WHERE e.codigo_hu_caixa=-450003 AND (
   (e.etapa_sap='261' AND ev.tipo_evento='RECOVERY_CLAIM_ADQUIRIDO' AND ev.claim_token_efetivo=v_b261)
   OR (e.etapa_sap='101' AND ev.tipo_evento='RECOVERY_CLAIM_ADQUIRIDO' AND ev.claim_token_efetivo=v_b101)
   OR (e.etapa_sap='101' AND ev.tipo_evento='RECOVERY_CLAIM_REASSUMIDO' AND ev.claim_token_efetivo=v_c101)
   OR (e.etapa_sap='101' AND ev.tipo_evento='RECONCILIACAO' AND ev.claim_token_efetivo=v_c101)
 );
 IF v_events<>4 THEN RAISE EXCEPTION 'VALIDACAO_045_HISTORICO_RECOVERY_INCOMPLETO qtd=%/4',v_events; END IF;
 RAISE NOTICE 'HISTORICO_RECOVERY_APPEND_ONLY=SIM';
 RAISE NOTICE 'CLAIM_ORIGINAL_IMUTAVEL_POS_RECOVERY=SIM';
 RAISE NOTICE 'RESULTADO_RECOVERY_IDENTIFICA_CLAIM_VIGENTE=SIM';
END
$gaia$;

DO $gaia$
DECLARE v261 text; y261 text; v101 text; y101 text;
BEGIN
 SELECT material_document,material_document_year INTO v261,y261 FROM desenvolvimento.hu_caixa_etapa_sap WHERE codigo_hu_caixa=-450003 AND etapa_sap='261';
 SELECT material_document,material_document_year INTO v101,y101 FROM desenvolvimento.hu_caixa_etapa_sap WHERE codigo_hu_caixa=-450003 AND etapa_sap='101';
 IF v261 IS NULL OR y261 IS NULL OR v101 IS NULL OR y101 IS NULL THEN RAISE EXCEPTION 'VALIDACAO_045_MATERIAL_DOCUMENT_NAO_PERSISTIDO'; END IF;
 RAISE NOTICE 'MATERIAL_DOCUMENT_261_PERSISTIVEL=SIM';
 RAISE NOTICE 'MATERIAL_DOCUMENT_101_PERSISTIVEL=SIM';
 RAISE NOTICE 'TIMEOUT_INDETERMINADO=SIM';
 RAISE NOTICE 'RETRY_CEGO_BLOQUEADO=SIM';
END
$gaia$;

-- ============================================================================
-- C. Concluir HU 044 da caixa -450001 para testar paletizacao.
-- ============================================================================
DO $gaia$
DECLARE v_user bigint; v_term text; v_claim uuid; v_tent integer; v_count integer; v_ok boolean;
BEGIN
 SELECT codigo_usuario,terminal_a INTO v_user,v_term FROM tmp_045_contexto;
 IF NOT desenvolvimento.fn_hu_caixa_aguardar_autorizacao(-450001) THEN RAISE EXCEPTION 'VALIDACAO_045_HU_AGUARDAR_FALHOU'; END IF;
 IF NOT desenvolvimento.fn_hu_caixa_autorizar_envio(-450001,v_user,v_term) THEN RAISE EXCEPTION 'VALIDACAO_045_HU_AUTORIZAR_FALHOU'; END IF;
 SELECT count(*) INTO v_count FROM desenvolvimento.fn_hu_caixa_claim_envio(-450001,v_user,v_term);
 SELECT claim_token,tentativas INTO v_claim,v_tent FROM desenvolvimento.hu_caixa WHERE codigo_hu_caixa=-450001;
 IF v_count<>1 THEN RAISE EXCEPTION 'VALIDACAO_045_HU_CLAIM_FALHOU'; END IF;
 v_ok:=desenvolvimento.fn_hu_caixa_registrar_sucesso(
   -450001,v_tent,v_claim,'900045001','',201,
   '{"HandlingUnitExternalID":"900045001","Warehouse":""}'::jsonb,'{}'::jsonb,
   'W/"GAIA-045"','GAIA_VALIDACAO',clock_timestamp());
 IF NOT v_ok THEN RAISE EXCEPTION 'VALIDACAO_045_HU_SUCESSO_FALHOU'; END IF;
 IF NOT EXISTS(SELECT 1 FROM desenvolvimento.hu_caixa WHERE codigo_hu_caixa=-450001 AND status_hu_caixa='CONFIRMADA_SAP' AND handling_unit_external_id='900045001') THEN
   RAISE EXCEPTION 'VALIDACAO_045_HU_NAO_CONFIRMADA'; END IF;
 RAISE NOTICE 'HU_044_POS_101_CONFIRMADA=SIM';
END
$gaia$;


-- Caixa Y legada: preserva comportamento 044 e fornece segunda caixa confirmada
-- para a prova fisica de unicidade de palete.
DO $gaia$
DECLARE v_user bigint; v_term text; v_claim uuid; v_tent integer; v_count integer; v_ok boolean;
BEGIN
 SELECT codigo_usuario,terminal_b INTO v_user,v_term FROM tmp_045_contexto;
 IF NOT desenvolvimento.fn_hu_caixa_aguardar_autorizacao(-450002) THEN RAISE EXCEPTION 'VALIDACAO_045_HU_LEGADA_AGUARDAR_FALHOU'; END IF;
 IF NOT desenvolvimento.fn_hu_caixa_autorizar_envio(-450002,v_user,v_term) THEN RAISE EXCEPTION 'VALIDACAO_045_HU_LEGADA_AUTORIZAR_FALHOU'; END IF;
 SELECT count(*) INTO v_count FROM desenvolvimento.fn_hu_caixa_claim_envio(-450002,v_user,v_term);
 SELECT claim_token,tentativas INTO v_claim,v_tent FROM desenvolvimento.hu_caixa WHERE codigo_hu_caixa=-450002;
 IF v_count<>1 THEN RAISE EXCEPTION 'VALIDACAO_045_HU_LEGADA_CLAIM_FALHOU'; END IF;
 v_ok:=desenvolvimento.fn_hu_caixa_registrar_sucesso(
   -450002,v_tent,v_claim,'900045002','',201,
   '{"HandlingUnitExternalID":"900045002","Warehouse":""}'::jsonb,'{}'::jsonb,
   'W/"GAIA-045-LEGADO"','GAIA_VALIDACAO',clock_timestamp());
 IF NOT v_ok THEN RAISE EXCEPTION 'VALIDACAO_045_HU_LEGADA_SUCESSO_FALHOU'; END IF;
 IF NOT EXISTS(SELECT 1 FROM desenvolvimento.hu_caixa WHERE codigo_hu_caixa=-450002 AND status_hu_caixa='CONFIRMADA_SAP' AND handling_unit_external_id='900045002') THEN
   RAISE EXCEPTION 'VALIDACAO_045_HU_LEGADA_NAO_CONFIRMADA'; END IF;
 RAISE NOTICE 'CAIXA_Y_LEGADA_CONFIRMADA_PARA_TESTE_PALETE=SIM';
END
$gaia$;

-- Dois paletes fixture com IDs negativos para evitar avanço da sequence do HEADER.
INSERT INTO desenvolvimento.hu_palete(
 codigo_hu_palete,material_embalagem,centro,deposito,peso_bruto,peso_liquido,peso_tara,
 unidade_peso,status_hu_palete,codigo_usuario,correlation_id,terminal)
SELECT -450001,'3000009','3007','PP02',100.000,90.000,10.000,'KG','RASCUNHO',codigo_usuario,
       '04510000-0000-0000-0000-000000000001'::uuid,terminal_a FROM tmp_045_contexto
UNION ALL
SELECT -450002,'3000009','3007','PP02',100.000,90.000,10.000,'KG','RASCUNHO',codigo_usuario,
       '04510000-0000-0000-0000-000000000002'::uuid,terminal_b FROM tmp_045_contexto;

\echo '=== UNICIDADE_PALETE_DEFINICAO_FISICA_POS_045 ==='
SELECT n.nspname AS schema_name,t.relname AS tabela,idx.relname AS indice,i.indisunique AS unicidade,
       ARRAY(SELECT a.attname::text FROM unnest(i.indkey::smallint[]) WITH ORDINALITY k(attnum,ord)
             JOIN pg_attribute a ON a.attrelid=i.indrelid AND a.attnum=k.attnum WHERE k.attnum>0 ORDER BY k.ord) AS colunas,
       pg_get_expr(i.indpred,i.indrelid,true) AS predicado_parcial,
       pg_get_indexdef(i.indexrelid) AS definicao,i.indisvalid AS validade
FROM pg_index i JOIN pg_class t ON t.oid=i.indrelid JOIN pg_class idx ON idx.oid=i.indexrelid JOIN pg_namespace n ON n.oid=t.relnamespace
WHERE n.nspname='desenvolvimento' AND t.relname='hu_palete_item' AND i.indisunique ORDER BY idx.relname;

DO $gaia$
DECLARE v_user bigint; v_a text; v_b text; v_id bigint; v_idx_caixa integer; v_idx_palete_caixa integer;
BEGIN
 SELECT codigo_usuario,terminal_a,terminal_b INTO v_user,v_a,v_b FROM tmp_045_contexto;

 -- Caixa nao confirmada continua inelegivel.
 BEGIN
   PERFORM desenvolvimento.fn_pa_045_palete_vincular_caixa(-450001,-450004,1,v_user,v_a);
   RAISE EXCEPTION 'TESTE_CAIXA_NAO_CONFIRMADA_PALETIZOU';
 EXCEPTION WHEN raise_exception THEN
   IF SQLERRM NOT LIKE '%PA045_PALETE_CAIXA_INELEGIVEL%' THEN RAISE; END IF;
 END;
 RAISE NOTICE 'CAIXA_NAO_CONFIRMADA_NAO_PALETIZA=SIM';

 -- Prova semantica da unicidade: nao depende do nome do indice.
 SELECT count(*) INTO v_idx_caixa FROM pg_index i
 WHERE i.indrelid='desenvolvimento.hu_palete_item'::regclass AND i.indisunique AND i.indisvalid
   AND ARRAY(SELECT a.attname::text FROM unnest(i.indkey::smallint[]) WITH ORDINALITY k(attnum,ord)
             JOIN pg_attribute a ON a.attrelid=i.indrelid AND a.attnum=k.attnum WHERE k.attnum>0 ORDER BY k.ord)=ARRAY['codigo_hu_caixa']::text[]
   AND lower(COALESCE(pg_get_expr(i.indpred,i.indrelid,true),'')) LIKE '%situacao_hu_palete_item%'
   AND lower(COALESCE(pg_get_expr(i.indpred,i.indrelid,true),'')) LIKE '%vinculado%'
   AND lower(COALESCE(pg_get_expr(i.indpred,i.indrelid,true),'')) LIKE '%enviado_sap%'
   AND lower(COALESCE(pg_get_expr(i.indpred,i.indrelid,true),'')) LIKE '%confirmado_sap%';
 SELECT count(*) INTO v_idx_palete_caixa FROM pg_index i
 WHERE i.indrelid='desenvolvimento.hu_palete_item'::regclass AND i.indisunique AND i.indisvalid
   AND ARRAY(SELECT a.attname::text FROM unnest(i.indkey::smallint[]) WITH ORDINALITY k(attnum,ord)
             JOIN pg_attribute a ON a.attrelid=i.indrelid AND a.attnum=k.attnum WHERE k.attnum>0 ORDER BY k.ord)=ARRAY['codigo_hu_palete','codigo_hu_caixa']::text[]
   AND lower(COALESCE(pg_get_expr(i.indpred,i.indrelid,true),'')) LIKE '%situacao_hu_palete_item%';
 IF v_idx_caixa<>1 OR v_idx_palete_caixa<>1 THEN
   RAISE EXCEPTION 'VALIDACAO_045_UNICIDADE_PALETE_SEMANTICA_DIVERGENTE caixa=% palete_caixa=%',v_idx_caixa,v_idx_palete_caixa; END IF;

 -- PALETE_A + CAIXA_X = sucesso.
 v_id:=desenvolvimento.fn_pa_045_palete_vincular_caixa(-450001,-450001,1,v_user,v_a);
 IF v_id IS NULL THEN RAISE EXCEPTION 'VALIDACAO_045_PALETE_A_CAIXA_X_FALHOU'; END IF;
 RAISE NOTICE 'PALETE_A_CAIXA_X=SUCESSO';

 -- PALETE_B + mesma CAIXA_X = falha fisica de unicidade ativa.
 BEGIN
   PERFORM desenvolvimento.fn_pa_045_palete_vincular_caixa(-450002,-450001,1,v_user,v_b);
   RAISE EXCEPTION 'TESTE_PALETE_B_MESMA_CAIXA_X_NAO_BLOQUEOU';
 EXCEPTION WHEN unique_violation THEN NULL;
 END;
 RAISE NOTICE 'PALETE_B_MESMA_CAIXA_X=FALHA_ESPERADA';
 RAISE NOTICE 'CAIXA_DUPLICADA_PALETE=BLOQUEADA';

 -- PALETE_B + CAIXA_Y = sucesso.
 v_id:=desenvolvimento.fn_pa_045_palete_vincular_caixa(-450002,-450002,2,v_user,v_b);
 IF v_id IS NULL THEN RAISE EXCEPTION 'VALIDACAO_045_PALETE_B_CAIXA_Y_FALHOU'; END IF;
 RAISE NOTICE 'PALETE_B_CAIXA_Y=SUCESSO';
END
$gaia$;

-- Prova estrutural da obrigatoriedade de HU individual SAP.
DO $gaia$
DECLARE v_ck text; v_notnull boolean;
BEGIN
 SELECT pg_get_constraintdef(oid,true) INTO v_ck FROM pg_constraint
  WHERE conrelid='desenvolvimento.hu_caixa'::regclass AND conname='ck_hu_caixa_confirmacao_sap';
 SELECT attnotnull INTO v_notnull FROM pg_attribute WHERE attrelid='desenvolvimento.hu_palete_item'::regclass AND attname='handling_unit_external_id_caixa';
 IF position('handling_unit_external_id' in lower(COALESCE(v_ck,'')))=0 OR NOT COALESCE(v_notnull,false) THEN
   RAISE EXCEPTION 'VALIDACAO_045_HU_INDIVIDUAL_SAP_NAO_PROVADA'; END IF;
 RAISE NOTICE 'CAIXA_SEM_HU_NAO_PALETIZA=SIM';
 RAISE NOTICE 'HU_INDIVIDUAL_SAP_OBRIGATORIA=SIM';
END
$gaia$;

-- ============================================================================
-- D. REV4 - CLAIM DE ENVIO + RECOVERY POS-RESTART DO PALETE.
-- Unica tentativa HTTP externa modelada: POST_FORMACAO (FugaPET -> CPI INT012).
-- ============================================================================
DO $gaia$
DECLARE v_user bigint; v_a text; v_b text; v1 integer; v2 integer; v_claim_a uuid; v_claim_b uuid; v_tent integer; v_ok boolean; v_status text; v_retry boolean;
BEGIN
 SELECT codigo_usuario,terminal_a,terminal_b INTO v_user,v_a,v_b FROM tmp_045_contexto;
 SELECT count(*) INTO v1 FROM desenvolvimento.fn_pa_045_palete_claim_envio(-450001,'{"PackagingMaterial":"3000009"}'::jsonb,'CPI_INT012_FORMACAO_PALETE',v_user,v_a);
 SELECT count(*) INTO v2 FROM desenvolvimento.fn_pa_045_palete_claim_envio(-450001,'{"PackagingMaterial":"3000009"}'::jsonb,'CPI_INT012_FORMACAO_PALETE',v_user,v_b);
 IF v1<>1 OR v2<>0 THEN RAISE EXCEPTION 'VALIDACAO_045_CLAIM_PALETE_NAO_ATOMICO primeiro=% segundo=%',v1,v2; END IF;
 IF EXISTS(SELECT 1 FROM desenvolvimento.hu_palete WHERE codigo_hu_palete=-450001 AND status_sap IS NOT NULL) THEN
   RAISE EXCEPTION 'VALIDACAO_REV5_STATUS_SAP_INICIADO_HEADER_DEVERIA_NULL'; END IF;
 IF EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450001 AND tipo_operacao='POST_FORMACAO' AND resultado='INICIADO' AND status_sap IS NOT NULL) THEN
   RAISE EXCEPTION 'VALIDACAO_REV5_STATUS_SAP_INICIADO_HISTORICO_DEVERIA_NULL'; END IF;
 RAISE NOTICE 'STATUS_SAP_INICIADO_SEM_RESPOSTA_NULL=SIM';
 SELECT claim_token,tentativas INTO v_claim_a,v_tent FROM desenvolvimento.hu_palete WHERE codigo_hu_palete=-450001;
 -- Preserva prova REV3 de reassuncao do lease de envio ativo apos expiracao.
 UPDATE desenvolvimento.hu_palete SET claim_obtido_em=clock_timestamp()-interval '10 minutes',claim_expira_em=clock_timestamp()-interval '5 minutes'
  WHERE codigo_hu_palete=-450001 AND claim_token=v_claim_a;
 IF desenvolvimento.fn_pa_045_palete_registrar_timeout(-450001,v_tent,v_claim_a,'token expirado','CPI_INT012_FORMACAO_PALETE',v_user,v_a) THEN
   RAISE EXCEPTION 'VALIDACAO_045_PALETE_TOKEN_EXPIRADO_ALTEROU'; END IF;
 SELECT count(*) INTO v1 FROM desenvolvimento.fn_pa_045_palete_reassumir_claim(-450001,v_user,v_b);
 IF v1<>1 THEN RAISE EXCEPTION 'VALIDACAO_045_PALETE_NOVO_OWNER_NAO_REASSUMIU_ENVIO'; END IF;
 SELECT claim_token,tentativas INTO v_claim_b,v_tent FROM desenvolvimento.hu_palete WHERE codigo_hu_palete=-450001;
 IF v_claim_b=v_claim_a THEN RAISE EXCEPTION 'VALIDACAO_045_PALETE_REASSUNCAO_ENVIO_NAO_TROCOU_TOKEN'; END IF;
 IF NOT EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450001 AND tipo_operacao='CLAIM_REASSUMIDO' AND resultado='CLAIM_REASSUMIDO' AND status_sap IS NULL) THEN
   RAISE EXCEPTION 'VALIDACAO_REV5_CLAIM_REASSUMIDO_STATUS_SAP_NAO_NULL_OU_EVENTO_AUSENTE'; END IF;
 RAISE NOTICE 'CLAIM_REASSUMIDO_SEM_OVERFLOW_STATUS_SAP_NULL=SIM';
 IF desenvolvimento.fn_pa_045_palete_registrar_timeout(-450001,v_tent,v_claim_a,'owner antigo','CPI_INT012_FORMACAO_PALETE',v_user,v_a) THEN
   RAISE EXCEPTION 'VALIDACAO_045_PALETE_OWNER_ENVIO_ANTIGO_ALTEROU'; END IF;
 v_ok:=desenvolvimento.fn_pa_045_palete_registrar_timeout(-450001,v_tent,v_claim_b,'timeout palete controlado','CPI_INT012_FORMACAO_PALETE',v_user,v_b);
 IF NOT v_ok THEN RAISE EXCEPTION 'VALIDACAO_045_TIMEOUT_PALETE_OWNER_VIGENTE_FALHOU'; END IF;
 IF EXISTS(SELECT 1 FROM desenvolvimento.hu_palete WHERE codigo_hu_palete=-450001 AND status_sap IS NOT NULL) THEN RAISE EXCEPTION 'VALIDACAO_REV5_TIMEOUT_HEADER_STATUS_SAP_DEVERIA_NULL'; END IF;
 IF NOT EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450001 AND tipo_operacao='POST_FORMACAO' AND resultado='INDETERMINADO_TIMEOUT' AND status_sap IS NULL) THEN RAISE EXCEPTION 'VALIDACAO_REV5_TIMEOUT_HISTORICO_STATUS_SAP_NAO_NULL_OU_AUSENTE'; END IF;
 RAISE NOTICE 'TIMEOUT_PALETE_STATUS_SAP_NULL=SIM';
 INSERT INTO tmp_045_recovery(chave,claim_token,tentativa) VALUES('PALETE_ENVIO_B',v_claim_b,v_tent);
 SELECT status_hu_palete,pode_reprocessar INTO v_status,v_retry FROM desenvolvimento.hu_palete WHERE codigo_hu_palete=-450001;
 SELECT count(*) INTO v2 FROM desenvolvimento.fn_pa_045_palete_claim_envio(-450001,'{}'::jsonb,'CPI_INT012_FORMACAO_PALETE',v_user,v_a);
 IF v_status<>'INDETERMINADO_TIMEOUT' OR v_retry OR v2<>0 THEN RAISE EXCEPTION 'VALIDACAO_045_RETRY_CEGO_PALETE_NAO_BLOQUEADO'; END IF;
END
$gaia$;

-- Nova sessao runtime nao le claim de envio e recebe apenas recovery B.
SET LOCAL ROLE fugapet_dev_app;
DO $gaia$
DECLARE v_user bigint; v_b text; v_r uuid; v_tent integer; v_qtd integer; v_cols integer;
BEGIN
 SELECT codigo_usuario,terminal_b INTO v_user,v_b FROM tmp_045_contexto;
 PERFORM 1 FROM desenvolvimento.vw_pa_045_palete_estado_runtime WHERE codigo_hu_palete=-450001;
 IF has_table_privilege(current_user,'desenvolvimento.hu_palete','SELECT') OR has_table_privilege(current_user,'desenvolvimento.hu_palete_integracao_sap','SELECT') THEN
   RAISE EXCEPTION 'VALIDACAO_045_RUNTIME_LE_TOKEN_PALETE'; END IF;
 SELECT count(*) INTO v_cols FROM information_schema.columns WHERE table_schema='desenvolvimento'
   AND table_name IN ('vw_pa_045_palete_estado_runtime','vw_pa_045_palete_integracao_runtime')
   AND column_name IN ('claim_token','claim_token_efetivo','recovery_claim_token');
 IF v_cols<>0 THEN RAISE EXCEPTION 'VALIDACAO_045_VIEW_PALETE_EXPOE_RECOVERY_TOKEN'; END IF;
 SELECT recovery_claim_token,tentativa INTO v_r,v_tent
  FROM desenvolvimento.fn_pa_045_palete_adquirir_recovery(-450001,v_user,v_b);
 IF v_r IS NULL THEN RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_PALETE_B_NAO_ADQUIRIDO'; END IF;
 INSERT INTO tmp_045_recovery(chave,claim_token,tentativa) VALUES('PALETE_RECOVERY_B',v_r,v_tent);
 SELECT count(*) INTO v_qtd FROM desenvolvimento.fn_pa_045_palete_adquirir_recovery(-450001,v_user,(SELECT terminal_c FROM tmp_045_contexto));
 IF v_qtd<>0 THEN RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_PALETE_NAO_EXCLUSIVO'; END IF;
END
$gaia$;
RESET ROLE;

DO $gaia$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450001 AND tipo_operacao='RECOVERY_CLAIM_ADQUIRIDO' AND status_sap IS NULL) THEN RAISE EXCEPTION 'VALIDACAO_REV5_RECOVERY_ADQUIRIDO_STATUS_SAP_NAO_NULL_OU_AUSENTE'; END IF;
 RAISE NOTICE 'RECOVERY_CLAIM_ADQUIRIDO_SEM_OVERFLOW_STATUS_SAP_NULL=SIM';
END $gaia$;

DO $gaia$
DECLARE v_user bigint; v_b text; v_send uuid; v_r uuid; v_tent integer; v_posts integer;
BEGIN
 SELECT codigo_usuario,terminal_b INTO v_user,v_b FROM tmp_045_contexto;
 SELECT claim_token,tentativa INTO v_send,v_tent FROM tmp_045_recovery WHERE chave='PALETE_ENVIO_B';
 SELECT claim_token INTO v_r FROM tmp_045_recovery WHERE chave='PALETE_RECOVERY_B';
 IF desenvolvimento.fn_pa_045_palete_registrar_reconciliacao(-450001,v_tent,gen_random_uuid(),'CONFIRMADO_NAO_EXISTE',NULL,
       '{"criterio":"deterministico","encontrado":false}'::jsonb,'aleatorio',v_user,v_b) THEN
   RAISE EXCEPTION 'VALIDACAO_045_TOKEN_ALEATORIO_RECONCILIOU_PALETE'; END IF;
 IF desenvolvimento.fn_pa_045_palete_registrar_reconciliacao(-450001,v_tent,v_send,'CONFIRMADO_NAO_EXISTE',NULL,
       '{"criterio":"deterministico","encontrado":false}'::jsonb,'claim envio aposentado',v_user,v_b) THEN
   RAISE EXCEPTION 'VALIDACAO_045_CLAIM_ENVIO_RECONCILIOU_PALETE'; END IF;
 SELECT count(*) INTO v_posts FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450001 AND tipo_operacao='POST_FORMACAO';
 IF v_posts<>2 THEN RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_GEROU_POST_FORMACAO_EXTRA qtd=%',v_posts; END IF;
END
$gaia$;

-- B cai; apos expiracao somente C reassume recovery.
UPDATE desenvolvimento.hu_palete SET recovery_claim_obtido_em=clock_timestamp()-interval '10 minutes',
       recovery_claim_expira_em=clock_timestamp()-interval '5 minutes'
 WHERE codigo_hu_palete=-450001 AND recovery_claim_token=(SELECT claim_token FROM tmp_045_recovery WHERE chave='PALETE_RECOVERY_B');

SET LOCAL ROLE fugapet_dev_app;
DO $gaia$
DECLARE v_user bigint; v_c text; v_r uuid; v_tent integer;
BEGIN
 SELECT codigo_usuario,terminal_d INTO v_user,v_c FROM tmp_045_contexto;
 SELECT recovery_claim_token,tentativa INTO v_r,v_tent FROM desenvolvimento.fn_pa_045_palete_adquirir_recovery(-450001,v_user,v_c);
 IF v_r IS NULL OR v_r=(SELECT claim_token FROM tmp_045_recovery WHERE chave='PALETE_RECOVERY_B') THEN
   RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_PALETE_C_NAO_REASSUMIU'; END IF;
 INSERT INTO tmp_045_recovery(chave,claim_token,tentativa) VALUES('PALETE_RECOVERY_C',v_r,v_tent);
END
$gaia$;
RESET ROLE;

DO $gaia$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450001 AND tipo_operacao='RECOVERY_CLAIM_REASSUMIDO' AND status_sap IS NULL) THEN RAISE EXCEPTION 'VALIDACAO_REV5_RECOVERY_REASSUMIDO_STATUS_SAP_NAO_NULL_OU_AUSENTE'; END IF;
 RAISE NOTICE 'RECOVERY_CLAIM_REASSUMIDO_SEM_OVERFLOW_STATUS_SAP_NULL=SIM';
END $gaia$;

DO $gaia$
DECLARE v_user bigint; v_c text; v_b uuid; v_c_token uuid; v_tent integer; v_posts_before integer; v_posts_after integer; v1 integer; v_claim2 uuid; v_tent2 integer; v_hist integer;
BEGIN
 SELECT codigo_usuario,terminal_d INTO v_user,v_c FROM tmp_045_contexto;
 SELECT claim_token,tentativa INTO v_b,v_tent FROM tmp_045_recovery WHERE chave='PALETE_RECOVERY_B';
 SELECT claim_token INTO v_c_token FROM tmp_045_recovery WHERE chave='PALETE_RECOVERY_C';
 IF desenvolvimento.fn_pa_045_palete_registrar_reconciliacao(-450001,v_tent,v_b,'CONFIRMADO_NAO_EXISTE',NULL,
       '{"criterio":"deterministico","encontrado":false}'::jsonb,'recovery B expirado',v_user,v_c) THEN
   RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_PALETE_B_ANTIGO_RECONCILIOU'; END IF;
 SELECT count(*) INTO v_posts_before FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450001 AND tipo_operacao='POST_FORMACAO';
 IF NOT desenvolvimento.fn_pa_045_palete_registrar_reconciliacao(-450001,v_tent,v_c_token,'CONFIRMADO_NAO_EXISTE',NULL,
       '{"criterio":"deterministico","encontrado":false}'::jsonb,'HU pai nao encontrada',v_user,v_c) THEN
   RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_PALETE_C_NAO_RECONCILIOU'; END IF;
 SELECT count(*) INTO v_posts_after FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450001 AND tipo_operacao='POST_FORMACAO';
 IF v_posts_after<>v_posts_before THEN RAISE EXCEPTION 'VALIDACAO_045_RECOVERY_EXECUTOU_POST_PALETE'; END IF;
 IF EXISTS(SELECT 1 FROM desenvolvimento.hu_palete WHERE codigo_hu_palete=-450001 AND status_sap IS NOT NULL) THEN RAISE EXCEPTION 'VALIDACAO_REV5_RECONCILIACAO_HEADER_STATUS_SAP_DEVERIA_NULL'; END IF;
 IF NOT EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450001 AND tipo_operacao='RECONCILIACAO' AND resultado='CONFIRMADO_NAO_EXISTE' AND claim_token=v_c_token AND status_sap IS NULL) THEN RAISE EXCEPTION 'VALIDACAO_REV5_RECONCILIACAO_HISTORICO_STATUS_SAP_NAO_NULL_OU_AUSENTE'; END IF;
 RAISE NOTICE 'RECONCILIACAO_LOCAL_STATUS_SAP_NULL=SIM';
 IF NOT desenvolvimento.fn_pa_045_palete_liberar_reprocessamento(-450001,v_c_token,'POS_RECONCILIACAO_NAO_ENCONTRADO',
       'liberacao controlada apos recovery deterministico do palete',v_user,v_c) THEN RAISE EXCEPTION 'VALIDACAO_045_LIBERACAO_PALETE_FALHOU'; END IF;
 IF NOT EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450001 AND tipo_operacao='LIBERACAO_REPROCESSAMENTO' AND status_sap IS NULL) THEN RAISE EXCEPTION 'VALIDACAO_REV5_LIBERACAO_STATUS_SAP_NAO_NULL_OU_AUSENTE'; END IF;
 RAISE NOTICE 'LIBERACAO_REPROCESSAMENTO_STATUS_SAP_NULL=SIM';
 SELECT count(*) INTO v1 FROM desenvolvimento.fn_pa_045_palete_claim_envio(-450001,'{"PackagingMaterial":"3000009"}'::jsonb,'CPI_INT012_FORMACAO_PALETE',v_user,v_c);
 SELECT claim_token,tentativas INTO v_claim2,v_tent2 FROM desenvolvimento.hu_palete WHERE codigo_hu_palete=-450001;
 IF v1<>1 OR v_tent2<>2 THEN RAISE EXCEPTION 'VALIDACAO_045_PALETE_TENTATIVA_2_FALHOU tentativa=%',v_tent2; END IF;
 IF NOT desenvolvimento.fn_pa_045_palete_registrar_sucesso(-450001,v_tent2,v_claim2,'900045PAL01',201,
       '{"HandlingUnitExternalID":"900045PAL01"}'::jsonb,'CPI_INT012_FORMACAO_PALETE',v_user,v_c) THEN
   RAISE EXCEPTION 'VALIDACAO_045_SUCESSO_POST_FORMACAO_FALHOU'; END IF;
 IF NOT EXISTS(SELECT 1 FROM desenvolvimento.hu_palete WHERE codigo_hu_palete=-450001 AND status_sap='CONFIRMADO') THEN RAISE EXCEPTION 'VALIDACAO_REV5_SUCESSO_EXTERNO_STATUS_SAP_AUSENTE'; END IF;
 IF NOT EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450001 AND tipo_operacao='POST_FORMACAO' AND resultado='CONFIRMADO' AND status_sap='CONFIRMADO' AND status_http BETWEEN 200 AND 299) THEN RAISE EXCEPTION 'VALIDACAO_REV5_HISTORICO_SUCESSO_EXTERNO_STATUS_SAP_INVALIDO'; END IF;
 RAISE NOTICE 'STATUS_SAP_EXTERNO_CONFIRMADO_PERMITIDO=SIM';
 SELECT count(*) INTO v_hist FROM desenvolvimento.hu_palete_integracao_sap
  WHERE codigo_hu_palete=-450001 AND (
    (tipo_operacao='RECOVERY_CLAIM_ADQUIRIDO' AND claim_token=v_b)
    OR (tipo_operacao='RECOVERY_CLAIM_REASSUMIDO' AND claim_token=v_c_token)
    OR (tipo_operacao='RECONCILIACAO' AND claim_token=v_c_token));
 IF v_hist<>3 THEN RAISE EXCEPTION 'VALIDACAO_045_HISTORICO_RECOVERY_PALETE_INCOMPLETO qtd=%/3',v_hist; END IF;
 IF EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450001 AND metodo_http<>'POST' AND tipo_operacao='POST_FORMACAO') THEN
   RAISE EXCEPTION 'VALIDACAO_045_POST_FORMACAO_METODO_DIVERGENTE'; END IF;
 IF EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450001 AND metodo_http='POST' AND tipo_operacao<>'POST_FORMACAO') THEN
   RAISE EXCEPTION 'VALIDACAO_045_OPERACAO_INTERNA_MODELADA_COMO_HTTP_EXTERNO'; END IF;
 RAISE NOTICE 'CLAIM_ATOMICO_PALETE=SIM';
 RAISE NOTICE 'CLAIM_OWNERSHIP_PALETE=SIM';
 RAISE NOTICE 'RECOVERY_PALETE_APOS_RESTART=IMPLEMENTADO';
 RAISE NOTICE 'RECOVERY_PALETE_LEASE_EXCLUSIVO=SIM';
 RAISE NOTICE 'REASSUNCAO_RECOVERY_PALETE_APOS_EXPIRACAO=SIM';
 RAISE NOTICE 'RECOVERY_PALETE_NAO_INCREMENTA_TENTATIVA_HTTP=SIM';
 RAISE NOTICE 'RECOVERY_PALETE_NAO_EXECUTA_POST=SIM';
 RAISE NOTICE 'HISTORICO_RECOVERY_PALETE_APPEND_ONLY=SIM';
 RAISE NOTICE 'TIMEOUT_PALETE_INDETERMINADO=SIM';
 RAISE NOTICE 'RETRY_CEGO_PALETE_BLOQUEADO=SIM';
 RAISE NOTICE 'PALETE_HTTP_EXTERNO_SOMENTE_POST_FORMACAO=SIM';
END
$gaia$;

-- REV5: regressao semantica status_sap em erro externo e em todos eventos locais de palete.
DO $gaia$
DECLARE v_user bigint; v_term text; v_qtd integer; v_claim uuid; v_tent integer; v_ok boolean;
BEGIN
 SELECT codigo_usuario,terminal_b INTO v_user,v_term FROM tmp_045_contexto;
 SELECT count(*) INTO v_qtd FROM desenvolvimento.fn_pa_045_palete_claim_envio(-450002,'{"PackagingMaterial":"3000009"}'::jsonb,'CPI_INT012_FORMACAO_PALETE',v_user,v_term);
 IF v_qtd<>1 THEN RAISE EXCEPTION 'VALIDACAO_REV5_ERRO_EXTERNO_CLAIM_FALHOU'; END IF;
 SELECT claim_token,tentativas INTO v_claim,v_tent FROM desenvolvimento.hu_palete WHERE codigo_hu_palete=-450002;
 v_ok:=desenvolvimento.fn_pa_045_palete_registrar_erro(-450002,v_tent,v_claim,500,'{"error":"controlado"}'::jsonb,'erro externo controlado','CPI_INT012_FORMACAO_PALETE',v_user,v_term);
 IF NOT v_ok THEN RAISE EXCEPTION 'VALIDACAO_REV5_ERRO_EXTERNO_REGISTRO_FALHOU'; END IF;
 IF NOT EXISTS(SELECT 1 FROM desenvolvimento.hu_palete WHERE codigo_hu_palete=-450002 AND status_sap='ERRO' AND status_http=500) THEN RAISE EXCEPTION 'VALIDACAO_REV5_ERRO_EXTERNO_HEADER_STATUS_SAP_INVALIDO'; END IF;
 IF NOT EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete=-450002 AND tipo_operacao='POST_FORMACAO' AND resultado='ERRO' AND status_sap='ERRO' AND status_http=500) THEN RAISE EXCEPTION 'VALIDACAO_REV5_ERRO_EXTERNO_HISTORICO_STATUS_SAP_INVALIDO'; END IF;
 IF EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete IN (-450001,-450002) AND metodo_http='LOCAL' AND status_sap IS NOT NULL) THEN RAISE EXCEPTION 'VALIDACAO_REV5_EVENTO_LOCAL_COM_STATUS_SAP'; END IF;
 IF EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete IN (-450001,-450002) AND status_sap IS NOT NULL AND char_length(status_sap)>10) THEN RAISE EXCEPTION 'VALIDACAO_REV5_STATUS_SAP_OVERFLOW_PERSISTIDO'; END IF;
 IF EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_integracao_sap WHERE codigo_hu_palete IN (-450001,-450002) AND status_sap IS NOT NULL AND NOT (metodo_http='POST' AND tipo_operacao='POST_FORMACAO' AND ((status_sap='CONFIRMADO' AND status_http BETWEEN 200 AND 299) OR (status_sap='ERRO' AND status_http IS NOT NULL AND status_http NOT BETWEEN 200 AND 299)))) THEN RAISE EXCEPTION 'VALIDACAO_REV5_STATUS_SAP_NAO_TEM_ORIGEM_EXTERNA_PERMITIDA'; END IF;
 RAISE NOTICE 'STATUS_SAP_EXTERNO_ERRO_PERMITIDO=SIM';
 RAISE NOTICE 'EVENTOS_LOCAIS_PALETE_STATUS_SAP_NULL=SIM';
 RAISE NOTICE 'CHECK_LENGTH_STATUS_SAP_RUNTIME=APROVADO';
 RAISE NOTICE 'CHECK_SEMANTICA_STATUS_SAP_RUNTIME=APROVADO';
END
$gaia$;

DO $gaia$
BEGIN
 BEGIN
   UPDATE desenvolvimento.hu_palete_integracao_sap
      SET mensagem_erro='alteracao proibida'
    WHERE codigo_hu_palete_integracao_sap=(SELECT codigo_hu_palete_integracao_sap FROM desenvolvimento.hu_palete_integracao_sap ORDER BY codigo_hu_palete_integracao_sap LIMIT 1);
   RAISE EXCEPTION 'TESTE_HISTORICO_PALETE_MUTAVEL';
 EXCEPTION WHEN raise_exception THEN
   IF SQLERRM NOT LIKE '%PA045_HISTORICO_PALETE_APPEND_ONLY%' THEN RAISE; END IF;
 END;
 BEGIN
   UPDATE desenvolvimento.hu_caixa_etapa_sap_tentativa
      SET terminal_operacao='ALTERACAO_PROIBIDA'
    WHERE codigo_hu_caixa_etapa_sap_tentativa=(SELECT codigo_hu_caixa_etapa_sap_tentativa FROM desenvolvimento.hu_caixa_etapa_sap_tentativa LIMIT 1);
   RAISE EXCEPTION 'TESTE_HISTORICO_ETAPA_MUTAVEL';
 EXCEPTION WHEN raise_exception THEN
   IF SQLERRM NOT LIKE '%PA045_HISTORICO_APPEND_ONLY%' THEN RAISE; END IF;
 END;
 BEGIN
   UPDATE desenvolvimento.hu_palete SET material_embalagem='9999999' WHERE codigo_hu_palete=-450001;
   RAISE EXCEPTION 'TESTE_PALETE_CONFIRMADO_MUTAVEL';
 EXCEPTION WHEN raise_exception THEN
   IF SQLERRM NOT LIKE '%PA045_PALETE_CONFIRMADO_IMUTAVEL%' THEN RAISE; END IF;
 END;
 RAISE NOTICE 'HISTORICO_APPEND_ONLY=SIM';
 RAISE NOTICE 'HU_PALETE_CONFIRMADA_SAP_IMUTAVEL=SIM';
END
$gaia$;

-- FK RESTRICT e view final.
DO $gaia$
DECLARE v_fk integer; vdef text;
BEGIN
 SELECT count(*) INTO v_fk FROM pg_constraint c
  WHERE c.connamespace=to_regnamespace('desenvolvimento')
    AND c.conname IN ('hu_palete_item_codigo_hu_palete_fkey','hu_palete_integracao_sap_codigo_hu_palete_fkey','hu_palete_etiqueta_codigo_hu_palete_fkey')
    AND c.confdeltype='r';
 IF v_fk<>3 THEN RAISE EXCEPTION 'VALIDACAO_045_DELETE_PALETE_NAO_RESTRICT quantidade=%',v_fk; END IF;
 vdef:=lower(pg_get_viewdef('desenvolvimento.vw_hu_caixas_sem_palete'::regclass,true));
 IF position('confirmada_sap' in vdef)=0 OR position('handling_unit_external_id' in vdef)=0
    OR position('etiquetada' in vdef)>0 OR position('enviada_sap' in vdef)>0 THEN
   RAISE EXCEPTION 'VALIDACAO_045_VIEW_ELEGIBILIDADE_DIVERGENTE'; END IF;
 IF (SELECT count(*) FROM desenvolvimento.vw_hu_caixas_sem_palete) <> (
      SELECT count(*) FROM desenvolvimento.hu_caixa hc
       WHERE hc.situacao_hu_caixa AND hc.status_hu_caixa='CONFIRMADA_SAP'
         AND hc.handling_unit_external_id IS NOT NULL
         AND NOT EXISTS (SELECT 1 FROM desenvolvimento.hu_palete_item hpi
                          WHERE hpi.codigo_hu_caixa=hc.codigo_hu_caixa AND hpi.situacao_hu_palete_item
                            AND hpi.status_vinculo IN ('VINCULADO','ENVIADO_SAP','CONFIRMADO_SAP'))) THEN
   RAISE EXCEPTION 'VALIDACAO_045_VIEW_CARDINALIDADE_INDEVIDA'; END IF;
 RAISE NOTICE 'DELETE_PALETE_RESTRICT=SIM';
 RAISE NOTICE 'VIEW_PALETE_SOMENTE_CAIXA_CONFIRMADA_COM_HU=SIM';
 RAISE NOTICE 'VIEW_PALETE_CARDINALIDADE_COERENTE=SIM';
END
$gaia$;

-- ACL REV3: runtime sem DML/SELECT de capability; PUBLIC sem EXECUTE; 19 funcoes controladas.
DO $gaia$
DECLARE v_dml integer; v_public integer; v_exec integer; v_fn044 integer; v_trg044 integer; v_token_sel integer; v_view_sel integer; v_claim_cols integer;
BEGIN
 SELECT count(*) INTO v_dml FROM (VALUES
   ('desenvolvimento.hu_caixa_etapa_sap'),('desenvolvimento.hu_caixa_etapa_sap_tentativa'),('desenvolvimento.hu_caixa_etapa_sap_evento'),
   ('desenvolvimento.hu_palete'),('desenvolvimento.hu_palete_item'),('desenvolvimento.hu_palete_integracao_sap'),('desenvolvimento.hu_palete_etiqueta')
 ) x(tabela)
 WHERE has_table_privilege('fugapet_dev_app',x.tabela,'INSERT') OR has_table_privilege('fugapet_dev_app',x.tabela,'UPDATE')
    OR has_table_privilege('fugapet_dev_app',x.tabela,'DELETE') OR has_table_privilege('fugapet_dev_app',x.tabela,'TRUNCATE');

 SELECT count(*) INTO v_public
 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
 JOIN LATERAL aclexplode(COALESCE(p.proacl,acldefault('f',p.proowner))) a ON true
 WHERE n.nspname='desenvolvimento' AND p.proname LIKE 'fn_pa_045_%'
   AND a.grantee=0 AND a.privilege_type='EXECUTE';

 SELECT count(*) INTO v_exec FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
 WHERE n.nspname='desenvolvimento' AND p.proname LIKE 'fn_pa_045_%'
   AND has_function_privilege('fugapet_dev_app',p.oid,'EXECUTE');

 SELECT count(*) INTO v_fn044 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
 WHERE n.nspname='desenvolvimento' AND p.proname LIKE 'fn_hu_%';
 SELECT count(*) INTO v_trg044 FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace
 WHERE NOT t.tgisinternal AND n.nspname='desenvolvimento'
   AND c.relname IN ('hu_caixa','hu_caixa_pesagem','hu_caixa_integracao_sap','hu_caixa_etiqueta',
                     'hu_palete','hu_palete_item','hu_palete_integracao_sap','hu_palete_etiqueta')
   AND t.tgname NOT LIKE 'trg_045_%';

 SELECT count(*) INTO v_token_sel FROM (VALUES
   ('desenvolvimento.hu_caixa_etapa_sap'),('desenvolvimento.hu_caixa_etapa_sap_tentativa'),('desenvolvimento.hu_caixa_etapa_sap_evento'),
   ('desenvolvimento.hu_palete'),('desenvolvimento.hu_palete_integracao_sap')
 ) x(tabela) WHERE has_table_privilege('fugapet_dev_app',x.tabela,'SELECT');
 SELECT count(*) INTO v_view_sel FROM (VALUES
   ('desenvolvimento.vw_pa_045_etapa_estado_runtime'),('desenvolvimento.vw_pa_045_etapa_tentativa_runtime'),('desenvolvimento.vw_pa_045_etapa_evento_runtime'),
   ('desenvolvimento.vw_pa_045_palete_estado_runtime'),('desenvolvimento.vw_pa_045_palete_integracao_runtime')
 ) x(objeto) WHERE has_table_privilege('fugapet_dev_app',x.objeto,'SELECT');
 SELECT count(*) INTO v_claim_cols FROM information_schema.columns WHERE table_schema='desenvolvimento'
   AND table_name IN ('vw_pa_045_etapa_estado_runtime','vw_pa_045_etapa_tentativa_runtime','vw_pa_045_etapa_evento_runtime',
                      'vw_pa_045_palete_estado_runtime','vw_pa_045_palete_integracao_runtime')
   AND column_name IN ('claim_token','claim_token_efetivo','recovery_claim_token');
 IF v_dml<>0 OR v_public<>0 OR v_exec<>21 OR v_fn044<>20 OR v_trg044<>22 OR v_token_sel<>0 OR v_view_sel<>5 OR v_claim_cols<>0 THEN
   RAISE EXCEPTION 'VALIDACAO_045_ACL_OU_044_FALHOU dml=% public=% exec=%/21 fn044=%/20 trg044=%/22 token_sel=%/0 views=%/5 claim_cols=%/0',v_dml,v_public,v_exec,v_fn044,v_trg044,v_token_sel,v_view_sel,v_claim_cols;
 END IF;
 RAISE NOTICE 'RUNTIME_SEM_DML_DIRETO=SIM';
 RAISE NOTICE 'RUNTIME_LE_CLAIM_TOKEN_ATIVO=NAO';
 RAISE NOTICE 'PALETE_TOKEN_EXPOSURE=CORRIGIDO';
 RAISE NOTICE 'PUBLIC_EXECUTE_045=ZERO';
 RAISE NOTICE 'FUNCOES_044_EXISTENTES=INALTERADAS';
 RAISE NOTICE 'TRIGGERS_044_EXISTENTES=INALTERADOS';
END
$gaia$;

-- Comprova que a role efetivamente pode chamar a API controlada sem receber DML direto.
SET LOCAL ROLE fugapet_dev_app;
SELECT count(*) AS etapas_visiveis_runtime FROM desenvolvimento.vw_pa_045_etapa_estado_runtime WHERE codigo_hu_caixa IN (-450001,-450003);
SELECT count(*) AS historico_visivel_runtime FROM desenvolvimento.vw_pa_045_etapa_tentativa_runtime;
RESET ROLE;


-- Palete: recovery read-only permanece disponivel sem capability secreta.
SET LOCAL ROLE fugapet_dev_app;
SELECT codigo_hu_palete,status_hu_palete,tentativas,correlation_id,lease_expira_em,status_reconciliacao,status_http
FROM desenvolvimento.vw_pa_045_palete_estado_runtime WHERE codigo_hu_palete=-450001;
SELECT count(*) AS colunas_token_palete_expostas
FROM information_schema.columns WHERE table_schema='desenvolvimento'
 AND table_name IN ('vw_pa_045_palete_estado_runtime','vw_pa_045_palete_integracao_runtime')
 AND column_name IN ('claim_token','claim_token_efetivo','recovery_claim_token');
RESET ROLE;

-- ==========================================================================
-- SEQUENCES DEPOIS / DELTA / CLASSIFICACAO
-- Nao exige delta zero; avanco em sequence alvo e nao transacional.
-- ==========================================================================
DO $gaia$
DECLARE r record; v_last bigint; v_called boolean;
BEGIN
 FOR r IN SELECT sequence_name FROM tmp_045_sequences ORDER BY sequence_name LOOP
   EXECUTE format('SELECT last_value,is_called FROM %s',r.sequence_name) INTO v_last,v_called;
   UPDATE tmp_045_sequences
      SET valor_depois=v_last,is_called_depois=v_called,
          delta=v_last-valor_antes,
          classificacao=CASE
             WHEN v_last<valor_antes THEN 'DELTA_INCOMPATIVEL_RECUO'
             WHEN v_last>valor_antes THEN 'AVANCO_NAO_TRANSACIONAL_ESPERADO'
             WHEN NOT is_called_antes AND v_called THEN 'AVANCO_NAO_TRANSACIONAL_ESPERADO_PRIMEIRO_USO'
             ELSE 'SEM_AVANCO'
          END
    WHERE sequence_name=r.sequence_name;
 END LOOP;
 IF EXISTS(SELECT 1 FROM tmp_045_sequences WHERE classificacao LIKE 'DELTA_INCOMPATIVEL%') THEN
   RAISE EXCEPTION 'VALIDACAO_045_SEQUENCE_DELTA_INCOMPATIVEL';
 END IF;
END
$gaia$;

\echo '=== SEQUENCES_DEPOIS_DELTA ==='
SELECT sequence_name AS sequence,valor_antes,is_called_antes,valor_depois,is_called_depois,delta,classificacao
FROM tmp_045_sequences ORDER BY sequence_name;

DO $gaia$ BEGIN
 RAISE NOTICE 'SEQUENCES_CAPTURADAS_ANTES_DEPOIS=SIM';
 RAISE NOTICE 'SEQUENCE_DELTA_ZERO_NAO_EXIGIDO=SIM';
 RAISE NOTICE 'SEQUENCE_AVANCO_NAO_TRANSACIONAL_CLASSIFICADO=SIM';
END $gaia$;

DO $gaia$
BEGIN
 RAISE NOTICE 'CLASSIFICACAO_OFICIAL=VALIDACAO_045_REV5_DEV_CONCLUIDA_COM_SUCESSO_E_ROLLBACK_PENDENTE';
 RAISE NOTICE '261_CONFIRMADO_LIBERA_101=SIM';
 RAISE NOTICE '261_NAO_CONFIRMADO_BLOQUEIA_101=SIM';
 RAISE NOTICE '101_CONFIRMADO_LIBERA_HU=SIM';
 RAISE NOTICE '101_NAO_CONFIRMADO_BLOQUEIA_HU=SIM';
 RAISE NOTICE 'LEGADO_044_NAO_REGREDIU=SIM';
 RAISE NOTICE 'CLAIM_ATOMICO_261=SIM';
 RAISE NOTICE 'CLAIM_ATOMICO_101=SIM';
 RAISE NOTICE 'CLAIM_OWNERSHIP_ETAPA=SIM';
 RAISE NOTICE 'RUNTIME_LE_CLAIM_TOKEN_ATIVO=NAO';
 RAISE NOTICE 'CLAIM_CAPABILITY=IMPLEMENTADA';
 RAISE NOTICE 'OWNERSHIP_MULTI_TERMINAL=IMPLEMENTADO';
 RAISE NOTICE 'REASSUNCAO_APPEND_ONLY_261_101=IMPLEMENTADA';
 RAISE NOTICE 'RESULTADO_IDENTIFICA_CLAIM_VIGENTE=SIM';
 RAISE NOTICE 'CLAIM_ORIGINAL_IMUTAVEL=SIM';
 RAISE NOTICE 'PALETE_TOKEN_EXPOSURE=CORRIGIDO';
 RAISE NOTICE 'TOKEN_INCORRETO_NAO_FINALIZA=SIM';
 RAISE NOTICE 'TOKEN_EXPIRADO_NAO_FINALIZA=SIM';
 RAISE NOTICE 'NOVO_OWNER_REASSUME_APOS_EXPIRACAO=SIM';
 RAISE NOTICE 'OWNER_ANTIGO_NAO_ALTERA_APOS_REASSUNCAO=SIM';
 RAISE NOTICE 'OWNER_VIGENTE_CONCLUI=SIM';
 RAISE NOTICE 'CLAIM_OWNERSHIP_PALETE=SIM';
 RAISE NOTICE 'PALETE_A_CAIXA_X=SUCESSO';
 RAISE NOTICE 'PALETE_B_MESMA_CAIXA_X=FALHA_ESPERADA';
 RAISE NOTICE 'PALETE_B_CAIXA_Y=SUCESSO';
 RAISE NOTICE 'PALETE_HTTP_EXTERNO_SOMENTE_POST_FORMACAO=SIM';
 RAISE NOTICE 'RECOVERY_261_101_APOS_RESTART=IMPLEMENTADO';
 RAISE NOTICE 'RECOVERY_PALETE_APOS_RESTART=IMPLEMENTADO';
 RAISE NOTICE 'RUNTIME_LE_TOKEN_ANTIGO=NAO';
 RAISE NOTICE 'RECOVERY_GERA_NOVA_CAPABILITY=SIM';
 RAISE NOTICE 'RECOVERY_INCREMENTA_TENTATIVA_HTTP=NAO';
 RAISE NOTICE 'RECOVERY_EXECUTA_POST=NAO';
 RAISE NOTICE 'RECOVERY_LEASE_EXCLUSIVO=SIM';
 RAISE NOTICE 'REASSUNCAO_RECOVERY_APOS_EXPIRACAO=SIM';
 RAISE NOTICE 'HISTORICO_RECOVERY_APPEND_ONLY=SIM';
 RAISE NOTICE 'SEQUENCES_CAPTURADAS_ANTES_DEPOIS=SIM';
 RAISE NOTICE 'TENTATIVA_UNICA=SIM';
 RAISE NOTICE 'TIMEOUT_INDETERMINADO=SIM';
 RAISE NOTICE 'RETRY_CEGO_BLOQUEADO=SIM';
 RAISE NOTICE 'MATERIAL_DOCUMENT_261_PERSISTIVEL=SIM';
 RAISE NOTICE 'MATERIAL_DOCUMENT_101_PERSISTIVEL=SIM';
 RAISE NOTICE 'CAIXA_NAO_CONFIRMADA_NAO_PALETIZA=SIM';
 RAISE NOTICE 'CAIXA_SEM_HU_NAO_PALETIZA=SIM';
 RAISE NOTICE 'CAIXA_DUPLICADA_PALETE=BLOQUEADA';
 RAISE NOTICE 'DELETE_PALETE_RESTRICT=SIM';
 RAISE NOTICE 'HISTORICO_APPEND_ONLY=SIM';
 RAISE NOTICE 'RUNTIME_SEM_DML_DIRETO=SIM';
 RAISE NOTICE 'STATUS_SAP_COLUNA_ALTERADA=NAO';
 RAISE NOTICE 'EVENTOS_LOCAIS_PALETE_STATUS_SAP_NULL=SIM';
 RAISE NOTICE 'CHECK_LENGTH_STATUS_SAP_RUNTIME=APROVADO';
 RAISE NOTICE 'CHECK_SEMANTICA_STATUS_SAP_RUNTIME=APROVADO';
 RAISE NOTICE 'SAP_ACESSADO=NAO';
END
$gaia$;

ROLLBACK;
\echo 'CLASSIFICACAO_OFICIAL=VALIDACAO_045_REV5_DEV_CONCLUIDA_COM_ROLLBACK'
\echo 'DADOS_PERSISTIDOS=NAO'
\echo 'SAP_ACESSADO=NAO'
\echo 'AVISO_SEQUENCE=VALORES_ANTES_DEPOIS_DELTA_E_CLASSIFICACAO_SAO_EMITIDOS;DELTA_ZERO_NAO_E_REQUISITO'
