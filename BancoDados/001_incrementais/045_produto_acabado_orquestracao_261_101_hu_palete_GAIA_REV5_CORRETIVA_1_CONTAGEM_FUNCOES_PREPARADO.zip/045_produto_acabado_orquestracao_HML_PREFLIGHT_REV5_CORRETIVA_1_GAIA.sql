\set ON_ERROR_STOP on
\pset pager off
\pset tuples_only off
\pset format aligned
\pset null '<NULL>'

-- FugaPET - Incremental 045 REV5 - HML - PREFLIGHT CORRETIVA RUNTIME STATUS PALETE
-- Estado esperado: REV4 aplicado; REV5 ainda nao aplicada. READ ONLY; final ROLLBACK.
\echo 'CLASSIFICACAO_DOCUMENTAL=PREFLIGHT_045_REV5_HML_PREPARADO_NAO_EXECUTADO'
BEGIN;
SET TRANSACTION READ ONLY;
SET LOCAL search_path TO homologacao, pg_catalog;
SET LOCAL statement_timeout='5min';
SET LOCAL lock_timeout='5s';

\echo '=== 01_AMBIENTE ==='
SELECT current_database() AS current_database,current_user AS current_user,session_user AS session_user,
       current_setting('server_version') AS server_version,current_setting('server_version_num')::integer AS server_version_num,
       current_schema() AS current_schema,to_regrole('fugapet_hml_app') AS runtime;

DO $gaia$
DECLARE vver integer:=current_setting('server_version_num')::integer;
BEGIN
 IF current_database()<>'fuga_jales_local_homologacao_v1_2' OR current_user<>'postgres' OR current_schema()<>'homologacao' THEN
   RAISE EXCEPTION 'PREFLIGHT_REV5_BLOQUEADO_AMBIENTE db=% user=% schema=%',current_database(),current_user,current_schema(); END IF;
 IF vver<180004 OR vver/10000<>18 THEN RAISE EXCEPTION 'PREFLIGHT_REV5_BLOQUEADO_VERSAO versao=%',vver; END IF;
 IF to_regrole('fugapet_hml_app') IS NULL THEN RAISE EXCEPTION 'PREFLIGHT_REV5_RUNTIME_AUSENTE'; END IF;
END
$gaia$;

-- REV4 instalado e assinaturas alvo presentes.
DO $gaia$
BEGIN
 IF to_regclass('homologacao.hu_caixa_etapa_sap') IS NULL
    OR to_regclass('homologacao.hu_caixa_etapa_sap_tentativa') IS NULL
    OR to_regclass('homologacao.hu_caixa_etapa_sap_evento') IS NULL
    OR to_regprocedure('homologacao.fn_pa_045_palete_inserir_evento(bigint,text,character varying,jsonb,jsonb,integer,character varying,character varying,text,integer,boolean,bigint,uuid,character varying,uuid,character varying,timestamp with time zone,timestamp with time zone,text)') IS NULL
    OR to_regprocedure('homologacao.fn_pa_045_palete_claim_envio(bigint,jsonb,text,bigint,text)') IS NULL
    OR to_regprocedure('homologacao.fn_pa_045_palete_reassumir_claim(bigint,bigint,text)') IS NULL
    OR to_regprocedure('homologacao.fn_pa_045_palete_adquirir_recovery(bigint,bigint,text)') IS NULL
    OR to_regprocedure('homologacao.fn_pa_045_palete_registrar_erro(bigint,integer,uuid,integer,jsonb,text,text,bigint,text)') IS NULL
    OR to_regprocedure('homologacao.fn_pa_045_palete_registrar_timeout(bigint,integer,uuid,text,text,bigint,text)') IS NULL
    OR to_regprocedure('homologacao.fn_pa_045_palete_registrar_reconciliacao(bigint,integer,uuid,character varying,character varying,jsonb,text,bigint,text)') IS NULL
    OR to_regprocedure('homologacao.fn_pa_045_palete_liberar_reprocessamento(bigint,uuid,character varying,text,bigint,text)') IS NULL
    OR to_regprocedure('homologacao.fn_pa_045_palete_registrar_sucesso(bigint,integer,uuid,character varying,integer,jsonb,text,bigint,text)') IS NULL THEN
   RAISE EXCEPTION 'PREFLIGHT_REV5_BLOQUEADO_REV4_NAO_INSTALADO_OU_ASSINATURA_DIVERGENTE'; END IF;
 IF (SELECT count(*) FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='homologacao' AND p.proname LIKE 'fn_pa_045_%')<>29 THEN
   RAISE EXCEPTION 'PREFLIGHT_REV5_BLOQUEADO_CONTAGEM_FUNCOES_045'; END IF;
END
$gaia$;

-- status_sap legado permanece varchar(10) em header e historico; REV5 nao amplia coluna.
\echo '=== 02_STATUS_SAP_TIPO ==='
SELECT table_name,column_name,data_type,character_maximum_length,is_nullable
FROM information_schema.columns
WHERE table_schema='homologacao' AND table_name IN ('hu_palete','hu_palete_integracao_sap') AND column_name='status_sap'
ORDER BY table_name;
DO $gaia$ BEGIN
 IF (SELECT count(*) FROM information_schema.columns WHERE table_schema='homologacao'
      AND table_name IN ('hu_palete','hu_palete_integracao_sap') AND column_name='status_sap'
      AND data_type='character varying' AND character_maximum_length=10)<>2 THEN
   RAISE EXCEPTION 'PREFLIGHT_REV5_BLOQUEADO_STATUS_SAP_TIPO_DIVERGENTE'; END IF;
END $gaia$;

-- Prova que as funcoes ainda estao na semantica REV4 que a corretiva sabe substituir.
DO $gaia$
DECLARE d text;
BEGIN
 d:=pg_get_functiondef('homologacao.fn_pa_045_palete_reassumir_claim(bigint,bigint,text)'::regprocedure);
 IF position('CLAIM_REASSUMIDO' in d)=0 OR position('PA045_STATUS_SAP_ORIGEM_EXTERNA_INVALIDA' in d)>0 THEN RAISE EXCEPTION 'PREFLIGHT_REV5_REASSUMIR_CLAIM_NAO_REV4'; END IF;
 d:=pg_get_functiondef('homologacao.fn_pa_045_palete_adquirir_recovery(bigint,bigint,text)'::regprocedure);
 IF position('RECOVERY_CLAIM_ADQUIRIDO' in d)=0 OR position('RECOVERY_CLAIM_REASSUMIDO' in d)=0 THEN RAISE EXCEPTION 'PREFLIGHT_REV5_RECOVERY_NAO_REV4'; END IF;
 d:=pg_get_functiondef('homologacao.fn_pa_045_palete_registrar_reconciliacao(bigint,integer,uuid,character varying,character varying,jsonb,text,bigint,text)'::regprocedure);
 IF position('NAO_ENCONTRADO' in d)=0 OR position('DIVERGENTE' in d)=0 THEN RAISE EXCEPTION 'PREFLIGHT_REV5_RECONCILIACAO_NAO_REV4'; END IF;
 d:=pg_get_functiondef('homologacao.fn_pa_045_palete_registrar_timeout(bigint,integer,uuid,text,text,bigint,text)'::regprocedure);
 IF position('status_sap = ''TIMEOUT''' in d)=0 AND position('status_sap=''TIMEOUT''' in d)=0 THEN RAISE EXCEPTION 'PREFLIGHT_REV5_TIMEOUT_NAO_REV4'; END IF;
 RAISE NOTICE 'REV4_RUNTIME_STATUS_PALETE_IDENTIFICADO=SIM';
END
$gaia$;

-- 044 congelado: funcoes e triggers preexistentes permanecem com assinatura conhecida.
\echo '=== 03_044_CONGELADO ==='
SELECT md5(string_agg(p.oid::regprocedure::text || E'\n' || pg_get_functiondef(p.oid),E'\n---\n' ORDER BY p.oid::regprocedure::text)) AS hash_funcoes_044
FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='homologacao' AND p.proname LIKE 'fn_hu_%';
SELECT md5(string_agg(c.relname || '|' || t.tgname || '|' || pg_get_triggerdef(t.oid,true),E'\n' ORDER BY c.relname,t.tgname)) AS hash_triggers_044_preexistentes
FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace
WHERE NOT t.tgisinternal AND n.nspname='homologacao'
  AND c.relname IN ('hu_caixa','hu_caixa_pesagem','hu_caixa_integracao_sap','hu_caixa_etiqueta','hu_palete','hu_palete_item','hu_palete_integracao_sap','hu_palete_etiqueta')
  AND t.tgname NOT LIKE 'trg_045_%';
DO $gaia$ DECLARE hf text; ht text; BEGIN
 SELECT md5(string_agg(p.oid::regprocedure::text || E'\n' || pg_get_functiondef(p.oid),E'\n---\n' ORDER BY p.oid::regprocedure::text)) INTO hf
 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='homologacao' AND p.proname LIKE 'fn_hu_%';
 SELECT md5(string_agg(c.relname || '|' || t.tgname || '|' || pg_get_triggerdef(t.oid,true),E'\n' ORDER BY c.relname,t.tgname)) INTO ht
 FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace
 WHERE NOT t.tgisinternal AND n.nspname='homologacao' AND c.relname IN ('hu_caixa','hu_caixa_pesagem','hu_caixa_integracao_sap','hu_caixa_etiqueta','hu_palete','hu_palete_item','hu_palete_integracao_sap','hu_palete_etiqueta') AND t.tgname NOT LIKE 'trg_045_%';
 IF 'HML'='DEV' AND hf<>'47c28c1f36fbe6ab8c68ee87a6f8532e' THEN RAISE EXCEPTION 'PREFLIGHT_REV5_044_FUNCOES_DIVERGENTES hash=%',hf; END IF;
 -- HML possui definicoes textuais/ACL historicas proprias; nesse ambiente valida-se contagem/nomes.
 IF 'HML'='DEV' AND ht<>'e4f46d7795bf5eb9afd2bfbd28b7eeb7' THEN RAISE EXCEPTION 'PREFLIGHT_REV5_044_TRIGGERS_DIVERGENTES hash=%',ht; END IF;
 IF (SELECT count(*) FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='homologacao' AND p.proname LIKE 'fn_hu_%')<>20 THEN RAISE EXCEPTION 'PREFLIGHT_REV5_044_FUNCOES_CONTAGEM'; END IF;
 IF (SELECT count(*) FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE NOT t.tgisinternal AND n.nspname='homologacao' AND c.relname IN ('hu_caixa','hu_caixa_pesagem','hu_caixa_integracao_sap','hu_caixa_etiqueta','hu_palete','hu_palete_item','hu_palete_integracao_sap','hu_palete_etiqueta') AND t.tgname NOT LIKE 'trg_045_%')<>22 THEN RAISE EXCEPTION 'PREFLIGHT_REV5_044_TRIGGERS_CONTAGEM'; END IF;
 RAISE NOTICE '044_INTEGRO=SIM';
END $gaia$;

-- Nenhuma massa residual dos fixtures autorizados. Nao limpa nada.
DO $gaia$
DECLARE v_ids bigint; v_corr bigint; v_term bigint;
BEGIN
 SELECT
   (SELECT count(*) FROM homologacao.hu_caixa WHERE codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005))
 + (SELECT count(*) FROM homologacao.hu_caixa_pesagem WHERE codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005))
 + (SELECT count(*) FROM homologacao.hu_caixa_integracao_sap WHERE codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005))
 + (SELECT count(*) FROM homologacao.hu_caixa_etiqueta WHERE codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005))
 + (SELECT count(*) FROM homologacao.hu_caixa_etapa_sap WHERE codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005))
 + (SELECT count(*) FROM homologacao.hu_palete WHERE codigo_hu_palete IN (-450001,-450002))
 + (SELECT count(*) FROM homologacao.hu_palete_item WHERE codigo_hu_palete IN (-450001,-450002) OR codigo_hu_caixa IN (-450001,-450002,-450003,-450004,-450005))
 + (SELECT count(*) FROM homologacao.hu_palete_integracao_sap WHERE codigo_hu_palete IN (-450001,-450002))
 + (SELECT count(*) FROM homologacao.hu_palete_etiqueta WHERE codigo_hu_palete IN (-450001,-450002)) INTO v_ids;
 SELECT
   (SELECT count(*) FROM homologacao.hu_caixa WHERE correlation_id IN ('04500000-0000-0000-0000-000000000001'::uuid,'04500000-0000-0000-0000-000000000002'::uuid,'04500000-0000-0000-0000-000000000003'::uuid,'04500000-0000-0000-0000-000000000004'::uuid,'04500000-0000-0000-0000-000000000005'::uuid))
 + (SELECT count(*) FROM homologacao.hu_palete WHERE correlation_id IN ('04510000-0000-0000-0000-000000000001'::uuid,'04510000-0000-0000-0000-000000000002'::uuid)) INTO v_corr;
 SELECT count(*) INTO v_term FROM homologacao.hu_caixa WHERE situacao_hu_caixa AND upper(btrim(terminal::text)) LIKE 'GAIA045-%';
 IF v_ids<>0 OR v_corr<>0 OR v_term<>0 THEN RAISE EXCEPTION 'PREFLIGHT_REV5_BLOQUEADO_RESIDUOS ids=% corr=% terminais=%',v_ids,v_corr,v_term; END IF;
 RAISE NOTICE 'PRECHECK_RESIDUOS_VALIDACAO=ZERO';
END
$gaia$;

DO $gaia$ BEGIN
 RAISE NOTICE 'CLASSIFICACAO_OFICIAL=PREFLIGHT_045_REV5_HML_APTO_PARA_PROPOSTA_CORRETIVA_RUNTIME_STATUS_PALETE';
 RAISE NOTICE 'STATUS_SAP_VARCHAR_10_PRESERVADO=SIM';
 RAISE NOTICE 'BANCO_ALTERADO=NAO';
END $gaia$;
ROLLBACK;
\echo 'PREFLIGHT_045_REV5_FINALIZADO_COM_ROLLBACK'
