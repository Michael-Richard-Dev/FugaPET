FUGAPET — INCREMENTAL 045 — REV5 CORRETIVA 1
ESCOPO EXCLUSIVO: CONTAGEM TOTAL DE FUNCOES 045

CLASSIFICACAO: pacote preparado para DEDALO_V5_AUDITORIA_ESTATICA_REV5_CORRETIVA_1.
EXECUCAO: proibida nesta entrega. BANCO_ACESSADO=NAO; SQL_EXECUTADO=NAO; SAP_ACESSADO=NAO; CPI_ACESSADO=NAO.

CAUSA DA CORRETIVA
A REV5 anterior usou 21 em quatro verificacoes que contam fisicamente pg_proc WHERE proname LIKE 'fn_pa_045_%'. O total fisico correto do contrato 045 e 29. O valor 21 pertence exclusivamente a superficie EXECUTE da role runtime, validada por has_function_privilege(...,'EXECUTE').

CORRECOES SQL AUTORIZADAS E UNICAS
1. DEV PREFLIGHT: total fisico <>21 -> <>29.
2. DEV PROPOSTA POSCHECK: total fisico <>21 -> <>29.
3. HML PREFLIGHT: total fisico <>21 -> <>29.
4. HML PROPOSTA POSCHECK: total fisico <>21 -> <>29.

CONTRATO CONGELADO
FUNCOES_045_TOTAL=29
FUNCOES_045_RUNTIME_EXECUTE=21

A REV5 CORRETIVA 1 NAO altera as 8 funcoes de negocio aprovadas da REV5. As VALIDACOES DEV/HML e ROLLBACKS DEV/HML sao byte a byte identicos aos arquivos REV5 aprovados. Em particular, v_exec<>21 permanece preservado nas duas validacoes.

STATUS_SAP permanece integralmente congelado conforme REV5:
- coluna varchar(10), sem ALTER TABLE;
- evento local sem status externo: status_sap=NULL;
- POST_FORMACAO HTTP 2xx: status_sap=CONFIRMADO;
- POST_FORMACAO HTTP conhecido nao-2xx: status_sap=ERRO.

CHECKER
O checker e somente filesystem. Ele prova:
- TOTAL DEV/HML=29 nos PREFLIGHTS e POSCHECKS das PROPOSTAS;
- RUNTIME EXECUTE DEV/HML=21 nas VALIDACOES;
- ausencia de substituicao global 21->29;
- delta de cada PREFLIGHT/PROPOSTA restrito ao unico token autorizado;
- 8 funcoes REV5 inalteradas e semanticamente simetricas DEV/HML;
- VALIDACOES e ROLLBACKS byte a byte identicos a REV5;
- matriz status_sap congelada byte a byte.

PROXIMO_GATE=DEDALO_V5_AUDITORIA_ESTATICA_REV5_CORRETIVA_1
