\set ON_ERROR_STOP on
\pset pager off
-- FugaPET - Incremental 045 REV5 - DEV - ROLLBACK CORRETIVO SOMENTE FUNCOES
-- Restaura exclusivamente as 8 definicoes alteradas pela REV5 para REV4.
-- NAO e rollback do Incremental 045 inteiro.
\echo 'CLASSIFICACAO_DOCUMENTAL=ROLLBACK_045_REV5_DEV_PREPARADO_NAO_EXECUTADO'
BEGIN;
SET LOCAL search_path TO desenvolvimento, pg_catalog;
SET LOCAL statement_timeout='10min';
SET LOCAL lock_timeout='10s';
DO $gaia$ BEGIN
 IF current_database()<>'fuga_jales_local_desenvolvimento' OR current_user<>'postgres' OR current_schema()<>'desenvolvimento' THEN RAISE EXCEPTION 'ROLLBACK_REV5_BLOQUEADO_AMBIENTE'; END IF;
 IF position('PA045_STATUS_SAP_ORIGEM_EXTERNA_INVALIDA' in pg_get_functiondef('desenvolvimento.fn_pa_045_palete_inserir_evento(bigint,text,character varying,jsonb,jsonb,integer,character varying,character varying,text,integer,boolean,bigint,uuid,character varying,uuid,character varying,timestamp with time zone,timestamp with time zone,text)'::regprocedure))=0 THEN RAISE EXCEPTION 'ROLLBACK_REV5_BLOQUEADO_REV5_NAO_IDENTIFICADA'; END IF;
END $gaia$;

CREATE OR REPLACE FUNCTION desenvolvimento.fn_pa_045_palete_inserir_evento(
    p_codigo_hu_palete bigint,p_endpoint text,p_metodo varchar,p_request jsonb,p_response jsonb,
    p_http integer,p_status_sap varchar,p_hu varchar,p_erro text,p_tentativa integer,p_reprocessar boolean,
    p_usuario bigint,p_correlation uuid,p_tipo_operacao varchar,p_claim uuid,p_resultado varchar,
    p_inicio timestamptz,p_fim timestamptz,p_terminal text
) RETURNS bigint
LANGUAGE plpgsql SECURITY DEFINER
SET search_path=pg_catalog,desenvolvimento
AS $fn$
DECLARE v_id bigint;
BEGIN
    INSERT INTO desenvolvimento.hu_palete_integracao_sap(
      codigo_hu_palete,endpoint,metodo_http,payload_request,payload_response,status_http,status_sap,hu_gerada,
      mensagem_erro,tentativa,pode_reprocessar,processado_em,codigo_usuario,
      correlation_id,tipo_operacao,claim_token,resultado,iniciado_em,finalizado_em,terminal)
    VALUES(p_codigo_hu_palete,btrim(p_endpoint),p_metodo,COALESCE(p_request,'{}'::jsonb),p_response,p_http,p_status_sap,
           p_hu,NULLIF(btrim(COALESCE(p_erro,'')),''),p_tentativa,COALESCE(p_reprocessar,false),COALESCE(p_fim,p_inicio),p_usuario,
           p_correlation,p_tipo_operacao,p_claim,p_resultado,p_inicio,p_fim,upper(btrim(p_terminal)))
    RETURNING codigo_hu_palete_integracao_sap INTO v_id;
    RETURN v_id;
END
$fn$;

CREATE OR REPLACE FUNCTION desenvolvimento.fn_pa_045_palete_claim_envio(
    p_codigo_hu_palete bigint,p_request jsonb,p_endpoint text,p_usuario bigint,p_terminal text
) RETURNS SETOF desenvolvimento.hu_palete
LANGUAGE plpgsql SECURITY DEFINER
SET search_path=pg_catalog,desenvolvimento
AS $fn$
DECLARE v_terminal varchar(120); v_now timestamptz:=clock_timestamp(); v desenvolvimento.hu_palete%ROWTYPE; v_status varchar(30); v_retry boolean;
BEGIN
    v_terminal:=desenvolvimento.fn_pa_045_validar_ator(p_usuario,p_terminal);
    IF p_request IS NULL OR jsonb_typeof(p_request)<>'object' OR char_length(btrim(COALESCE(p_endpoint,'')))=0 THEN
       RAISE EXCEPTION 'PA045_PALETE_CLAIM_REQUEST_INVALIDO';
    END IF;
    SELECT status_hu_palete,pode_reprocessar INTO v_status,v_retry
      FROM desenvolvimento.hu_palete WHERE codigo_hu_palete=p_codigo_hu_palete FOR UPDATE;
    IF NOT FOUND THEN RETURN; END IF;
    IF NOT (v_status='RASCUNHO' OR (v_status IN ('ERRO_SAP','BLOQUEADO') AND v_retry)) THEN RETURN; END IF;
    IF NOT EXISTS(SELECT 1 FROM desenvolvimento.hu_palete_item i
                  WHERE i.codigo_hu_palete=p_codigo_hu_palete AND i.situacao_hu_palete_item
                    AND i.status_vinculo='VINCULADO') THEN
       RAISE EXCEPTION 'PA045_PALETE_SEM_CAIXAS';
    END IF;
    UPDATE desenvolvimento.hu_palete
       SET status_hu_palete='ENVIADO_SAP',payload_request=p_request,payload_response=NULL,status_http=NULL,status_sap='INICIADO',
           claim_token=gen_random_uuid(),claim_obtido_em=v_now,claim_expira_em=v_now+interval '5 minutes',
           recovery_claim_token=NULL,recovery_claim_obtido_em=NULL,recovery_claim_expira_em=NULL,
           tentativas=tentativas+1,tentativa_iniciada_em=v_now,status_reconciliacao='NAO_NECESSARIA',
           reconciliado_em=NULL,pode_reprocessar=false,erro_sanitizado=NULL,codigo_usuario=p_usuario,terminal=v_terminal
     WHERE codigo_hu_palete=p_codigo_hu_palete
       AND (status_hu_palete='RASCUNHO' OR (status_hu_palete IN ('ERRO_SAP','BLOQUEADO') AND pode_reprocessar))
     RETURNING * INTO v;
    IF NOT FOUND THEN RETURN; END IF;
    PERFORM desenvolvimento.fn_pa_045_palete_inserir_evento(v.codigo_hu_palete,p_endpoint,'POST',p_request,NULL,NULL,'INICIADO',NULL,NULL,
           v.tentativas,false,p_usuario,v.correlation_id,'POST_FORMACAO',v.claim_token,'INICIADO',v_now,NULL,v_terminal);
    RETURN NEXT v;
END
$fn$;

CREATE OR REPLACE FUNCTION desenvolvimento.fn_pa_045_palete_reassumir_claim(
    p_codigo_hu_palete bigint,p_usuario bigint,p_terminal text
) RETURNS SETOF desenvolvimento.hu_palete
LANGUAGE plpgsql SECURITY DEFINER
SET search_path=pg_catalog,desenvolvimento
AS $fn$
DECLARE v_terminal varchar(120); v_now timestamptz:=clock_timestamp(); v desenvolvimento.hu_palete%ROWTYPE;
BEGIN
    v_terminal:=desenvolvimento.fn_pa_045_validar_ator(p_usuario,p_terminal);
    UPDATE desenvolvimento.hu_palete
       SET claim_token=gen_random_uuid(),claim_obtido_em=v_now,claim_expira_em=v_now+interval '5 minutes',
           codigo_usuario=p_usuario,terminal=v_terminal
     WHERE codigo_hu_palete=p_codigo_hu_palete AND status_hu_palete='ENVIADO_SAP'
       AND tentativas>0 AND claim_token IS NOT NULL AND claim_expira_em IS NOT NULL AND claim_expira_em<=v_now
     RETURNING * INTO v;
    IF NOT FOUND THEN RETURN; END IF;
    PERFORM desenvolvimento.fn_pa_045_palete_inserir_evento(v.codigo_hu_palete,
           'LOCAL://produto-acabado/045/palete/claim/reassumir','LOCAL','{}'::jsonb,NULL,NULL,'CLAIM_REASSUMIDO',NULL,NULL,
           v.tentativas,false,p_usuario,v.correlation_id,'CLAIM_REASSUMIDO',v.claim_token,'CLAIM_REASSUMIDO',v_now,v_now,v_terminal);
    RETURN NEXT v;
END
$fn$;

CREATE OR REPLACE FUNCTION desenvolvimento.fn_pa_045_palete_adquirir_recovery(
    p_codigo_hu_palete bigint,p_usuario bigint,p_terminal text
) RETURNS TABLE(
    codigo_hu_palete bigint,tentativa integer,recovery_claim_token uuid,recovery_claim_expira_em timestamptz
)
LANGUAGE plpgsql SECURITY DEFINER
SET search_path=pg_catalog,desenvolvimento
AS $fn$
DECLARE
    v_terminal varchar(120); v_now timestamptz:=clock_timestamp(); v desenvolvimento.hu_palete%ROWTYPE;
    v_token uuid; v_tipo varchar(40);
BEGIN
    v_terminal:=desenvolvimento.fn_pa_045_validar_ator(p_usuario,p_terminal);
    SELECT * INTO v FROM desenvolvimento.hu_palete p WHERE p.codigo_hu_palete=p_codigo_hu_palete FOR UPDATE;
    IF NOT FOUND OR v.status_hu_palete NOT IN ('INDETERMINADO_TIMEOUT','ERRO_SAP','BLOQUEADO') OR v.tentativas<=0 THEN RETURN; END IF;
    IF v.claim_token IS NULL OR v.claim_expira_em IS NULL OR v.claim_expira_em>v_now THEN RETURN; END IF;
    IF v.recovery_claim_token IS NOT NULL AND v.recovery_claim_expira_em IS NOT NULL
       AND v.recovery_claim_expira_em>v_now THEN RETURN; END IF;

    v_tipo:=CASE WHEN v.recovery_claim_token IS NULL THEN 'RECOVERY_CLAIM_ADQUIRIDO'
                 ELSE 'RECOVERY_CLAIM_REASSUMIDO' END;
    v_token:=gen_random_uuid();
    UPDATE desenvolvimento.hu_palete
       SET recovery_claim_token=v_token,recovery_claim_obtido_em=v_now,recovery_claim_expira_em=v_now+interval '5 minutes',
           codigo_usuario=p_usuario,terminal=v_terminal
     WHERE codigo_hu_palete=p_codigo_hu_palete;

    PERFORM desenvolvimento.fn_pa_045_palete_inserir_evento(v.codigo_hu_palete,
           'LOCAL://produto-acabado/045/palete/recovery/claim','LOCAL','{}'::jsonb,NULL,NULL,v_tipo,NULL,NULL,
           v.tentativas,false,p_usuario,v.correlation_id,v_tipo,v_token,v_tipo,v_now,v_now,v_terminal);
    RETURN QUERY SELECT p_codigo_hu_palete,v.tentativas,v_token,v_now+interval '5 minutes';
END
$fn$;

CREATE OR REPLACE FUNCTION desenvolvimento.fn_pa_045_palete_registrar_erro(
    p_codigo_hu_palete bigint,p_tentativa integer,p_claim uuid,p_http integer,p_response jsonb,p_erro text,
    p_endpoint text,p_usuario bigint,p_terminal text
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER
SET search_path=pg_catalog,desenvolvimento
AS $fn$
DECLARE v_terminal varchar(120); v_now timestamptz:=clock_timestamp(); v desenvolvimento.hu_palete%ROWTYPE;
BEGIN
    v_terminal:=desenvolvimento.fn_pa_045_validar_ator(p_usuario,p_terminal);
    IF char_length(btrim(COALESCE(p_erro,'')))=0 OR char_length(btrim(COALESCE(p_endpoint,'')))=0 THEN RAISE EXCEPTION 'PA045_PALETE_ERRO_EXIGE_MENSAGEM'; END IF;
    UPDATE desenvolvimento.hu_palete
       SET status_hu_palete='ERRO_SAP',payload_response=p_response,status_http=p_http,status_sap='ERRO',
           erro_sanitizado=btrim(p_erro),pode_reprocessar=false,claim_expira_em=v_now,
           recovery_claim_token=NULL,recovery_claim_obtido_em=NULL,recovery_claim_expira_em=NULL,
           codigo_usuario=p_usuario,terminal=v_terminal
     WHERE codigo_hu_palete=p_codigo_hu_palete AND status_hu_palete='ENVIADO_SAP'
       AND tentativas=p_tentativa AND claim_token=p_claim
       AND claim_expira_em IS NOT NULL AND claim_expira_em>v_now RETURNING * INTO v;
    IF NOT FOUND THEN RETURN false; END IF;
    PERFORM desenvolvimento.fn_pa_045_palete_inserir_evento(v.codigo_hu_palete,p_endpoint,'POST',v.payload_request,p_response,p_http,'ERRO',NULL,
           btrim(p_erro),p_tentativa,false,p_usuario,v.correlation_id,'POST_FORMACAO',p_claim,'ERRO',v.tentativa_iniciada_em,v_now,v_terminal);
    RETURN true;
END
$fn$;

CREATE OR REPLACE FUNCTION desenvolvimento.fn_pa_045_palete_registrar_timeout(
    p_codigo_hu_palete bigint,p_tentativa integer,p_claim uuid,p_erro text,p_endpoint text,p_usuario bigint,p_terminal text
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER
SET search_path=pg_catalog,desenvolvimento
AS $fn$
DECLARE v_terminal varchar(120); v_now timestamptz:=clock_timestamp(); v desenvolvimento.hu_palete%ROWTYPE;
BEGIN
    v_terminal:=desenvolvimento.fn_pa_045_validar_ator(p_usuario,p_terminal);
    IF char_length(btrim(COALESCE(p_erro,'')))=0 OR char_length(btrim(COALESCE(p_endpoint,'')))=0 THEN RAISE EXCEPTION 'PA045_PALETE_TIMEOUT_EXIGE_MENSAGEM'; END IF;
    UPDATE desenvolvimento.hu_palete
       SET status_hu_palete='INDETERMINADO_TIMEOUT',payload_response=NULL,status_http=NULL,status_sap='TIMEOUT',
           erro_sanitizado=btrim(p_erro),status_reconciliacao='PENDENTE',reconciliado_em=NULL,pode_reprocessar=false,
           claim_expira_em=v_now,recovery_claim_token=NULL,recovery_claim_obtido_em=NULL,recovery_claim_expira_em=NULL,
           codigo_usuario=p_usuario,terminal=v_terminal
     WHERE codigo_hu_palete=p_codigo_hu_palete AND status_hu_palete='ENVIADO_SAP'
       AND tentativas=p_tentativa AND claim_token=p_claim
       AND claim_expira_em IS NOT NULL AND claim_expira_em>v_now RETURNING * INTO v;
    IF NOT FOUND THEN RETURN false; END IF;
    PERFORM desenvolvimento.fn_pa_045_palete_inserir_evento(v.codigo_hu_palete,p_endpoint,'POST',v.payload_request,NULL,NULL,'TIMEOUT',NULL,
           btrim(p_erro),p_tentativa,false,p_usuario,v.correlation_id,'POST_FORMACAO',p_claim,'INDETERMINADO_TIMEOUT',
           v.tentativa_iniciada_em,v_now,v_terminal);
    RETURN true;
END
$fn$;

CREATE OR REPLACE FUNCTION desenvolvimento.fn_pa_045_palete_registrar_reconciliacao(
    p_codigo_hu_palete bigint,p_tentativa integer,p_claim uuid,p_resultado varchar,p_hu_pai varchar,
    p_evidencia jsonb,p_erro text,p_usuario bigint,p_terminal text
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER
SET search_path=pg_catalog,desenvolvimento
AS $fn$
DECLARE v_terminal varchar(120); v_now timestamptz:=clock_timestamp(); v desenvolvimento.hu_palete%ROWTYPE;
BEGIN
    v_terminal:=desenvolvimento.fn_pa_045_validar_ator(p_usuario,p_terminal);
    IF p_claim IS NULL OR p_resultado NOT IN ('CONFIRMADO_EXISTE','CONFIRMADO_NAO_EXISTE','DIVERGENTE')
       OR p_evidencia IS NULL OR jsonb_typeof(p_evidencia)<>'object' THEN
       RAISE EXCEPTION 'PA045_PALETE_RECONCILIACAO_INVALIDA'; END IF;
    IF p_resultado='CONFIRMADO_EXISTE' AND char_length(btrim(COALESCE(p_hu_pai,'')))=0 THEN
       RAISE EXCEPTION 'PA045_PALETE_RECONCILIACAO_EXISTE_EXIGE_HU_PAI'; END IF;
    IF p_resultado='DIVERGENTE' AND char_length(btrim(COALESCE(p_erro,'')))=0 THEN
       RAISE EXCEPTION 'PA045_PALETE_RECONCILIACAO_DIVERGENTE_EXIGE_ERRO'; END IF;

    IF p_resultado='CONFIRMADO_EXISTE' THEN
       UPDATE desenvolvimento.hu_palete
          SET status_hu_palete='CONFIRMADO_SAP',handling_unit_external_id=btrim(p_hu_pai),hu_palete=btrim(p_hu_pai),
              payload_response=p_evidencia,status_http=NULL,status_sap='CONFIRMADO',criado_sap_em=COALESCE(criado_sap_em,v_now),
              status_reconciliacao='CONFIRMADO_EXISTE',reconciliado_em=v_now,pode_reprocessar=false,erro_sanitizado=NULL,
              recovery_claim_token=NULL,recovery_claim_obtido_em=NULL,recovery_claim_expira_em=NULL,
              codigo_usuario=p_usuario,terminal=v_terminal
        WHERE codigo_hu_palete=p_codigo_hu_palete AND status_hu_palete='INDETERMINADO_TIMEOUT'
          AND tentativas=p_tentativa AND recovery_claim_token=p_claim
          AND recovery_claim_expira_em IS NOT NULL AND recovery_claim_expira_em>v_now RETURNING * INTO v;
    ELSIF p_resultado='CONFIRMADO_NAO_EXISTE' THEN
       UPDATE desenvolvimento.hu_palete
          SET status_hu_palete='ERRO_SAP',payload_response=p_evidencia,status_http=NULL,status_sap='NAO_ENCONTRADO',
              status_reconciliacao='CONFIRMADO_NAO_EXISTE',reconciliado_em=v_now,pode_reprocessar=false,
              erro_sanitizado=COALESCE(NULLIF(btrim(COALESCE(p_erro,'')),''),'Reconciliacao deterministica: HU pai nao encontrada'),
              codigo_usuario=p_usuario,terminal=v_terminal
        WHERE codigo_hu_palete=p_codigo_hu_palete AND status_hu_palete='INDETERMINADO_TIMEOUT'
          AND tentativas=p_tentativa AND recovery_claim_token=p_claim
          AND recovery_claim_expira_em IS NOT NULL AND recovery_claim_expira_em>v_now RETURNING * INTO v;
    ELSE
       UPDATE desenvolvimento.hu_palete
          SET status_hu_palete='BLOQUEADO',payload_response=p_evidencia,status_http=NULL,status_sap='DIVERGENTE',
              status_reconciliacao='DIVERGENTE',reconciliado_em=v_now,pode_reprocessar=false,erro_sanitizado=btrim(p_erro),
              codigo_usuario=p_usuario,terminal=v_terminal
        WHERE codigo_hu_palete=p_codigo_hu_palete AND status_hu_palete='INDETERMINADO_TIMEOUT'
          AND tentativas=p_tentativa AND recovery_claim_token=p_claim
          AND recovery_claim_expira_em IS NOT NULL AND recovery_claim_expira_em>v_now RETURNING * INTO v;
    END IF;
    IF NOT FOUND THEN RETURN false; END IF;

    PERFORM desenvolvimento.fn_pa_045_palete_inserir_evento(v.codigo_hu_palete,
           'LOCAL://produto-acabado/045/palete/reconciliacao','LOCAL','{}'::jsonb,p_evidencia,NULL,
           CASE p_resultado WHEN 'CONFIRMADO_EXISTE' THEN 'CONFIRMADO' WHEN 'CONFIRMADO_NAO_EXISTE' THEN 'NAO_ENCONTRADO' ELSE 'DIVERGENTE' END,
           NULLIF(btrim(COALESCE(p_hu_pai,'')),''),NULLIF(btrim(COALESCE(p_erro,'')),''),p_tentativa,false,p_usuario,
           v.correlation_id,'RECONCILIACAO',p_claim,p_resultado,v_now,v_now,v_terminal);
    RETURN true;
END
$fn$;

CREATE OR REPLACE FUNCTION desenvolvimento.fn_pa_045_palete_liberar_reprocessamento(
    p_codigo_hu_palete bigint,p_claim uuid,p_tipo_liberacao varchar,p_motivo text,p_usuario bigint,p_terminal text
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER
SET search_path=pg_catalog,desenvolvimento
AS $fn$
DECLARE v_terminal varchar(120); v_now timestamptz:=clock_timestamp(); v desenvolvimento.hu_palete%ROWTYPE;
BEGIN
    v_terminal:=desenvolvimento.fn_pa_045_validar_ator(p_usuario,p_terminal);
    IF p_claim IS NULL OR p_tipo_liberacao NOT IN ('POS_RECONCILIACAO_NAO_ENCONTRADO','DECISAO_OPERACIONAL_FORMAL')
       OR char_length(btrim(COALESCE(p_motivo,'')))<10 THEN
       RAISE EXCEPTION 'PA045_PALETE_LIBERACAO_INVALIDA'; END IF;
    SELECT * INTO v FROM desenvolvimento.hu_palete WHERE codigo_hu_palete=p_codigo_hu_palete FOR UPDATE;
    IF NOT FOUND OR v.status_hu_palete NOT IN ('ERRO_SAP','BLOQUEADO') OR v.tentativas<=0
       OR v.recovery_claim_token IS DISTINCT FROM p_claim OR v.recovery_claim_expira_em IS NULL
       OR v.recovery_claim_expira_em<=v_now THEN RETURN false; END IF;
    IF p_tipo_liberacao='POS_RECONCILIACAO_NAO_ENCONTRADO' AND v.status_reconciliacao<>'CONFIRMADO_NAO_EXISTE' THEN
       RAISE EXCEPTION 'PA045_PALETE_RETRY_EXIGE_RECONCILIACAO_NAO_ENCONTRADO'; END IF;
    UPDATE desenvolvimento.hu_palete
       SET pode_reprocessar=true,erro_sanitizado=btrim(p_motivo),recovery_claim_expira_em=v_now,
           codigo_usuario=p_usuario,terminal=v_terminal
     WHERE codigo_hu_palete=p_codigo_hu_palete AND recovery_claim_token=p_claim AND recovery_claim_expira_em>v_now;
    IF NOT FOUND THEN RETURN false; END IF;
    PERFORM desenvolvimento.fn_pa_045_palete_inserir_evento(v.codigo_hu_palete,'LOCAL://produto-acabado/045/palete/reprocessamento','LOCAL',
           '{}'::jsonb,NULL,NULL,'LIBERADO',NULL,p_tipo_liberacao||': '||p_motivo,v.tentativas,true,p_usuario,v.correlation_id,
           'LIBERACAO_REPROCESSAMENTO',p_claim,'LIBERADO_REPROCESSAMENTO',v_now,v_now,v_terminal);
    RETURN true;
END
$fn$;

DO $gaia$ BEGIN
 IF position('PA045_STATUS_SAP_ORIGEM_EXTERNA_INVALIDA' in pg_get_functiondef('desenvolvimento.fn_pa_045_palete_inserir_evento(bigint,text,character varying,jsonb,jsonb,integer,character varying,character varying,text,integer,boolean,bigint,uuid,character varying,uuid,character varying,timestamp with time zone,timestamp with time zone,text)'::regprocedure))>0 THEN RAISE EXCEPTION 'ROLLBACK_REV5_NAO_RESTAURou_INSERTER'; END IF;
 IF position('CLAIM_REASSUMIDO' in pg_get_functiondef('desenvolvimento.fn_pa_045_palete_reassumir_claim(bigint,bigint,text)'::regprocedure))=0 THEN RAISE EXCEPTION 'ROLLBACK_REV5_NAO_RESTAURou_REV4'; END IF;
 IF (SELECT count(*) FROM information_schema.columns WHERE table_schema='desenvolvimento' AND table_name IN ('hu_palete','hu_palete_integracao_sap') AND column_name='status_sap' AND character_maximum_length=10)<>2 THEN RAISE EXCEPTION 'ROLLBACK_REV5_STATUS_SAP_TIPO_DIVERGENTE'; END IF;
 RAISE NOTICE 'ROLLBACK_REV5_RESTAURA_APENAS_FUNCOES=SIM';
 RAISE NOTICE 'STATUS_SAP_COLUNA_ALTERADA=NAO';
 RAISE NOTICE 'CLASSIFICACAO_OFICIAL=ROLLBACK_045_REV5_DEV_FUNCOES_RESTAURADAS_PARA_REV4';
END $gaia$;
COMMIT;
\echo 'ROLLBACK_045_REV5_DEV_FINALIZADO_COM_COMMIT'
