\set ON_ERROR_STOP on
\pset pager off
\pset tuples_only off
\pset format aligned
\pset null '<NULL>'

-- FugaPET - Incremental 044 DEV - PREFLIGHT REV11 CORRECAO AUDITORIA
-- Exclusivamente READ ONLY. Nao altera banco, ACL, triggers, sequences ou dados.
-- Base esperada: PROPOSTA REV10 aplicada e REV11 ainda nao aplicada.

BEGIN;
SET TRANSACTION READ ONLY;
SET LOCAL statement_timeout='5min';
SET LOCAL lock_timeout='5s';

DO $gaia$
DECLARE
  v_version integer := current_setting('server_version_num')::integer;
  v_cols integer;
  v_objs integer;
  v_generic oid;
  v_owner name;
  v_prosecdef boolean;
  v_def text;
  v_hu_triggers integer;
  v_negative bigint;
  v_temp_grants integer;
  v_log_dml integer;
  v_seq text;
  v_seq_usage boolean := false;
BEGIN
  IF current_database()<>'fuga_jales_local_desenvolvimento' OR current_user<>'postgres' THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_AMBIENTE_OU_EXECUTOR banco=% executor=%',current_database(),current_user;
  END IF;
  IF v_version<150005 OR v_version>=160000 THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_POSTGRESQL versao_num=%',v_version;
  END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='fugapet_dev_app' AND rolcanlogin AND NOT rolsuper AND NOT rolcreatedb AND NOT rolcreaterole AND NOT rolreplication AND NOT rolbypassrls) THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_ROLE_APLICACAO';
  END IF;
  IF has_schema_privilege('fugapet_dev_app','desenvolvimento','CREATE') THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_APP_COM_CREATE_SCHEMA';
  END IF;

  SELECT count(*) INTO v_cols FROM (VALUES ('hu_caixa','numero_ordem_producao'),('hu_caixa','item_ordem_producao'),('hu_caixa','codigo_caixa_local'),('hu_caixa','correlation_id'),('hu_caixa','lote'),('hu_caixa','centro'),('hu_caixa','deposito'),('hu_caixa','material_embalagem'),('hu_caixa','origem_material_embalagem'),('hu_caixa','quantidade'),('hu_caixa','unidade_quantidade'),('hu_caixa','origem_pesagem'),('hu_caixa','terminal'),('hu_caixa','endpoint_sanitizado'),('hu_caixa','handling_unit_external_id'),('hu_caixa','warehouse'),('hu_caixa','odata_etag'),('hu_caixa','created_by_user_sap'),('hu_caixa','creation_datetime_sap'),('hu_caixa','http_status'),('hu_caixa','request_json_sanitizado'),('hu_caixa','response_json_sanitizado'),('hu_caixa','sap_messages_sanitizadas'),('hu_caixa','erro_sanitizado'),('hu_caixa','claim_em'),('hu_caixa','claim_token'),('hu_caixa','tentativa_iniciada_em'),('hu_caixa','enviado_sap_em'),('hu_caixa','confirmado_sap_em'),('hu_caixa','reconciliado_em'),('hu_caixa','tentativas'),('hu_caixa','autorizado_envio_em'),('hu_caixa','autorizado_envio_por'),('hu_caixa','terminal_autorizacao'),('hu_caixa','cancelado_em'),('hu_caixa','cancelado_por'),('hu_caixa','motivo_cancelamento'),('hu_caixa','reprocessamento_liberado_em'),('hu_caixa','reprocessamento_liberado_por'),('hu_caixa','motivo_reprocessamento'),('hu_caixa','criado_em'),('hu_caixa','atualizado_em'),('hu_caixa_integracao_sap','correlation_id'),('hu_caixa_integracao_sap','tipo_operacao'),('hu_caixa_integracao_sap','endpoint_sanitizado'),('hu_caixa_integracao_sap','numero_tentativa'),('hu_caixa_integracao_sap','claim_token'),('hu_caixa_integracao_sap','request_json_sanitizado'),('hu_caixa_integracao_sap','response_json_sanitizado'),('hu_caixa_integracao_sap','http_status'),('hu_caixa_integracao_sap','resultado'),('hu_caixa_integracao_sap','handling_unit_external_id'),('hu_caixa_integracao_sap','warehouse'),('hu_caixa_integracao_sap','odata_etag'),('hu_caixa_integracao_sap','mensagem_erro_sanitizada'),('hu_caixa_integracao_sap','iniciado_em'),('hu_caixa_integracao_sap','finalizado_em'),('hu_caixa_integracao_sap','terminal'),('hu_caixa_integracao_sap','criado_em')) e(tabela,coluna)
  WHERE EXISTS(SELECT 1 FROM information_schema.columns c WHERE c.table_schema='desenvolvimento' AND c.table_name=e.tabela AND c.column_name=e.coluna);
  SELECT (
      (to_regprocedure('desenvolvimento.fn_hu_caixa_preparar_insert()') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_validar_update()') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_integracao_preparar_insert()') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_integracao_imutavel()') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_inserir_evento(bigint,uuid,varchar,text,varchar,integer,uuid,jsonb,jsonb,jsonb,integer,varchar,varchar,varchar,text,text,boolean,timestamptz,timestamptz,bigint,text)') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_finalizar_local(bigint,bigint,text)') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_salvar_preview(bigint,jsonb,text)') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_aguardar_autorizacao(bigint)') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_autorizar_envio(bigint,bigint,text)') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_claim_envio(bigint,bigint,text)') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_registrar_sucesso(bigint,integer,uuid,varchar,varchar,integer,jsonb,jsonb,text,varchar,timestamptz)') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_registrar_erro(bigint,integer,uuid,integer,jsonb,jsonb,text,varchar,boolean)') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_registrar_timeout(bigint,integer,uuid,jsonb,text)') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_confirmar_reconciliacao(bigint,varchar,varchar,integer,jsonb,jsonb,text,varchar,timestamptz,boolean)') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_registrar_reconciliacao_nao_encontrada(bigint,varchar,varchar,integer,jsonb,jsonb,text)') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_cancelar(bigint,bigint,text,text)') IS NOT NULL)::integer
    + (to_regprocedure('desenvolvimento.fn_hu_caixa_liberar_reprocessamento(bigint,bigint,text,text)') IS NOT NULL)::integer
    + EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE NOT t.tgisinternal AND n.nspname='desenvolvimento' AND t.tgname='trg_hu_caixa_preparar_insert')::integer
    + EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE NOT t.tgisinternal AND n.nspname='desenvolvimento' AND t.tgname='trg_hu_caixa_validar_update')::integer
    + EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE NOT t.tgisinternal AND n.nspname='desenvolvimento' AND t.tgname='trg_hu_caixa_integracao_preparar_insert')::integer
    + EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE NOT t.tgisinternal AND n.nspname='desenvolvimento' AND t.tgname='trg_hu_caixa_integracao_imutavel')::integer
    + (to_regclass('desenvolvimento.uq_hu_caixa_correlation_id') IS NOT NULL)::integer
    + (to_regclass('desenvolvimento.uq_hu_caixa_codigo_local') IS NOT NULL)::integer
    + (to_regclass('desenvolvimento.uq_hu_caixa_op_numero') IS NOT NULL)::integer
    + (to_regclass('desenvolvimento.uq_hu_caixa_hu_sap_warehouse') IS NOT NULL)::integer
    + (to_regclass('desenvolvimento.uq_hu_caixa_terminal_ativo') IS NOT NULL)::integer
    + (to_regclass('desenvolvimento.ix_hu_caixa_status_atualizado_044') IS NOT NULL)::integer
    + (to_regclass('desenvolvimento.ix_hu_caixa_op') IS NOT NULL)::integer
    + (to_regclass('desenvolvimento.ix_hu_caixa_integracao_tentativa_claim') IS NOT NULL)::integer
    + (to_regclass('desenvolvimento.uq_hu_caixa_claim_token') IS NOT NULL)::integer
    + (to_regclass('desenvolvimento.uq_hu_caixa_integracao_claim_iniciado') IS NOT NULL)::integer
    + (to_regclass('desenvolvimento.ix_hu_caixa_integracao_correlation') IS NOT NULL)::integer
    + (to_regclass('desenvolvimento.ix_hu_caixa_integracao_hu_sap') IS NOT NULL)::integer
    + EXISTS (SELECT 1 FROM pg_constraint c JOIN pg_namespace n ON n.oid=c.connamespace WHERE n.nspname='desenvolvimento' AND c.conname='uq_hu_caixa_codigo_correlation')::integer
) INTO v_objs;
  IF v_cols<>59 OR v_objs<>34 THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_REV10_INCOMPLETA colunas=%/59 objetos=%/34',v_cols,v_objs;
  END IF;
  IF to_regprocedure('desenvolvimento.fn_hu_caixa_pesagem_normalizar()') IS NULL
     OR to_regprocedure('desenvolvimento.fn_hu_caixa_bloquear_configuracao(bigint,bigint,text,text,jsonb)') IS NULL
     OR NOT EXISTS(SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace
                   WHERE n.nspname='desenvolvimento' AND c.relname='hu_caixa_pesagem'
                     AND t.tgname='trg_hu_caixa_pesagem_normalizar' AND NOT t.tgisinternal AND t.tgenabled<>'D') THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_REV10_COMPLEMENTOS_AUSENTES';
  END IF;

  v_generic:=to_regprocedure('desenvolvimento.fn_registrar_log_alteracao_cadastral()');
  IF v_generic IS NULL THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_FUNCAO_AUDITORIA_GENERICA_AUSENTE';
  END IF;
  SELECT pg_get_userbyid(p.proowner),p.prosecdef,pg_get_functiondef(p.oid) INTO v_owner,v_prosecdef,v_def FROM pg_proc p WHERE p.oid=v_generic;
  IF v_owner<>'postgres' OR v_prosecdef THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_FUNCAO_GENERICA_ESTADO_INESPERADO owner=% prosecdef=%',v_owner,v_prosecdef;
  END IF;
  IF position('INSERT INTO desenvolvimento.log_alteracao_cadastral' IN v_def)=0 THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_FUNCAO_GENERICA_NAO_GRAVA_LOG_ESPERADO';
  END IF;
  IF v_def ~* '\mEXECUTE\M' OR v_def ~* '\mformat\s*\(' THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_FUNCAO_GENERICA_SQL_DINAMICO_INESPERADO';
  END IF;

  IF to_regprocedure('desenvolvimento.fn_hu_registrar_log_alteracao_cadastral()') IS NOT NULL THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_REV11_JA_APLICADA_PARCIAL_OU_TOTAL';
  END IF;

  SELECT count(*) INTO v_hu_triggers
  FROM (VALUES
    ('hu_caixa','trg_hu_caixa_log_alteracao_cadastral'),
    ('hu_caixa_pesagem','trg_hu_caixa_pesagem_log_alteracao_cadastral'),
    ('hu_caixa_integracao_sap','trg_hu_caixa_integracao_sap_log_alteracao_cadastral')
  ) x(tabela,trigger_name)
  JOIN pg_class c ON c.relname=x.tabela
  JOIN pg_namespace n ON n.oid=c.relnamespace AND n.nspname='desenvolvimento'
  JOIN pg_trigger t ON t.tgrelid=c.oid AND t.tgname=x.trigger_name AND NOT t.tgisinternal
  WHERE t.tgenabled<>'D' AND t.tgfoid=v_generic;
  IF v_hu_triggers<>3 THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_TRIGGERS_HU_GENERICOS quantidade=%/3',v_hu_triggers;
  END IF;

  SELECT count(*) INTO v_negative FROM desenvolvimento.hu_caixa WHERE codigo_hu_caixa<0 AND (codigo_hu_caixa BETWEEN -440307 AND -440301 OR codigo_hu_caixa=-449901);
  v_negative:=v_negative+(SELECT count(*) FROM desenvolvimento.hu_caixa_pesagem WHERE codigo_hu_caixa_pesagem<0 AND codigo_hu_caixa_pesagem BETWEEN -44990101 AND -44030101);
  v_negative:=v_negative+(SELECT count(*) FROM desenvolvimento.hu_caixa_integracao_sap WHERE codigo_hu_caixa<0 AND codigo_hu_caixa BETWEEN -440307 AND -440301);
  IF v_negative<>0 THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_RESIDUOS_VALIDACAO quantidade=%',v_negative;
  END IF;

  SELECT
    has_column_privilege('fugapet_dev_app','desenvolvimento.hu_caixa','codigo_hu_caixa','INSERT')::int
    + has_column_privilege('fugapet_dev_app','desenvolvimento.hu_caixa_pesagem','codigo_hu_caixa_pesagem','INSERT')::int
    + has_table_privilege('fugapet_dev_app','desenvolvimento.hu_caixa','UPDATE')::int
  INTO v_temp_grants;
  IF v_temp_grants<>0 THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_GRANT_TEMPORARIO quantidade=%',v_temp_grants;
  END IF;

  SELECT
    has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','INSERT')::int
    + has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','UPDATE')::int
    + has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','DELETE')::int
  INTO v_log_dml;
  IF v_log_dml<>0 THEN
    RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_APP_COM_DML_DIRETO_LOG quantidade=%',v_log_dml;
  END IF;

  v_seq:=pg_get_serial_sequence('desenvolvimento.log_alteracao_cadastral','codigo_log_alteracao_cadastral');
  IF v_seq IS NOT NULL THEN
    v_seq_usage:=has_sequence_privilege('fugapet_dev_app',v_seq,'USAGE');
    IF v_seq_usage THEN
      RAISE EXCEPTION 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_BLOQUEADO_APP_COM_USAGE_SEQUENCE_AUDITORIA sequence=%',v_seq;
    END IF;
  END IF;

  RAISE NOTICE 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_APROVADO';
  RAISE NOTICE 'REV10_COLUNAS=%/59 REV10_OBJETOS=%/34 REV10_COMPLEMENTOS=3/3',v_cols,v_objs;
  RAISE NOTICE 'FUNCAO_GENERICA_OWNER=% SECURITY_DEFINER=% SQL_DINAMICO=NAO',v_owner,v_prosecdef;
END
$gaia$;

SELECT 'AMBIENTE' grupo,current_database() banco,current_user executor,current_setting('server_version') postgresql,
       COALESCE(inet_server_addr()::text,'') servidor,COALESCE(inet_server_port()::text,'') porta;

SELECT 'FUNCAO_AUDITORIA_GENERICA' grupo,p.oid::regprocedure funcao,pg_get_userbyid(p.proowner) owner,p.prosecdef,
       p.proconfig,pg_get_functiondef(p.oid) definicao
FROM pg_proc p WHERE p.oid=to_regprocedure('desenvolvimento.fn_registrar_log_alteracao_cadastral()');

SELECT 'TRIGGERS_DEPENDENTES_FUNCAO_GENERICA' grupo,n.nspname schema_tabela,c.relname tabela,t.tgname,
       t.tgenabled,pg_get_triggerdef(t.oid,true) definicao
FROM pg_trigger t JOIN pg_proc p ON p.oid=t.tgfoid JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace
WHERE NOT t.tgisinternal AND p.oid=to_regprocedure('desenvolvimento.fn_registrar_log_alteracao_cadastral()')
ORDER BY n.nspname,c.relname,t.tgname;

SELECT 'ACL_FUNCAO_GENERICA' grupo,
       CASE WHEN a.grantee=0 THEN 'PUBLIC' ELSE pg_get_userbyid(a.grantee) END grantee,
       a.privilege_type,a.is_grantable
FROM pg_proc p CROSS JOIN LATERAL aclexplode(COALESCE(p.proacl,acldefault('f',p.proowner))) a
WHERE p.oid=to_regprocedure('desenvolvimento.fn_registrar_log_alteracao_cadastral()')
ORDER BY grantee,a.privilege_type;

SELECT 'PRIVILEGIOS_APP_LOG' grupo,
       has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','SELECT') select_log,
       has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','INSERT') insert_log,
       has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','UPDATE') update_log,
       has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','DELETE') delete_log,
       pg_get_serial_sequence('desenvolvimento.log_alteracao_cadastral','codigo_log_alteracao_cadastral') sequence_auditoria;

SELECT 'TRIGGERS_HU_ATUAIS' grupo,c.relname tabela,t.tgname,t.tgenabled,p.oid::regprocedure funcao,pg_get_triggerdef(t.oid,true) definicao
FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace JOIN pg_proc p ON p.oid=t.tgfoid
WHERE NOT t.tgisinternal AND n.nspname='desenvolvimento' AND t.tgname IN (
 'trg_hu_caixa_log_alteracao_cadastral','trg_hu_caixa_pesagem_log_alteracao_cadastral','trg_hu_caixa_integracao_sap_log_alteracao_cadastral')
ORDER BY c.relname,t.tgname;

ROLLBACK;
\echo 'CLASSIFICACAO_OFICIAL=PREFLIGHT_044_DEV_REV11_APROVADO'
\echo 'PREFLIGHT 044 REV11 FINALIZADO - READ ONLY - NENHUMA ALTERACAO PERSISTIDA'
