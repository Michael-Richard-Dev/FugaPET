\set ON_ERROR_STOP on
\pset pager off
\pset tuples_only off
\pset format aligned
\pset null '<NULL>'

-- FugaPET - Incremental 044 DEV - PROPOSTA CORRETIVA REV11
-- DELTA POS-PROPOSTA REV10. Nao reaplica estruturas/regras HU da REV10.
-- Correcao exclusiva do runtime de auditoria sob fugapet_dev_app.

BEGIN;
SET LOCAL statement_timeout='10min';
SET LOCAL lock_timeout='10s';

DO $gaia$
DECLARE v_version integer:=current_setting('server_version_num')::integer; v_generic oid; v_count integer; v_dml integer; v_seq text;
BEGIN
  IF current_database()<>'fuga_jales_local_desenvolvimento' OR current_user<>'postgres' THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_AMBIENTE_OU_EXECUTOR_INVALIDO'; END IF;
  IF v_version<150005 OR v_version>=160000 THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_POSTGRESQL_INCOMPATIVEL versao=%',v_version; END IF;
  IF to_regprocedure('desenvolvimento.fn_hu_registrar_log_alteracao_cadastral()') IS NOT NULL THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_JA_APLICADA'; END IF;
  IF to_regprocedure('desenvolvimento.fn_hu_caixa_pesagem_normalizar()') IS NULL
     OR to_regprocedure('desenvolvimento.fn_hu_caixa_bloquear_configuracao(bigint,bigint,text,text,jsonb)') IS NULL
     OR NOT EXISTS(SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace
                   WHERE n.nspname='desenvolvimento' AND c.relname='hu_caixa_pesagem' AND t.tgname='trg_hu_caixa_pesagem_normalizar'
                     AND NOT t.tgisinternal AND t.tgenabled<>'D') THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_REV10_COMPLEMENTOS_AUSENTES'; END IF;
  v_generic:=to_regprocedure('desenvolvimento.fn_registrar_log_alteracao_cadastral()');
  IF v_generic IS NULL THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_FUNCAO_GENERICA_AUSENTE'; END IF;
  IF (SELECT prosecdef FROM pg_proc WHERE oid=v_generic) OR (SELECT pg_get_userbyid(proowner)<>'postgres' FROM pg_proc WHERE oid=v_generic) THEN
    RAISE EXCEPTION 'PROPOSTA_044_REV11_FUNCAO_GENERICA_ESTADO_INESPERADO';
  END IF;
  SELECT count(*) INTO v_count FROM (VALUES
    ('hu_caixa','trg_hu_caixa_log_alteracao_cadastral'),
    ('hu_caixa_pesagem','trg_hu_caixa_pesagem_log_alteracao_cadastral'),
    ('hu_caixa_integracao_sap','trg_hu_caixa_integracao_sap_log_alteracao_cadastral')) x(tabela,trigger_name)
    JOIN pg_class c ON c.relname=x.tabela JOIN pg_namespace n ON n.oid=c.relnamespace AND n.nspname='desenvolvimento'
    JOIN pg_trigger t ON t.tgrelid=c.oid AND t.tgname=x.trigger_name AND NOT t.tgisinternal
    WHERE t.tgenabled<>'D' AND t.tgfoid=v_generic;
  IF v_count<>3 THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_TRIGGERS_ORIGINAIS_DIVERGENTES quantidade=%/3',v_count; END IF;
  SELECT has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','INSERT')::int+
         has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','UPDATE')::int+
         has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','DELETE')::int INTO v_dml;
  IF v_dml<>0 THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_APP_DML_DIRETO_LOG_INESPERADO'; END IF;
  v_seq:=pg_get_serial_sequence('desenvolvimento.log_alteracao_cadastral','codigo_log_alteracao_cadastral');
  IF v_seq IS NOT NULL AND has_sequence_privilege('fugapet_dev_app',v_seq,'USAGE') THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_APP_USAGE_SEQUENCE_AUDITORIA_INESPERADO'; END IF;
END
$gaia$;

LOCK TABLE desenvolvimento.hu_caixa IN SHARE ROW EXCLUSIVE MODE;
LOCK TABLE desenvolvimento.hu_caixa_pesagem IN SHARE ROW EXCLUSIVE MODE;
LOCK TABLE desenvolvimento.hu_caixa_integracao_sap IN SHARE ROW EXCLUSIVE MODE;
LOCK TABLE desenvolvimento.log_alteracao_cadastral IN ROW EXCLUSIVE MODE;

CREATE OR REPLACE FUNCTION desenvolvimento.fn_hu_registrar_log_alteracao_cadastral()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $func$
DECLARE
    v_tabela text := TG_TABLE_NAME;
    v_coluna_codigo text := 'codigo_' || TG_TABLE_NAME;
    v_coluna_situacao text := 'situacao_' || TG_TABLE_NAME;
    v_situacao_anterior boolean;
    v_situacao_nova boolean;
    v_coluna_criado_por_tabela text := TG_TABLE_NAME || '_criado_por';
    v_coluna_atualizado_por_tabela text := TG_TABLE_NAME || '_atualizado_por';
    v_coluna_excluido_por_tabela text := TG_TABLE_NAME || '_excluido_por';
    v_coluna_criado_por text := 'criado_por';
    v_coluna_atualizado_por text := 'atualizado_por';
    v_coluna_excluido_por text := 'excluido_por';
    v_dados_anteriores jsonb;
    v_dados_novos jsonb;
    v_codigo_registro bigint;
    v_codigo_usuario bigint;
    v_operacao varchar(20);
BEGIN
    IF TG_TABLE_SCHEMA <> 'desenvolvimento' OR NOT (
        (TG_TABLE_NAME='hu_caixa' AND TG_NAME='trg_hu_caixa_log_alteracao_cadastral') OR
        (TG_TABLE_NAME='hu_caixa_pesagem' AND TG_NAME='trg_hu_caixa_pesagem_log_alteracao_cadastral') OR
        (TG_TABLE_NAME='hu_caixa_integracao_sap' AND TG_NAME='trg_hu_caixa_integracao_sap_log_alteracao_cadastral')
    ) THEN
        RAISE EXCEPTION 'FN_HU_AUDITORIA_CONTEXTO_NAO_AUTORIZADO schema=% tabela=% trigger=%',TG_TABLE_SCHEMA,TG_TABLE_NAME,TG_NAME;
    END IF;

    IF TG_OP='INSERT' THEN
        v_operacao:='INSERT';
        v_dados_anteriores:=NULL;
        v_dados_novos:=to_jsonb(NEW)-'senha_hash';
    ELSIF TG_OP='UPDATE' THEN
        v_dados_anteriores:=to_jsonb(OLD)-'senha_hash';
        v_dados_novos:=to_jsonb(NEW)-'senha_hash';
        v_situacao_anterior:=NULLIF(v_dados_anteriores->>v_coluna_situacao,'')::boolean;
        v_situacao_nova:=NULLIF(v_dados_novos->>v_coluna_situacao,'')::boolean;
        IF v_situacao_anterior=true AND v_situacao_nova=false THEN v_operacao:='DELETE_LOGICO';
        ELSIF v_situacao_anterior=false AND v_situacao_nova=true THEN v_operacao:='REATIVACAO';
        ELSE v_operacao:='UPDATE'; END IF;
    ELSIF TG_OP='DELETE' THEN
        v_operacao:='DELETE_LOGICO';
        v_dados_anteriores:=to_jsonb(OLD)-'senha_hash';
        v_dados_novos:=NULL;
    ELSE
        RETURN COALESCE(NEW,OLD);
    END IF;

    v_codigo_registro:=COALESCE(
        NULLIF(v_dados_novos->>v_coluna_codigo,'')::bigint,
        NULLIF(v_dados_anteriores->>v_coluna_codigo,'')::bigint
    );

    v_codigo_usuario:=COALESCE(
        NULLIF(v_dados_novos->>v_coluna_atualizado_por_tabela,'')::bigint,
        NULLIF(v_dados_novos->>v_coluna_criado_por_tabela,'')::bigint,
        NULLIF(v_dados_novos->>v_coluna_excluido_por_tabela,'')::bigint,
        NULLIF(v_dados_novos->>v_coluna_atualizado_por,'')::bigint,
        NULLIF(v_dados_novos->>v_coluna_criado_por,'')::bigint,
        NULLIF(v_dados_novos->>v_coluna_excluido_por,'')::bigint,
        NULLIF(v_dados_anteriores->>v_coluna_atualizado_por_tabela,'')::bigint,
        NULLIF(v_dados_anteriores->>v_coluna_criado_por_tabela,'')::bigint,
        NULLIF(v_dados_anteriores->>v_coluna_excluido_por_tabela,'')::bigint,
        NULLIF(v_dados_anteriores->>v_coluna_atualizado_por,'')::bigint,
        NULLIF(v_dados_anteriores->>v_coluna_criado_por,'')::bigint,
        NULLIF(v_dados_anteriores->>v_coluna_excluido_por,'')::bigint
    );
    v_codigo_usuario:=COALESCE(v_codigo_usuario,NULLIF(current_setting('app.usuario_id',true),'')::bigint);

    IF v_codigo_registro IS NULL THEN RETURN COALESCE(NEW,OLD); END IF;

    IF v_operacao='INSERT' THEN
        INSERT INTO desenvolvimento.log_alteracao_cadastral(
          tabela,codigo_registro,operacao,dados_anteriores,dados_novos,codigo_usuario,
          log_alteracao_cadastral_criado_por,log_alteracao_cadastral_criado_em,situacao_log_alteracao_cadastral)
        VALUES(v_tabela,v_codigo_registro,v_operacao,v_dados_anteriores,v_dados_novos,v_codigo_usuario,
          v_codigo_usuario,now(),true);
    ELSIF v_operacao='UPDATE' THEN
        INSERT INTO desenvolvimento.log_alteracao_cadastral(
          tabela,codigo_registro,operacao,dados_anteriores,dados_novos,codigo_usuario,
          log_alteracao_cadastral_atualizado_por,log_alteracao_cadastral_atualizado_em,situacao_log_alteracao_cadastral)
        VALUES(v_tabela,v_codigo_registro,v_operacao,v_dados_anteriores,v_dados_novos,v_codigo_usuario,
          v_codigo_usuario,now(),true);
    ELSIF v_operacao='DELETE_LOGICO' THEN
        INSERT INTO desenvolvimento.log_alteracao_cadastral(
          tabela,codigo_registro,operacao,dados_anteriores,dados_novos,codigo_usuario,
          log_alteracao_cadastral_excluido_por,log_alteracao_cadastral_excluido_em,situacao_log_alteracao_cadastral)
        VALUES(v_tabela,v_codigo_registro,v_operacao,v_dados_anteriores,v_dados_novos,v_codigo_usuario,
          v_codigo_usuario,now(),true);
    ELSIF v_operacao='REATIVACAO' THEN
        INSERT INTO desenvolvimento.log_alteracao_cadastral(
          tabela,codigo_registro,operacao,dados_anteriores,dados_novos,codigo_usuario,
          log_alteracao_cadastral_atualizado_por,log_alteracao_cadastral_atualizado_em,situacao_log_alteracao_cadastral)
        VALUES(v_tabela,v_codigo_registro,v_operacao,v_dados_anteriores,v_dados_novos,v_codigo_usuario,
          v_codigo_usuario,now(),true);
    END IF;
    RETURN COALESCE(NEW,OLD);
END
$func$;

ALTER FUNCTION desenvolvimento.fn_hu_registrar_log_alteracao_cadastral() OWNER TO postgres;
REVOKE ALL ON FUNCTION desenvolvimento.fn_hu_registrar_log_alteracao_cadastral() FROM PUBLIC;
REVOKE ALL ON FUNCTION desenvolvimento.fn_hu_registrar_log_alteracao_cadastral() FROM fugapet_dev_app;
COMMENT ON FUNCTION desenvolvimento.fn_hu_registrar_log_alteracao_cadastral() IS
'FugaPET 044 REV11: auditoria SECURITY DEFINER restrita aos tres triggers HU, sem DML direto do app no log.';

DROP TRIGGER trg_hu_caixa_log_alteracao_cadastral ON desenvolvimento.hu_caixa;
CREATE TRIGGER trg_hu_caixa_log_alteracao_cadastral
AFTER INSERT OR UPDATE OR DELETE ON desenvolvimento.hu_caixa
FOR EACH ROW EXECUTE FUNCTION desenvolvimento.fn_hu_registrar_log_alteracao_cadastral();

DROP TRIGGER trg_hu_caixa_pesagem_log_alteracao_cadastral ON desenvolvimento.hu_caixa_pesagem;
CREATE TRIGGER trg_hu_caixa_pesagem_log_alteracao_cadastral
AFTER INSERT OR UPDATE OR DELETE ON desenvolvimento.hu_caixa_pesagem
FOR EACH ROW EXECUTE FUNCTION desenvolvimento.fn_hu_registrar_log_alteracao_cadastral();

DROP TRIGGER trg_hu_caixa_integracao_sap_log_alteracao_cadastral ON desenvolvimento.hu_caixa_integracao_sap;
CREATE TRIGGER trg_hu_caixa_integracao_sap_log_alteracao_cadastral
AFTER INSERT OR UPDATE OR DELETE ON desenvolvimento.hu_caixa_integracao_sap
FOR EACH ROW EXECUTE FUNCTION desenvolvimento.fn_hu_registrar_log_alteracao_cadastral();

DO $gaia$
DECLARE v_fn oid; v_count integer; v_dml integer; v_seq text; v_public integer; v_def text;
BEGIN
  v_fn:=to_regprocedure('desenvolvimento.fn_hu_registrar_log_alteracao_cadastral()');
  IF v_fn IS NULL THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_POSTCHECK_FUNCAO_AUSENTE'; END IF;
  SELECT count(*) INTO v_public FROM pg_proc p CROSS JOIN LATERAL aclexplode(COALESCE(p.proacl,acldefault('f',p.proowner))) a WHERE p.oid=v_fn AND a.grantee=0 AND a.privilege_type='EXECUTE';
  SELECT pg_get_functiondef(v_fn) INTO v_def;
  IF (SELECT pg_get_userbyid(proowner)<>'postgres' OR NOT prosecdef OR NOT (COALESCE(proconfig,ARRAY[]::text[]) @> ARRAY['search_path=pg_catalog']) FROM pg_proc WHERE oid=v_fn) THEN
    RAISE EXCEPTION 'PROPOSTA_044_REV11_POSTCHECK_HARDENING_FUNCAO';
  END IF;
  IF v_public<>0 OR has_function_privilege('fugapet_dev_app',v_fn,'EXECUTE') THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_POSTCHECK_EXECUTE_INDEVIDO public=% app=%',v_public,has_function_privilege('fugapet_dev_app',v_fn,'EXECUTE'); END IF;
  IF v_def ~* '\mEXECUTE\M' OR v_def ~* '\mformat\s*\(' OR position('TG_TABLE_SCHEMA' IN v_def)=0 OR position('desenvolvimento.log_alteracao_cadastral' IN v_def)=0 THEN
    RAISE EXCEPTION 'PROPOSTA_044_REV11_POSTCHECK_CORPO_FUNCAO_INSEGURO';
  END IF;
  SELECT count(*) INTO v_count FROM (VALUES
    ('hu_caixa','trg_hu_caixa_log_alteracao_cadastral'),
    ('hu_caixa_pesagem','trg_hu_caixa_pesagem_log_alteracao_cadastral'),
    ('hu_caixa_integracao_sap','trg_hu_caixa_integracao_sap_log_alteracao_cadastral')) x(tabela,trigger_name)
    JOIN pg_class c ON c.relname=x.tabela JOIN pg_namespace n ON n.oid=c.relnamespace AND n.nspname='desenvolvimento'
    JOIN pg_trigger t ON t.tgrelid=c.oid AND t.tgname=x.trigger_name AND NOT t.tgisinternal
    WHERE t.tgenabled<>'D' AND t.tgfoid=v_fn;
  IF v_count<>3 THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_POSTCHECK_TRIGGERS quantidade=%/3',v_count; END IF;
  SELECT has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','INSERT')::int+
         has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','UPDATE')::int+
         has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','DELETE')::int INTO v_dml;
  IF v_dml<>0 THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_POSTCHECK_APP_DML_LOG'; END IF;
  v_seq:=pg_get_serial_sequence('desenvolvimento.log_alteracao_cadastral','codigo_log_alteracao_cadastral');
  IF v_seq IS NOT NULL AND has_sequence_privilege('fugapet_dev_app',v_seq,'USAGE') THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_POSTCHECK_APP_SEQUENCE'; END IF;
  IF (SELECT prosecdef FROM pg_proc WHERE oid=to_regprocedure('desenvolvimento.fn_registrar_log_alteracao_cadastral()')) THEN RAISE EXCEPTION 'PROPOSTA_044_REV11_FUNCAO_GENERICA_ALTERADA_INDEVIDAMENTE'; END IF;
  RAISE NOTICE 'CLASSIFICACAO_OFICIAL=PROPOSTA_044_DEV_REV11_CORRECAO_AUDITORIA_APLICADA_COM_SUCESSO';
  RAISE NOTICE 'ESTRATEGIA=FUNCAO_DEDICADA_HU_SECURITY_DEFINER';
  RAISE NOTICE 'DML_DIRETO_APP_LOG=0';
END
$gaia$;

COMMIT;
\echo 'CLASSIFICACAO_OFICIAL=PROPOSTA_044_DEV_REV11_CORRECAO_AUDITORIA_APLICADA_COM_SUCESSO'
\echo 'OK - delta 044 DEV REV11 aplicado; REV10 preservada'
