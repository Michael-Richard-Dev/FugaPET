FugaPET — 044 REV11 — CORRECAO POS-PROPOSTA DA AUDITORIA DO RUNTIME

PACOTE: 044_produto_acabado_hu_caixa_GAIA_DEV_REV11_CORRECAO_AUDITORIA.zip
BASE: 044_produto_acabado_hu_caixa_GAIA_DEV_REV10.zip
SHA256_BASE_REV10: 7E90E5193442BEB92A90A7EC519B90A4C6D51F368E9FC61883E3E19426F66866
VALIDACAO_REV10_ORIGINAL_SHA256: C243096576EF6C527620D81028D86D47E4C139DD9F2F6D5CEB667CF47936E319

FINALIDADE
Este pacote e exclusivamente um DELTA POS-PROPOSTA. A PROPOSTA REV10 ja esta aplicada e NAO pode ser reexecutada.
A REV11 corrige o contrato de auditoria disparado pelos tres triggers HU quando o runtime opera sob fugapet_dev_app.

ESTRATEGIA
Foi escolhida funcao dedicada HU SECURITY DEFINER, em vez de converter a funcao generica historica. Essa escolha reduz o blast radius e preserva os consumidores antigos.

ARTEFATOS
1. 044_produto_acabado_hu_caixa_DEV_PREFLIGHT_GAIA_REV11.sql
2. 044_produto_acabado_hu_caixa_DEV_PROPOSTA_CORRECAO_GAIA_REV11.sql
3. 044_produto_acabado_hu_caixa_DEV_VALIDACAO_GAIA_REV11.sql
4. 044_produto_acabado_hu_caixa_DEV_ROLLBACK_GAIA_REV11.sql
5. README_044_PRODUTO_ACABADO_HU_CAIXA_GAIA_REV11.txt
6. RELATORIO_044_REV11_CAUSA_RAIZ_AUDITORIA.txt
7. DIFF_044_REV10_REV11.txt
8. MANIFEST_SHA256.txt

FLUXO OPERACIONAL RECOMENDADO — SOMENTE APOS AUTORIZACAO HERA
1. Executar PREFLIGHT REV11 uma unica vez; deve terminar com ROLLBACK e zero alteracoes.
2. Auditar o log do PREFLIGHT.
3. Se formalmente autorizado, executar PROPOSTA CORRETIVA REV11 uma unica vez; COMMIT unico.
4. Auditar o log da PROPOSTA.
5. Se formalmente autorizado, executar VALIDACAO REV11 uma unica vez; ROLLBACK interno obrigatorio.
6. A VALIDACAO deve comprovar runtime fugapet_dev_app + auditoria ativa + bloqueio de DML direto no log.
7. Nao exigir rollback da sequence de auditoria: reportar SEQUENCE_AUDITORIA_AVANCO e validar zero residuos transacionais.
8. ROLLBACK REV11 e somente contingencia formalmente autorizada; nunca remove a REV10.

PROIBICOES
- Nao reexecutar PROPOSTA REV10.
- Nao conceder INSERT/UPDATE/DELETE no log para fugapet_dev_app.
- Nao conceder USAGE direto da sequence da auditoria como solucao.
- Nao transformar a funcao generica global em SECURITY DEFINER.
- Nao desabilitar auditoria para fazer a validacao passar.
- Nao executar scripts deste ZIP sem autorizacao formal.

ESTADO DA MISSAO DE PREPARACAO
BANCO_ACESSADO=NAO
SQL_EXECUTADO=NAO
PREFLIGHT_EXECUTADO=NAO
PROPOSTA_EXECUTADA=NAO
VALIDACAO_EXECUTADA=NAO
ROLLBACK_EXECUTADO=NAO
SAP_ACESSADO=NAO
CPI_ACESSADO=NAO
CSHARP_ALTERADO=NAO
HML_ACESSADO=NAO
PRD_ACESSADO=NAO
COMMIT_GIT=NAO
PUSH_GIT=NAO

DESTINO: auditoria estatica unica do DEDALO antes de qualquer execucao.
