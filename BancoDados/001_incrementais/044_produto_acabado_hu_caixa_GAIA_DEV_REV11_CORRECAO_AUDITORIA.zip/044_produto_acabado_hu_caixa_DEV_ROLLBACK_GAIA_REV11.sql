\set ON_ERROR_STOP on
\pset pager off
\pset tuples_only off
\pset format aligned
\pset null '<NULL>'

-- FugaPET - Incremental 044 DEV - ROLLBACK REV11 CORRECAO AUDITORIA
-- Remove somente o delta REV11. REV10 permanece integralmente aplicada.

BEGIN;
SET LOCAL statement_timeout='10min';
SET LOCAL lock_timeout='10s';

DO $gaia$
DECLARE v_fn oid; v_count integer;
BEGIN
 IF current_database()<>'fuga_jales_local_desenvolvimento' OR current_user<>'postgres' THEN RAISE EXCEPTION 'ROLLBACK_044_REV11_AMBIENTE_OU_EXECUTOR_INVALIDO'; END IF;
 v_fn:=to_regprocedure('desenvolvimento.fn_hu_registrar_log_alteracao_cadastral()');
 IF v_fn IS NULL THEN RAISE EXCEPTION 'ROLLBACK_044_REV11_FUNCAO_DEDICADA_AUSENTE'; END IF;
 SELECT count(*) INTO v_count FROM (VALUES ('hu_caixa','trg_hu_caixa_log_alteracao_cadastral'),('hu_caixa_pesagem','trg_hu_caixa_pesagem_log_alteracao_cadastral'),('hu_caixa_integracao_sap','trg_hu_caixa_integracao_sap_log_alteracao_cadastral')) x(tabela,trigger_name)
 JOIN pg_class c ON c.relname=x.tabela JOIN pg_namespace n ON n.oid=c.relnamespace AND n.nspname='desenvolvimento' JOIN pg_trigger t ON t.tgrelid=c.oid AND t.tgname=x.trigger_name AND NOT t.tgisinternal
 WHERE t.tgfoid=v_fn;
 IF v_count<>3 THEN RAISE EXCEPTION 'ROLLBACK_044_REV11_TRIGGERS_NAO_ESTAO_NO_DELTA quantidade=%/3',v_count; END IF;
 IF to_regprocedure('desenvolvimento.fn_registrar_log_alteracao_cadastral()') IS NULL THEN RAISE EXCEPTION 'ROLLBACK_044_REV11_FUNCAO_GENERICA_AUSENTE'; END IF;
END $gaia$;

LOCK TABLE desenvolvimento.hu_caixa IN SHARE ROW EXCLUSIVE MODE;
LOCK TABLE desenvolvimento.hu_caixa_pesagem IN SHARE ROW EXCLUSIVE MODE;
LOCK TABLE desenvolvimento.hu_caixa_integracao_sap IN SHARE ROW EXCLUSIVE MODE;

DROP TRIGGER trg_hu_caixa_log_alteracao_cadastral ON desenvolvimento.hu_caixa;
CREATE TRIGGER trg_hu_caixa_log_alteracao_cadastral
AFTER INSERT OR UPDATE OR DELETE ON desenvolvimento.hu_caixa
FOR EACH ROW EXECUTE FUNCTION desenvolvimento.fn_registrar_log_alteracao_cadastral();

DROP TRIGGER trg_hu_caixa_pesagem_log_alteracao_cadastral ON desenvolvimento.hu_caixa_pesagem;
CREATE TRIGGER trg_hu_caixa_pesagem_log_alteracao_cadastral
AFTER INSERT OR UPDATE OR DELETE ON desenvolvimento.hu_caixa_pesagem
FOR EACH ROW EXECUTE FUNCTION desenvolvimento.fn_registrar_log_alteracao_cadastral();

DROP TRIGGER trg_hu_caixa_integracao_sap_log_alteracao_cadastral ON desenvolvimento.hu_caixa_integracao_sap;
CREATE TRIGGER trg_hu_caixa_integracao_sap_log_alteracao_cadastral
AFTER INSERT OR UPDATE OR DELETE ON desenvolvimento.hu_caixa_integracao_sap
FOR EACH ROW EXECUTE FUNCTION desenvolvimento.fn_registrar_log_alteracao_cadastral();

DROP FUNCTION desenvolvimento.fn_hu_registrar_log_alteracao_cadastral();

DO $gaia$
DECLARE v_generic oid; v_count integer; v_dml integer;
BEGIN
 IF to_regprocedure('desenvolvimento.fn_hu_registrar_log_alteracao_cadastral()') IS NOT NULL THEN RAISE EXCEPTION 'ROLLBACK_044_REV11_FUNCAO_DEDICADA_PERMANECEU'; END IF;
 v_generic:=to_regprocedure('desenvolvimento.fn_registrar_log_alteracao_cadastral()');
 IF v_generic IS NULL OR (SELECT prosecdef FROM pg_proc WHERE oid=v_generic) THEN RAISE EXCEPTION 'ROLLBACK_044_REV11_FUNCAO_GENERICA_DIVERGENTE'; END IF;
 SELECT count(*) INTO v_count FROM (VALUES ('hu_caixa','trg_hu_caixa_log_alteracao_cadastral'),('hu_caixa_pesagem','trg_hu_caixa_pesagem_log_alteracao_cadastral'),('hu_caixa_integracao_sap','trg_hu_caixa_integracao_sap_log_alteracao_cadastral')) x(tabela,trigger_name)
 JOIN pg_class c ON c.relname=x.tabela JOIN pg_namespace n ON n.oid=c.relnamespace AND n.nspname='desenvolvimento' JOIN pg_trigger t ON t.tgrelid=c.oid AND t.tgname=x.trigger_name AND NOT t.tgisinternal
 WHERE t.tgfoid=v_generic;
 IF v_count<>3 THEN RAISE EXCEPTION 'ROLLBACK_044_REV11_TRIGGERS_GENERICOS_NAO_RESTAURADOS quantidade=%/3',v_count; END IF;
 SELECT has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','INSERT')::int+has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','UPDATE')::int+has_table_privilege('fugapet_dev_app','desenvolvimento.log_alteracao_cadastral','DELETE')::int INTO v_dml;
 IF v_dml<>0 THEN RAISE EXCEPTION 'ROLLBACK_044_REV11_APP_DML_LOG_INDEVIDO'; END IF;
 RAISE NOTICE 'CLASSIFICACAO_OFICIAL=ROLLBACK_044_DEV_REV11_CONCLUIDO_REV10_PRESERVADA';
END $gaia$;

COMMIT;
\echo 'CLASSIFICACAO_OFICIAL=ROLLBACK_044_DEV_REV11_CONCLUIDO_REV10_PRESERVADA'
\echo 'OK - somente delta REV11 removido; REV10 preservada'
