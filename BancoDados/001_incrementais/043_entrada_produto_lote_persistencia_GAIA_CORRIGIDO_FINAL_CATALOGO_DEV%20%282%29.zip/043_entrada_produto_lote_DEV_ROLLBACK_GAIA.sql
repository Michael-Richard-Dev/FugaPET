\set ON_ERROR_STOP on
-- ============================================================================
-- 043_entrada_produto_lote_DEV_ROLLBACK_GAIA.sql
-- ROLLBACK OFICIAL, SEPARADO E NUNCA AUTOMATICO.
--
-- Exige:
--   -v CONFIRMAR_ROLLBACK_043=EU_CONFIRMO_ROLLBACK_043_DEV
--
-- Bloqueia quando houver qualquer lote registrado ou pesagem vinculada.
-- NAO apaga lancamentos, itens ou pesagens historicas.
-- NAO toca em HML/PRD nem em integracoes anteriores.
-- ============================================================================

\if :{?CONFIRMAR_ROLLBACK_043}
\else
    \echo 'ROLLBACK 043 BLOQUEADO: informe -v CONFIRMAR_ROLLBACK_043=EU_CONFIRMO_ROLLBACK_043_DEV'
    \quit 43
\endif

SELECT
    :'CONFIRMAR_ROLLBACK_043' =
    'EU_CONFIRMO_ROLLBACK_043_DEV' AS confirmacao_ok
\gset

\if :confirmacao_ok
\else
    \echo 'ROLLBACK 043 BLOQUEADO: confirmacao explicita incorreta.'
    \quit 44
\endif

SET search_path TO desenvolvimento, public;

BEGIN;
SET LOCAL lock_timeout = '10s';
SET LOCAL statement_timeout = '5min';

DO $$
DECLARE
    v_tabela_lote integer;
    v_colunas_pesagem integer;
    v_lotes bigint;
    v_pesagens_vinculadas bigint;
BEGIN
    IF current_database() <> 'fuga_jales_local_desenvolvimento' THEN
        RAISE EXCEPTION
            'CLASSIFICACAO_OFICIAL=ROLLBACK_REPROVADO_BANCO_INCORRETO banco_atual=%',
            current_database();
    END IF;

    SELECT count(*)
      INTO v_tabela_lote
      FROM information_schema.tables
     WHERE table_schema = 'desenvolvimento'
       AND table_name = 'entrada_produto_lote';

    SELECT count(*)
      INTO v_colunas_pesagem
      FROM information_schema.columns
     WHERE table_schema = 'desenvolvimento'
       AND table_name = 'entrada_produto_pesagem'
       AND column_name IN (
           'codigo_entrada_produto_lote',
           'numero_lote_snapshot',
           'data_fabricacao_snapshot',
           'data_vencimento_snapshot'
       );

    IF v_tabela_lote <> 1 OR v_colunas_pesagem <> 4 THEN
        RAISE EXCEPTION
            'CLASSIFICACAO_OFICIAL=ROLLBACK_BLOQUEADO_ESTRUTURA_PARCIAL tabela_lote=% colunas_pesagem=%/4',
            v_tabela_lote,
            v_colunas_pesagem;
    END IF;

    SELECT count(*)
      INTO v_lotes
      FROM desenvolvimento.entrada_produto_lote;

    SELECT count(*)
      INTO v_pesagens_vinculadas
      FROM desenvolvimento.entrada_produto_pesagem
     WHERE codigo_entrada_produto_lote IS NOT NULL
        OR numero_lote_snapshot IS NOT NULL
        OR data_fabricacao_snapshot IS NOT NULL
        OR data_vencimento_snapshot IS NOT NULL;

    IF v_lotes <> 0 OR v_pesagens_vinculadas <> 0 THEN
        RAISE EXCEPTION
            'CLASSIFICACAO_OFICIAL=ROLLBACK_BLOQUEADO_DADOS_PRODUTIVOS lotes=% pesagens_vinculadas=%',
            v_lotes,
            v_pesagens_vinculadas;
    END IF;

    RAISE NOTICE
        'ROLLBACK 043 PRECHECK OK: sem lotes e sem pesagens vinculadas.';
END $$;

DROP TRIGGER trg_entrada_produto_pesagem_recalcular_lote
ON desenvolvimento.entrada_produto_pesagem;

DROP TRIGGER trg_entrada_produto_pesagem_validar_lote
ON desenvolvimento.entrada_produto_pesagem;

DROP TRIGGER trg_entrada_produto_lote_proteger_update
ON desenvolvimento.entrada_produto_lote;

DROP INDEX desenvolvimento.ix_entrada_pesagem_lote;

ALTER TABLE desenvolvimento.entrada_produto_pesagem
    DROP CONSTRAINT ck_entrada_pesagem_lote_snapshot_conjunto;

ALTER TABLE desenvolvimento.entrada_produto_pesagem
    DROP CONSTRAINT fk_entrada_pesagem_lote;

ALTER TABLE desenvolvimento.entrada_produto_pesagem
    DROP COLUMN data_vencimento_snapshot,
    DROP COLUMN data_fabricacao_snapshot,
    DROP COLUMN numero_lote_snapshot,
    DROP COLUMN codigo_entrada_produto_lote;

DROP FUNCTION desenvolvimento.fn_entrada_produto_pesagem_recalcular_lote();
DROP FUNCTION desenvolvimento.fn_entrada_produto_lote_recalcular_peso(bigint);
DROP FUNCTION desenvolvimento.fn_entrada_produto_pesagem_validar_lote_snapshot();
DROP FUNCTION desenvolvimento.fn_entrada_produto_lote_proteger_update();

DROP TABLE desenvolvimento.entrada_produto_lote;

-- Matriz anterior oficial do DEV, diagnosticada em 2026-07-24:
-- fugapet_dev_app nao possuia qualquer privilegio nas tres tabelas base
-- nem nas tres sequences identity. O rollback restaura exatamente essa matriz.
REVOKE ALL PRIVILEGES
ON TABLE
    desenvolvimento.entrada_produto_lancamento,
    desenvolvimento.entrada_produto_item,
    desenvolvimento.entrada_produto_pesagem
FROM fugapet_dev_app;

DO $$
DECLARE
    v_tabela text;
    v_coluna text;
    v_sequence text;
BEGIN
    FOR v_tabela, v_coluna IN
        SELECT *
        FROM (VALUES
            ('desenvolvimento.entrada_produto_lancamento', 'codigo_entrada_produto_lancamento'),
            ('desenvolvimento.entrada_produto_item', 'codigo_entrada_produto_item'),
            ('desenvolvimento.entrada_produto_pesagem', 'codigo_entrada_produto_pesagem')
        ) AS alvo(tabela, coluna)
    LOOP
        v_sequence := pg_get_serial_sequence(v_tabela, v_coluna);
        IF v_sequence IS NULL THEN
            RAISE EXCEPTION
                'CLASSIFICACAO_OFICIAL=ROLLBACK_REPROVADO_SEQUENCE_BASE_NAO_RESOLVIDA tabela=% coluna=%',
                v_tabela,
                v_coluna;
        END IF;
        EXECUTE format(
            'REVOKE ALL PRIVILEGES ON SEQUENCE %s FROM fugapet_dev_app',
            v_sequence::regclass
        );
    END LOOP;
END $$;

DO $$
DECLARE
    v_sequence_conformes integer;
    v_owner_conformes integer;
BEGIN
    IF to_regclass('desenvolvimento.entrada_produto_lote') IS NOT NULL THEN
        RAISE EXCEPTION
            'CLASSIFICACAO_OFICIAL=ROLLBACK_REPROVADO_TABELA_LOTE_AINDA_EXISTE';
    END IF;

    IF EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = 'desenvolvimento'
          AND table_name = 'entrada_produto_pesagem'
          AND column_name IN (
              'codigo_entrada_produto_lote',
              'numero_lote_snapshot',
              'data_fabricacao_snapshot',
              'data_vencimento_snapshot'
          )
    ) THEN
        RAISE EXCEPTION
            'CLASSIFICACAO_OFICIAL=ROLLBACK_REPROVADO_COLUNAS_043_AINDA_EXISTEM';
    END IF;

    IF to_regclass('desenvolvimento.entrada_produto_lancamento') IS NULL
       OR to_regclass('desenvolvimento.entrada_produto_item') IS NULL
       OR to_regclass('desenvolvimento.entrada_produto_pesagem') IS NULL THEN
        RAISE EXCEPTION
            'CLASSIFICACAO_OFICIAL=ROLLBACK_REPROVADO_TABELAS_HISTORICAS_AFETADAS';
    END IF;

    IF EXISTS (
        SELECT 1
        FROM (VALUES
            ('desenvolvimento.entrada_produto_lancamento'),
            ('desenvolvimento.entrada_produto_item'),
            ('desenvolvimento.entrada_produto_pesagem')
        ) AS alvo(tabela)
        WHERE has_table_privilege('fugapet_dev_app', alvo.tabela, 'SELECT')
           OR has_table_privilege('fugapet_dev_app', alvo.tabela, 'INSERT')
           OR has_table_privilege('fugapet_dev_app', alvo.tabela, 'UPDATE')
           OR has_table_privilege('fugapet_dev_app', alvo.tabela, 'DELETE')
           OR has_table_privilege('fugapet_dev_app', alvo.tabela, 'TRUNCATE')
           OR has_table_privilege('fugapet_dev_app', alvo.tabela, 'REFERENCES')
           OR has_table_privilege('fugapet_dev_app', alvo.tabela, 'TRIGGER')
    ) THEN
        RAISE EXCEPTION
            'CLASSIFICACAO_OFICIAL=ROLLBACK_REPROVADO_MATRIZ_TABELAS_BASE_NAO_RESTAURADA';
    END IF;

    WITH seq AS (
        SELECT pg_get_serial_sequence(tabela, coluna) AS sequence_name
        FROM (VALUES
            ('desenvolvimento.entrada_produto_lancamento', 'codigo_entrada_produto_lancamento'),
            ('desenvolvimento.entrada_produto_item', 'codigo_entrada_produto_item'),
            ('desenvolvimento.entrada_produto_pesagem', 'codigo_entrada_produto_pesagem')
        ) AS alvo(tabela, coluna)
    )
    SELECT count(*)
      INTO v_sequence_conformes
      FROM seq
     WHERE sequence_name IS NOT NULL
       AND NOT has_sequence_privilege('fugapet_dev_app', sequence_name, 'USAGE')
       AND NOT has_sequence_privilege('fugapet_dev_app', sequence_name, 'SELECT')
       AND NOT has_sequence_privilege('fugapet_dev_app', sequence_name, 'UPDATE');

    IF v_sequence_conformes <> 3 THEN
        RAISE EXCEPTION
            'CLASSIFICACAO_OFICIAL=ROLLBACK_REPROVADO_MATRIZ_SEQUENCES_BASE_NAO_RESTAURADA conformes=%/3',
            v_sequence_conformes;
    END IF;

    WITH objetos AS (
        SELECT 'desenvolvimento.entrada_produto_lancamento'::regclass AS oid
        UNION ALL SELECT 'desenvolvimento.entrada_produto_item'::regclass
        UNION ALL SELECT 'desenvolvimento.entrada_produto_pesagem'::regclass
        UNION ALL SELECT pg_get_serial_sequence('desenvolvimento.entrada_produto_lancamento', 'codigo_entrada_produto_lancamento')::regclass
        UNION ALL SELECT pg_get_serial_sequence('desenvolvimento.entrada_produto_item', 'codigo_entrada_produto_item')::regclass
        UNION ALL SELECT pg_get_serial_sequence('desenvolvimento.entrada_produto_pesagem', 'codigo_entrada_produto_pesagem')::regclass
    )
    SELECT count(*)
      INTO v_owner_conformes
      FROM objetos o
      JOIN pg_class c ON c.oid = o.oid
      JOIN pg_roles r ON r.oid = c.relowner
     WHERE r.rolname = 'postgres';

    IF v_owner_conformes <> 6 THEN
        RAISE EXCEPTION
            'CLASSIFICACAO_OFICIAL=ROLLBACK_REPROVADO_OWNER_BASE_ALTERADO conformes=%/6',
            v_owner_conformes;
    END IF;

    IF NOT has_database_privilege(
        'fugapet_dev_app',
        current_database(),
        'CONNECT'
    )
    OR NOT has_schema_privilege(
        'fugapet_dev_app',
        'desenvolvimento',
        'USAGE'
    )
    OR has_schema_privilege(
        'fugapet_dev_app',
        'desenvolvimento',
        'CREATE'
    ) THEN
        RAISE EXCEPTION
            'CLASSIFICACAO_OFICIAL=ROLLBACK_REPROVADO_MATRIZ_BANCO_SCHEMA_NAO_RESTAURADA';
    END IF;

    RAISE NOTICE 'CLASSIFICACAO_OFICIAL=ROLLBACK_043_CONCLUIDO_COM_SUCESSO';
    RAISE NOTICE 'ROLLBACK 043 OK: objetos 043 removidos e matriz anterior de grants restaurada.';
END $$;

COMMIT;

\echo 'OK - ROLLBACK 043 DEV concluido'
