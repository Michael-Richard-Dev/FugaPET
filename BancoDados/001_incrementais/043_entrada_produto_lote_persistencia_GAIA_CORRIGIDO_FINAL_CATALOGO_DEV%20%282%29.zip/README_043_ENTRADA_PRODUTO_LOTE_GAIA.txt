FUGAPET - INCREMENTAL 043 DEV
PERSISTENCIA POR LOTE DA ENTRADA DE MATERIA-PRIMA E PRODUTOS QUIMICOS
Responsavel: Michael Richard
Pacote: 043_entrada_produto_lote_persistencia_GAIA_CORRIGIDO_FINAL_CATALOGO_DEV
Ambiente exclusivo: DEV
Banco esperado: fuga_jales_local_desenvolvimento
Schema: desenvolvimento
Papel da aplicacao: fugapet_dev_app

====================================================================
1. NUMERACAO
====================================================================

Foi utilizado o incremental 043.

Motivo:
- 041 esta reservado para persistencia do Resultado do Apontamento;
- 042 esta reservado para as futuras rotas e seeds vinculados ao 041;
- 043 e a proxima numeracao disponivel dentro do contexto aprovado.

Nenhum incremental anterior foi alterado ou reutilizado.

====================================================================
2. ESCOPO
====================================================================

O pacote cria a camada de persistencia por lote para a mesma
ProcessoEntradaProdutoForm utilizada em:

- Entrada de Materia-Prima;
- Entrada de Produtos Quimicos.

Campos funcionais destinados ao SAP:

- Batch;
- ManufactureDate;
- ShelfLifeExpirationDate.

O pacote NAO:
- altera codigo C#;
- insere lotes;
- cria lotes ficticios para historico;
- altera lancamentos, itens ou pesagens existentes;
- cria rotas;
- cria permissoes de tela;
- acessa ou promove HML/PRD.

====================================================================
3. DIAGRAMA DAS RELACOES
====================================================================

desenvolvimento.entrada_produto_lancamento
    1
    |
    +---- N desenvolvimento.entrada_produto_item
                 1
                 |
                 +---- N desenvolvimento.entrada_produto_lote
                              1
                              |
                              +---- N desenvolvimento.entrada_produto_pesagem

FKs novas:

entrada_produto_lote.codigo_entrada_produto_item
    -> entrada_produto_item.codigo_entrada_produto_item
    ON DELETE RESTRICT

entrada_produto_pesagem.codigo_entrada_produto_lote
    -> entrada_produto_lote.codigo_entrada_produto_lote
    ON DELETE RESTRICT

O lancamento continua representando a entrada/pedido.
O item continua representando o item do pedido.
Um item pode possuir varios lotes.
Cada lote e unidade independente de pesagem, envio SAP, idempotencia,
erro, reprocessamento, documento e impressao.

====================================================================
4. MATRIZ DE COLUNAS - ENTRADA_PRODUTO_LOTE
====================================================================

Coluna                                  Tipo              Nulo  Regra
codigo_entrada_produto_lote             bigint identity   nao   PK
codigo_entrada_produto_item             bigint            nao   FK RESTRICT
numero_lote                             varchar(10)       nao   Batch SAP
data_fabricacao                         date               nao   ManufactureDate
data_vencimento                         date               nao   ShelfLifeExpirationDate
peso_liquido_total_kg                   numeric(14,3)      nao   default 0
status_lote                             varchar(30)       nao   status controlado
correlation_id                          uuid               nao   unique global
documento_material_sap                  varchar(20)       sim
exercicio_documento_material_sap        varchar(4)        sim
documento_material_item                 varchar(10)       sim
batch_retornado_sap                     varchar(10)       sim
quantidade_retorno_sap                  numeric(14,3)      sim
payload_enviado_json                    jsonb              sim
resposta_sap_json                       jsonb              sim
erro_sanitizado                         text               sim
criado_em                               timestamptz        nao   clock_timestamp()
criado_por                              varchar(80)       nao
confirmado_em                           timestamptz        sim
enviado_sap_em                          timestamptz        sim
confirmado_sap_em                       timestamptz        sim
alterado_em                             timestamptz        sim
alterado_por                            varchar(80)       sim

Tamanho do lote:
numero_lote e batch_retornado_sap usam varchar(10) como decisao tecnica desta
versao.

O documento de API fornecido confirma a existencia dos campos Batch,
ManufactureDate e ShelfLifeExpirationDate, mas nao informa o facet/tamanho do
Batch. A confirmacao contratual do limite permanece pendente com Ares/SAP.
Qualquer mudanca futura de tamanho exige novo incremental; este pacote nao deve
ser alterado manualmente.

====================================================================
5. MATRIZ DE COLUNAS NOVAS - ENTRADA_PRODUTO_PESAGEM
====================================================================

Coluna                         Tipo          Nulo
codigo_entrada_produto_lote    bigint        sim
numero_lote_snapshot           varchar(10)  sim
data_fabricacao_snapshot       date          sim
data_vencimento_snapshot       date          sim

Compatibilidade historica:
- as quatro colunas sao adicionadas como nullable;
- registros antigos permanecem com as quatro colunas NULL;
- nao existe backfill;
- nao sao criados lotes ficticios;
- o fluxo novo deve informar as quatro colunas em conjunto;
- uma pesagem legada nunca vinculada pode permanecer com os quatro campos NULL;
- uma pesagem legada pode ser vinculada a um lote uma unica vez;
- depois da primeira vinculacao, nao pode voltar ao estado legado;
- a constraint condicionada aceita somente:
  a) todas NULL, para legado nunca vinculado;
  b) todas preenchidas, para o fluxo versionado por lote.

====================================================================
6. STATUS DO LOTE
====================================================================

Valores permitidos:

AGUARDANDO_DADOS
LOTE_CONFIRMADO
PESANDO
FINALIZADO_LOCAL
ENVIANDO_SAP
CONFIRMADO_SAP
ERRO_SAP
CANCELADO

O status do lancamento nao foi reutilizado automaticamente.
A consolidacao do status do lancamento a partir dos lotes permanece
responsabilidade da aplicacao.

====================================================================
7. MATRIZ DE CONSTRAINTS
====================================================================

Tabela entrada_produto_lote:

pk_entrada_produto_lote
- PK identity.

fk_entrada_lote_item
- FK para entrada_produto_item;
- ON DELETE RESTRICT.

uq_entrada_lote_correlation_id
- correlation_id globalmente unico.

ck_entrada_lote_numero_nao_vazio
- bloqueia lote vazio apos trim.

ck_entrada_lote_datas
- data_vencimento >= data_fabricacao.

ck_entrada_lote_peso_total
- peso_liquido_total_kg >= 0.

ck_entrada_lote_status
- restringe aos oito status oficiais.

ck_entrada_lote_documento_conjunto
- documento, exercicio e item SAP sao todos NULL ou todos validos.

ck_entrada_lote_confirmado_sap_documento
- CONFIRMADO_SAP exige documento, exercicio, item e confirmado_sap_em.

ck_entrada_lote_erro_sap
- ERRO_SAP exige erro_sanitizado.

ck_entrada_lote_quantidade_retorno
- quantidade_retorno_sap NULL ou >= 0.

ck_entrada_lote_criado_por
ck_entrada_lote_alterado_por
- atores nao vazios.

ck_entrada_lote_enviado_em
- ENVIANDO_SAP/CONFIRMADO_SAP exige enviado_sap_em.

ck_entrada_lote_confirmado_em
- estados operacionais posteriores ao inicial exigem confirmado_em.

ck_entrada_lote_payload_sem_credencial
- bloqueia chaves JSON sensiveis conhecidas:
  Authorization, password, senha, token, connection string e client secret.

Tabela entrada_produto_pesagem:

fk_entrada_pesagem_lote
- FK nullable para entrada_produto_lote;
- ON DELETE RESTRICT.

ck_entrada_pesagem_lote_snapshot_conjunto
- legado: todos os campos de lote NULL;
- novo fluxo: FK e os tres snapshots preenchidos.

Regras adicionais por trigger:
- snapshot deve corresponder ao lote referenciado;
- lote e pesagem devem pertencer ao mesmo item;
- vinculo e snapshots tornam-se imutaveis;
- item/lote/datas do lote tornam-se imutaveis apos primeira pesagem ativa;
- peso nao pode mudar apos ENVIANDO_SAP ou CONFIRMADO_SAP;
- CONFIRMADO_SAP nao pode voltar para reenvio.

====================================================================
8. UNICIDADE E NORMALIZACAO
====================================================================

Agrupamento ativo unico:

codigo_entrada_produto_item
+ upper(trim(numero_lote))
+ data_fabricacao
+ data_vencimento

Filtro:
status_lote <> CANCELADO

Consequencias:
- bloqueia dois agrupamentos ativos identicos no mesmo item;
- considera diferencas apenas de caixa e espacos externos como o mesmo lote;
- permite o mesmo numero de lote em itens ou materiais diferentes;
- permite recriacao depois de CANCELADO, preservando o registro cancelado.

Documento SAP confirmado:
documento_material_sap + exercicio_documento_material_sap possui
unicidade parcial em CONFIRMADO_SAP.

documento_material_item permanece obrigatorio quando o documento estiver
preenchido, mas nao participa da unicidade. Assim, o mesmo documento e
exercicio nao podem ser associados a dois lotes, mesmo com itens SAP
diferentes.

====================================================================
9. ESTRATEGIA DE PESO CONSOLIDADO
====================================================================

Decisao:
peso_liquido_total_kg e uma projecao persistida, mantida transacionalmente
por trigger.

Fonte de verdade:
entrada_produto_pesagem.

Calculo:
soma de peso_liquido_kg somente quando:
- situacao_entrada_produto_pesagem = true;
- status_pesagem = VALIDA;
- codigo_entrada_produto_lote corresponde ao lote.

Justificativa:
- a tela precisa listar varios lotes com peso e status;
- o campo evita agregacoes repetidas em grids e filas de envio;
- a trigger recalcula a partir das pesagens, evitando incremento manual;
- update direto do peso total e bloqueado;
- nenhuma pesagem historica e alterada.

====================================================================
10. ESTRATEGIA DE IMUTABILIDADE
====================================================================

Trigger do lote, executada em BEFORE INSERT OR UPDATE:
- no INSERT, peso_liquido_total_kg deve ser obrigatoriamente zero;
- peso positivo ou negativo informado manualmente no INSERT e bloqueado;
- correlation_id e campos de criacao sempre imutaveis;
- depois da primeira pesagem ativa:
  - codigo_entrada_produto_item imutavel;
  - numero_lote imutavel;
  - data_fabricacao imutavel;
  - data_vencimento imutavel;
- peso total alterado somente pelo mecanismo interno de consolidacao;
- update direto do peso pela aplicacao e bloqueado;
- toda atualizacao define NEW.alterado_em = clock_timestamp(), ignorando
  timestamp fornecido pelo cliente;
- lote CONFIRMADO_SAP nao pode ser reaberto ou ter dados SAP substituidos.

Trigger da pesagem:
- valida item, lote e snapshots;
- permite que registro historico nunca vinculado permaneca com lote e snapshots NULL;
- permite a primeira vinculacao de uma pesagem legada, desde que os tres
  snapshots estejam completos e correspondam ao lote;
- depois da primeira vinculacao, o codigo do lote e os tres snapshots tornam-se
  imutaveis;
- a pesagem nao pode voltar ao estado legado;
- lote e snapshots nao podem ser removidos em conjunto;
- o codigo do lote nao pode ser removido isoladamente;
- os snapshots nao podem ser removidos ou alterados isoladamente;
- a pesagem nao pode trocar para outro lote;
- a verificacao de imutabilidade de UPDATE ocorre antes do retorno antecipado
  destinado ao fluxo legado com NEW.codigo_entrada_produto_lote IS NULL;
- bloqueia inclusao, exclusao ou mudanca operacional de peso em lote
  ENVIANDO_SAP ou CONFIRMADO_SAP.

Os campos de status, erro e retorno SAP continuam atualizaveis quando a
transicao for coerente e o lote ainda nao estiver confirmado definitivamente.

====================================================================
11. MATRIZ DE INDICES
====================================================================

Objeto                                      Finalidade
uq_entrada_lote_correlation_id              idempotencia global; criado pela unique
uq_entrada_lote_ativo_item_lote_datas       agrupamento ativo unico normalizado
uq_entrada_lote_documento_confirmado        documento + exercicio SAP unicos
ix_entrada_lote_item                        lotes por item
ix_entrada_lote_status                      fila e historico por status/data
ix_entrada_lote_numero                      diagnostico por Batch normalizado
ix_entrada_lote_pendente_envio              FINALIZADO_LOCAL e ERRO_SAP
ix_entrada_lote_erro_sap                    fila dedicada de erros
ix_entrada_pesagem_lote                     pesagens por lote

Nao foi criado indice separado para correlation_id porque a unique constraint
ja cria o indice necessario.

Nao foi criado indice comum adicional para documento SAP porque o indice
unico parcial atende o fluxo confirmado. Sua chave e exatamente:
- documento_material_sap;
- exercicio_documento_material_sap.
O documento_material_item nao participa do indice unico.

====================================================================
12. MATRIZ DE GRANTS
====================================================================

Origem historica confirmada:

Incremental 022:
- criou entrada_produto_lancamento;
- criou entrada_produto_item;
- criou entrada_produto_pesagem;
- nao concedeu privilegios para fugapet_dev_app.

Incremental 025:
- a criacao das roles;
- os grants gerais;
- os default privileges;
estao somente na Secao B comentada e nao foram executados pelo incremental.

Incremental 039:
- concedeu privilegios somente aos objetos proprios do Controle de
  Apontamentos;
- nao normalizou as tabelas antigas da Entrada.

Conclusao:
a ausencia de grants nas tabelas antigas da Entrada e uma lacuna historica
do modelo de permissoes. Nao representa aplicacao parcial do 043.

Diagnostico READ ONLY oficial do DEV em 2026-07-24:

Banco:
- CONNECT: sim.

Schema desenvolvimento:
- USAGE: sim;
- CREATE: nao.

Role fugapet_dev_app:
- LOGIN: sim;
- SUPERUSER: nao;
- INHERIT: sim;
- memberships diretos ou indiretos: 0;
- default privileges aplicaveis: 0.

Owners das tres tabelas base e das tres sequences base:
- postgres.

ACL explicita anterior:
- NULL nos seis objetos.

Matriz anterior das tabelas base:

Objeto                         SEL INS UPD DEL TRU REF TRG
entrada_produto_lancamento     nao nao nao nao nao nao nao
entrada_produto_item           nao nao nao nao nao nao nao
entrada_produto_pesagem        nao nao nao nao nao nao nao

Sequences identity resolvidas dinamicamente:

entrada_produto_lancamento:
desenvolvimento.entrada_produto_lancamento_codigo_entrada_produto_lancament_seq

entrada_produto_item:
desenvolvimento.entrada_produto_item_codigo_entrada_produto_item_seq

entrada_produto_pesagem:
desenvolvimento.entrada_produto_pesagem_codigo_entrada_produto_pesagem_seq

Matriz anterior das sequences base:

Objeto                         USAGE SELECT UPDATE
sequence lancamento            nao   nao    nao
sequence item                  nao   nao    nao
sequence pesagem               nao   nao    nao

Matriz posterior obrigatoria das tabelas:

Objeto                         SEL INS UPD DEL TRU REF TRG
entrada_produto_lancamento     sim sim sim nao nao nao nao
entrada_produto_item           sim sim sim nao nao nao nao
entrada_produto_pesagem        sim sim sim nao nao nao nao
entrada_produto_lote           sim sim sim nao nao nao nao

Matriz posterior obrigatoria das sequences:

Objeto                         USAGE SELECT UPDATE
sequence lancamento            sim   sim    nao
sequence item                  sim   sim    nao
sequence pesagem               sim   sim    nao
sequence lote                  sim   sim    nao

A sequence de lote tambem e resolvida dinamicamente por
pg_get_serial_sequence. Nenhum nome historico de sequence e presumido.

ALTER, DROP, propriedade de objetos, DELETE, TRUNCATE, REFERENCES e TRIGGER
nao sao concedidos a fugapet_dev_app.

PUBLIC nao deve receber privilegios nas quatro tabelas ou nas quatro
sequences. fugapet_dev_app nao pode ser owner desses objetos.

Compatibilidade com EntradaProdutoRepositorio:
- INSERT em entrada_produto_lancamento;
- INSERT em entrada_produto_item;
- INSERT em entrada_produto_pesagem;
- UPDATE em entrada_produto_item;
- UPDATE em entrada_produto_lancamento;
- SELECT nas tabelas da Entrada.

Por isso, grants somente em pesagem seriam insuficientes. Nenhuma alteracao
no codigo C# faz parte deste pacote.

====================================================================
13. PREFLIGHT
====================================================================

O PREFLIGHT:
- usa BEGIN + SET TRANSACTION READ ONLY + ROLLBACK;
- nao executa GRANT, REVOKE, DDL ou DML persistente;
- valida banco, schema, PostgreSQL, role, CONNECT e USAGE;
- bloqueia role inexistente ou superusuaria;
- valida as tres tabelas atuais da Entrada;
- resolve dinamicamente as tres sequences identity;
- imprime as matrizes:
  GRANTS_LANCAMENTO;
  GRANTS_ITEM;
  GRANTS_PESAGEM;
  GRANTS_SEQUENCE_LANCAMENTO;
  GRANTS_SEQUENCE_ITEM;
  GRANTS_SEQUENCE_PESAGEM;
- aceita ausencia total ou parcial de SELECT, INSERT, UPDATE, USAGE e SELECT
  da matriz minima anterior;
- registra essa condicao como:
  GRANTS_BASE_A_NORMALIZAR_PELO_043;
- imprime:
  GRANTS_SERAO_NORMALIZADOS_PELA_PROPOSTA=SIM;
- bloqueia DELETE, TRUNCATE, REFERENCES ou TRIGGER nas tabelas base;
- bloqueia UPDATE nas sequences base;
- verifica homonimos e aplicacao parcial;
- verifica definicoes reais por pg_get_constraintdef, pg_get_indexdef,
  pg_get_triggerdef e pg_get_functiondef;
- classifica em uma unica linha:
  CLASSIFICACAO_OFICIAL=PACOTE_NAO_APLICADO;
  CLASSIFICACAO_OFICIAL=PACOTE_COMPLETAMENTE_APLICADO;
  CLASSIFICACAO_OFICIAL=PACOTE_PARCIAL_INCOMPATIVEL.

A ausencia dos grants minimos nao impede PACOTE_NAO_APLICADO. Ela e uma
condicao a ser normalizada transacionalmente pela PROPOSTA.

====================================================================
14. PROPOSTA
====================================================================

A PROPOSTA:
- usa ON_ERROR_STOP;
- usa BEGIN/COMMIT;
- define lock_timeout e statement_timeout;
- exige pacote ainda nao aplicado;
- nao exige que os grants minimos ja existam;
- cria entrada_produto_lote;
- adiciona FK e snapshots nullable na pesagem;
- usa constraints NOT VALID + VALIDATE nas alteracoes historicas;
- cria indices, funcoes e triggers;
- concede SELECT, INSERT e UPDATE nas quatro tabelas;
- revoga DELETE, TRUNCATE, REFERENCES e TRIGGER nas quatro tabelas;
- resolve as quatro sequences por pg_get_serial_sequence;
- concede USAGE e SELECT nas quatro sequences;
- revoga UPDATE nas quatro sequences;
- nao concede ownership, ALTER ou DROP;
- confirma ausencia de privilegios para PUBLIC;
- confirma que fugapet_dev_app nao e owner;
- compara hashes e quantidades das tres tabelas historicas antes/depois;
- exige entrada_produto_lote vazia;
- nao executa UPDATE massivo;
- nao insere lote;
- nao altera status ou dados historicos;
- termina com classificacao inequivoca de sucesso.

A concessao e a revogacao ocorrem na mesma transacao do incremental. Nenhum
grant manual deve ser aplicado antes ou depois do pacote.

====================================================================
15. VALIDACAO
====================================================================

A VALIDACAO preserva todos os testes funcionais anteriores e acrescenta:

- matriz exata das quatro tabelas;
- matriz exata das quatro sequences;
- role existente e nao-superusuaria;
- CONNECT no banco;
- USAGE no schema;
- SELECT, INSERT e UPDATE presentes nas quatro tabelas;
- DELETE, TRUNCATE, REFERENCES e TRIGGER ausentes;
- USAGE e SELECT presentes nas quatro sequences;
- UPDATE ausente nas quatro sequences;
- fugapet_dev_app nao e owner;
- PUBLIC sem privilegios;
- estado last_value/is_called das quatro sequences do 043 antes e depois;
- estado last_value/is_called da sequence de log_alteracao_cadastral;
- nenhuma chamada a nextval;
- desabilitacao transacional exclusiva do trigger generico de auditoria da
  pesagem, mantendo ativos os triggers funcionais do 043;
- restauracao automatica desse trigger pelo rollback interno;
- nenhum avanco das quatro sequences do 043 nem da sequence de auditoria;
- nenhum residuo depois do rollback interno.

Testes funcionais preservados:
- lote valido;
- lote vazio bloqueado;
- vencimento anterior a fabricacao bloqueado;
- correlation_id duplicado bloqueado;
- mesmo lote/datas no mesmo item bloqueado;
- mesmo lote/datas em item diferente permitido;
- INSERT sem peso aceito e persistido com zero;
- peso positivo ou negativo manual no INSERT bloqueado;
- update direto do peso bloqueado;
- CONFIRMADO_SAP sem documento bloqueado;
- payload com credencial bloqueado;
- pesagem legada vinculada ao lote uma unica vez;
- snapshot correspondente e preservado;
- consolidacao de peso;
- desvinculacao integral com lote e snapshots para NULL bloqueada;
- peso consolidado preservado depois da tentativa de desvinculacao;
- troca para outro lote valido do mesmo item bloqueada;
- remocao isolada do codigo do lote bloqueada;
- remocao isolada dos snapshots bloqueada;
- alteracao do numero do lote no snapshot bloqueada;
- alteracao isolada de cada data do snapshot bloqueada;
- alteracao do lote apos pesagem bloqueada;
- atualizacao coerente de status SAP permitida;
- reenvio de CONFIRMADO_SAP bloqueado;
- mesmo documento/ano com item SAP diferente bloqueado;
- alterado_em renovado;
- definicoes reais de indices, constraints, triggers e funcoes;
- FKs ON DELETE RESTRICT;
- ausencia de alteracao historica.

A validacao usa IDs negativos explicitos para lotes de teste e nao consome a
sequence identity. Todos os testes de dados ficam em transacao e terminam em
ROLLBACK.

====================================================================
16. ROLLBACK OFICIAL
====================================================================

O rollback:
- e separado;
- nunca e automatico;
- exige:
  CONFIRMAR_ROLLBACK_043=EU_CONFIRMO_ROLLBACK_043_DEV;
- bloqueia se houver qualquer lote;
- bloqueia se houver pesagem vinculada ou snapshot preenchido;
- remove somente os objetos estruturais do 043;
- remove entrada_produto_lote sem CASCADE;
- nao apaga lancamentos, itens ou pesagens;
- nao altera CONNECT ou USAGE;
- restaura a matriz anterior oficial do DEV sem adivinhacao.

Matriz restaurada nas tres tabelas base:
- SELECT: nao;
- INSERT: nao;
- UPDATE: nao;
- DELETE: nao;
- TRUNCATE: nao;
- REFERENCES: nao;
- TRIGGER: nao.

Matriz restaurada nas tres sequences base:
- USAGE: nao;
- SELECT: nao;
- UPDATE: nao.

O rollback resolve as sequences base dinamicamente, revoga todos os
privilegios que o 043 adicionou e confirma que os seis owners continuam sendo
postgres. Tambem confirma a matriz anterior de banco/schema:
- CONNECT: sim;
- USAGE: sim;
- CREATE: nao.

O criterio oficial de restauracao e a matriz efetiva. Depois de um ciclo
GRANT/REVOKE, o PostgreSQL pode manter ACL explicita apenas do owner em vez de
voltar a representar a mesma semantica como ACL NULL. Isso nao concede acesso
adicional: PUBLIC permanece sem privilegios, o owner permanece postgres e
fugapet_dev_app volta a nao possuir privilegios nos seis objetos base.

Depois que o fluxo C# criar o primeiro lote, o rollback fica
intencionalmente bloqueado.

====================================================================
17. RISCOS E PENDENCIAS
====================================================================

1. Regras de obrigatoriedade SAP
A estrutura suporta Batch, ManufactureDate e ShelfLifeExpirationDate, mas
a fonte SAP que informa se cada material exige lote/validade continua sendo
contrato funcional da integracao e nao foi inventada no banco.

2. Aplicacao C#
O pacote de banco deve ser acompanhado pela alteracao controlada da tela,
servico, repositorio, payload SAP 101, etiqueta e reimpressao. O banco nao
ativa sozinho o novo fluxo.

3. Um documento por lote
O C# deve consolidar e enviar cada lote separadamente, com correlation_id
proprio. O status do lancamento passa a ser uma consolidacao dos lotes.

4. Concorrencia
A unique ativa e o correlation_id protegem a idempotencia no banco.
O C# ainda deve usar transacao para criar lote, vincular pesagens e mudar
status.

5. Dados SAP sensiveis
O check de JSON bloqueia chaves sensiveis conhecidas. A aplicacao tambem
deve sanitizar valores e logs; nao deve depender apenas da constraint.

6. Tamanho Batch
Foi adotado limite de 10 caracteres. Mudanca futura no contrato SAP exige
novo incremental, nunca alteracao manual deste pacote.

7. Auditoria generica e role de aplicacao
O diagnostico autorizado comprovou a matriz apenas das tabelas e sequences da
Entrada. A funcao historica fn_registrar_log_alteracao_cadastral e executada
como SECURITY INVOKER no baseline revisado e escreve em
log_alteracao_cadastral. O pacote 043 nao concede privilegios nessa tabela,
porque isso alteraria objeto fora da matriz expressamente autorizada.
Antes de trocar o runtime para fugapet_dev_app, deve existir validacao separada
do direito de INSERT na auditoria ou endurecimento proprio da funcao, em
incremental independente. Essa pendencia nao autoriza grant manual neste 043.

====================================================================
18. ORDEM CONTROLADA
====================================================================

1. Revisar o pacote com Michael Richard e Dedalo.
2. Autorizar e executar somente PREFLIGHT.
3. Revisar a evidencia.
4. Autorizar e executar PROPOSTA.
5. Revisar a evidencia.
6. Autorizar e executar VALIDACAO.
7. Somente depois desenvolver/validar o fluxo funcional.
8. Nao promover automaticamente para HML ou PRD.

====================================================================
19. CONTROLE FINAL DA PREPARACAO
====================================================================

Diagnostico READ ONLY executado por Michael Richard: sim.
Codigo de saida do diagnostico: 0.
Classificacao: DIAGNOSTICO_READ_ONLY_CONCLUIDO.

Grants concedidos manualmente: nao.
SQL de alteracao executado durante esta correcao: nao.
Novo PREFLIGHT executado: nao.
PROPOSTA executada durante esta correcao local: nao.
VALIDACAO executada: nao.
ROLLBACK oficial executado: nao.
DEV alterado por esta correcao local: nao.
HML acessado/alterado: nao.
PRD acessado/alterado: nao.
Codigo C# alterado: nao.
Commit/push: nao realizado.
Dados produtivos inseridos: nao.
Registros historicos modificados: nao.

====================================================================
20. CORRECOES CONTROLADAS DA REVISAO
====================================================================

1. Unicidade do documento SAP
A chave unica parcial de CONFIRMADO_SAP usa somente documento e exercicio.

2. Peso total no INSERT e UPDATE
Peso inicia em zero; alteracao direta permanece bloqueada; consolidacao
interna por trigger permanece permitida.

3. alterado_em
Toda atualizacao usa clock_timestamp().

4. Grants historicos
A exigencia incorreta de grants previamente existentes foi removida.
A ausencia passa a ser aceita e registrada para normalizacao pelo 043.

5. Matriz completa do repository
Lancamento, item e pesagem passam a receber SELECT, INSERT e UPDATE.
O pacote deixa de tratar somente pesagem como suficiente.

6. Sequences dinamicas
As quatro sequences sao resolvidas com pg_get_serial_sequence.
UPDATE e explicitamente revogado.

7. Postcheck e validacao
As quatro tabelas e as quatro sequences possuem matriz exata, owners e PUBLIC
verificados. A validacao monitora tambem a sequence da auditoria, desabilita
transacionalmente apenas o trigger generico de log da pesagem e confirma que
nenhuma das cinco sequences monitoradas avanca.

8. Rollback
A matriz anterior do DEV e restaurada exatamente: nenhum privilegio para a
role nas tres tabelas e nas tres sequences base.

9. Classificacao automatica
As classificacoes oficiais foram padronizadas em linhas unicas iniciadas por
CLASSIFICACAO_OFICIAL=.

10. Imutabilidade da vinculacao da pesagem
A protecao de UPDATE da funcao de validacao da pesagem foi movida para antes do
retorno do fluxo legado. Depois da primeira vinculacao, a pesagem nao pode ser
desvinculada, trocar de lote nem remover/alterar o numero e as datas dos
snapshots. A VALIDACAO cobre desvinculacao integral, troca de lote, remocao
isolada do codigo, remocao dos snapshots e alteracao de cada data.

11. Hash do catalogo fora do escopo
A tentativa controlada da PROPOSTA em 2026-07-24 foi abortada antes do COMMIT
por falso positivo no hash do catalogo fora do escopo. O hash anterior era
calculado com search_path "$user", public, enquanto o posterior era calculado
com desenvolvimento, public. Expressoes de decompilacao como column_default,
pg_get_constraintdef, pg_indexes.indexdef e pg_get_triggerdef podem qualificar
nomes de forma diferente conforme a visibilidade, mesmo sem mudanca estrutural.

A correcao move SET search_path TO desenvolvimento, public para antes de todos
os snapshots, registra o valor canonico e confirma no postcheck que ele nao foi
alterado. A verificacao integral de tabelas, colunas, constraints, indices e
triggers fora do escopo foi preservada. Em caso de divergencia real, a excecao
agora informa os hashes anterior e posterior com a classificacao:
CLASSIFICACAO_OFICIAL=PROPOSTA_POSTCHECK_REPROVADO_CATALOGO_FORA_ESCOPO_DIVERGENTE.

====================================================================
21. INTEGRIDADE CRIPTOGRAFICA DA ENTREGA
====================================================================

Todos os SQL possuem:
- primeira linha: \set ON_ERROR_STOP on;
- codificacao: UTF-8 sem BOM;
- terminacao de linha: LF.

Os hashes reais dos cinco arquivos e do ZIP sao entregues em manifesto
externo. O README interno registra os hashes dos quatro SQL depois da
finalizacao, sem tentar embutir o hash autorreferente do proprio README ou do
ZIP.

043_entrada_produto_lote_DEV_PREFLIGHT_GAIA.sql
SHA256=4C786BFA7F565EEF64347EC13840F7985E0C8CC0A6A1729EEB2F6F826D7AA8E0

043_entrada_produto_lote_DEV_PROPOSTA_GAIA.sql
SHA256=026F490F0A306F1D054A2DFE8077B01521F62E6B200D08925B18928013D81EF2

043_entrada_produto_lote_DEV_VALIDACAO_GAIA.sql
SHA256=016496C390975C891423DD94707A02DF67E9DCD1EEA070AE2821DCD0C3AC32B7

043_entrada_produto_lote_DEV_ROLLBACK_GAIA.sql
SHA256=1490C0C45EE976C0EE66461071588D1D2DDC376CD3AB3FDE906EF735C32B8613

====================================================================
22. ESCOPO POR AMBIENTE
====================================================================

Este pacote e exclusivo para DEV e restaura a matriz anterior encontrada no
DEV em 2026-07-24.

HML exige:
- diagnostico READ ONLY proprio;
- matriz anterior propria;
- pacote proprio;
- aprovacao separada.

Nenhum arquivo deste pacote deve ser executado diretamente em HML ou PRD.
