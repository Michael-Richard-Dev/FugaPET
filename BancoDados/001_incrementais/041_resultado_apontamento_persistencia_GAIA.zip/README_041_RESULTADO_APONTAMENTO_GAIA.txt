FUGAPET - INCREMENTAL 041 DEV
PERSISTENCIA DO RESULTADO DO APONTAMENTO
Responsavel: Michael Richard
Pacote: 041_resultado_apontamento_persistencia_GAIA
Data de preparacao: 2026-07-23

====================================================================
1. ESCOPO
====================================================================

Este pacote foi preparado exclusivamente para o banco DEV:

Banco esperado: fuga_jales_local_desenvolvimento
Schema: desenvolvimento
Papel da aplicacao: fugapet_dev_app

Objetivos:

1. ampliar a constraint ck_operacao_config_tipo_processo para aceitar:
   - CONSUMO_MATERIA_PRIMA
   - CONSUMO_QUIMICOS
   - CONSUMO_SEMI_ACABADO
   - RESULTADO_APONTAMENTO
   - SEMI_ACABADO
   - PRODUTO_ACABADO
   - SEM_DESTINO_CONFIGURADO
2. criar operacao_resultado_definicao;
3. criar operacao_resultado_registro;
4. criar operacao_resultado_registro_item;
5. manter vinculo integral com operacao_producao_apontamento do incremental 039;
6. aplicar grants minimos para fugapet_dev_app.

O pacote NAO cria rotas, NAO insere definicoes, NAO insere resultados e NAO
executa qualquer promocao para HML ou PRD.

====================================================================
2. DEPENDENCIAS
====================================================================

- Incremental 039 DEV concluido e integro.
- Incremental 040 DEV concluido e integro.
- Tabelas 039:
  - desenvolvimento.operacao_producao_configuracao
  - desenvolvimento.operacao_producao_apontamento
  - desenvolvimento.operacao_producao_evento
- Rotas 040:
  - 0050 / CONSUMO_MATERIA_PRIMA
  - 0060 / CONSUMO_QUIMICOS
- Papel fugapet_dev_app existente, nao-superusuario, com CONNECT e USAGE.
- PostgreSQL compativel com identity (versao 10 ou superior).

====================================================================
3. ARQUIVOS E ORDEM CONTROLADA
====================================================================

1. 041_resultado_apontamento_DEV_PREFLIGHT_GAIA.sql
2. 041_resultado_apontamento_DEV_PROPOSTA_GAIA.sql
3. 041_resultado_apontamento_DEV_VALIDACAO_GAIA.sql
4. 041_resultado_apontamento_DEV_ROLLBACK_GAIA.sql

Ordem normal autorizavel:

PREFLIGHT -> revisao -> PROPOSTA -> revisao -> VALIDACAO

O ROLLBACK nao faz parte do fluxo normal. Ele e separado, bloqueia dados reais e
exige confirmacao explicita. Nenhum arquivo deve ser executado automaticamente.

Confirmacao exigida pelo rollback:

CONFIRMAR_ROLLBACK_041=EU_CONFIRMO_ROLLBACK_041_DEV

====================================================================
4. PAPEL DOS IDENTIFICADORES
====================================================================

codigo_apontamento:

- chave estrangeira para operacao_producao_apontamento;
- garante que o resultado pertence ao apontamento 039 correto;
- possui unicidade no cabecalho: um resultado por apontamento.

codigo_resultado:

- chave primaria do cabecalho operacao_resultado_registro;
- vincula todos os itens registrados;
- deve ser devolvido ao Controle de Apontamentos no campo
  codigo_registro_processo.

====================================================================
5. SNAPSHOT DOS ITENS
====================================================================

operacao_resultado_registro_item preserva no historico:

- codigo_item;
- tipo;
- medida;
- referencia;
- ordem_exibicao;
- obrigatorio.

Uma alteracao futura em operacao_resultado_definicao nao modifica o resultado
historico ja registrado.

A gravacao futura pelo codigo C# deve inserir o cabecalho e todos os itens na
mesma transacao.

====================================================================
6. TABELAS E PRINCIPAIS REGRAS
====================================================================

operacao_resultado_definicao

- PK identity bigint: codigo_definicao;
- FK codigo_configuracao -> operacao_producao_configuracao, RESTRICT;
- checks de campos nao vazios, referencia >= 0 e ordem_exibicao > 0;
- unica definicao ativa por configuracao + codigo_item;
- unica ordem ativa por configuracao;
- nenhuma definicao inserida pelo 041.

operacao_resultado_registro

- PK identity bigint: codigo_resultado;
- FK codigo_apontamento -> operacao_producao_apontamento, RESTRICT;
- UNIQUE codigo_apontamento;
- horario gerado pelo banco;
- append-only para o papel da aplicacao nesta etapa.

operacao_resultado_registro_item

- PK identity bigint: codigo_resultado_item;
- FKs para resultado e definicao, ambas RESTRICT;
- UNIQUE codigo_resultado + codigo_item;
- referencia e resultado nao negativos;
- item obrigatorio exige resultado;
- item opcional aceita resultado NULL.

====================================================================
7. INDICES
====================================================================

- uq_resultado_definicao_ativa_item
- uq_resultado_definicao_ativa_ordem
- ix_resultado_definicao_config_ativo
- ix_resultado_definicao_tipo_medida
- ix_resultado_registro_item_resultado

As UNIQUE constraints do cabecalho e do item tambem geram indices internos do
PostgreSQL.

====================================================================
8. MATRIZ DE GRANTS
====================================================================

Objeto                                      SELECT  INSERT  UPDATE  DELETE
operacao_resultado_definicao                SIM     NAO     NAO     NAO
operacao_resultado_registro                 SIM     SIM     NAO     NAO
operacao_resultado_registro_item            SIM     SIM     NAO     NAO

Sequences identity:

- USAGE: SIM
- SELECT: SIM
- UPDATE: NAO

Nao sao concedidos DELETE, TRUNCATE, ALTER ou DROP.

====================================================================
9. VALIDACAO
====================================================================

A validacao oficial verifica:

- novos tipos aceitos e tipo invalido bloqueado;
- tres tabelas, identities, PKs, FKs RESTRICT, uniques e indices;
- duplicidade ativa de definicao e ordem bloqueada;
- um cabecalho por apontamento;
- item duplicado bloqueado;
- obrigatorio NULL bloqueado;
- opcional NULL aceito;
- valores negativos bloqueados;
- registros orfaos bloqueados;
- grants minimos e ausencia de DELETE/UPDATE historico;
- rollback interno dos testes;
- zero residuos e preservacao dos incrementais 039/040.

Os testes usam IDs negativos explicitos para nao avancar as sequences identity.

====================================================================
10. ROLLBACK
====================================================================

O rollback:

- nunca e automatico;
- exige confirmacao explicita;
- bloqueia se houver qualquer definicao, resultado ou item;
- bloqueia se configuracoes usarem CONSUMO_SEMI_ACABADO ou RESULTADO_APONTAMENTO;
- remove somente as tres tabelas 041, sem CASCADE;
- restaura a constraint anterior de tipos;
- preserva apontamentos, eventos, rotas 039/040 e seus dados.

====================================================================
11. PACOTE 042 FUTURO
====================================================================

Rotas 0070/0090/0100/0105/0140 e seeds de definicoes serao tratados em pacote
042 futuro, apos definicao funcional aprovada. O 041 nao cria TEMPO/MINUTO/5 e
nao inventa definicoes por operacao.

====================================================================
12. HASHES DOS ARQUIVOS SQL
====================================================================

041_resultado_apontamento_DEV_PREFLIGHT_GAIA.sql
451E5D395EA5813FC467D2F1DD0C959055836817330A04F117F1D31E4F4223B4

041_resultado_apontamento_DEV_PROPOSTA_GAIA.sql
2CC84546DF0834AEA4749FC9F5FD65449CE992BE9E8FF2F8EB3A18D76F5B77D9

041_resultado_apontamento_DEV_VALIDACAO_GAIA.sql
8E30B7CDA65717D13B9CD50122370976E7E3E4728D3CF59FD3E008B06063BDCF

041_resultado_apontamento_DEV_ROLLBACK_GAIA.sql
506FC6481E107418307321F96DB638D9EE191E8463378E63C89B0F20CEAD9EE0

O hash deste README e o hash do ZIP constam no manifesto de entrega externo,
pois inserir o proprio hash no arquivo alteraria o seu conteudo.

====================================================================
13. CONTROLE DE EXECUCAO
====================================================================

- Nenhum SQL foi executado durante a preparacao deste pacote.
- Nenhum banco DEV, HML ou PRD foi alterado.
- Nenhum acesso a HML ou PRD foi realizado.
- Nenhum codigo C# foi alterado.
- Nenhum commit ou push foi realizado.
- Nao ha senha ou connection string sensivel neste pacote.
- Nao existe promocao automatica para HML ou PRD.
