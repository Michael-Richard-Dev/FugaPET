FUGAPET - INCREMENTAL 043 DEV
PERSISTENCIA POR LOTE DA ENTRADA DE MATERIA-PRIMA E PRODUTOS QUIMICOS
Responsavel: Michael Richard
Pacote: 043_entrada_produto_lote_persistencia_GAIA
Ambiente exclusivo: DEV
Banco esperado: fuga_jales_local_desenvolvimento
Schema: desenvolvimento
Papel da aplicacao: fugapet_dev_app

====================================================================
1. NUMERACAO
====================================================================

Foi utilizado o incremental 043.

Motivo:
- 041 esta reservado para persistencia do Resultado do Apontamento;
- 042 esta reservado para as futuras rotas e seeds vinculados ao 041;
- 043 e a proxima numeracao disponivel dentro do contexto aprovado.

Nenhum incremental anterior foi alterado ou reutilizado.

====================================================================
2. ESCOPO
====================================================================

O pacote cria a camada de persistencia por lote para a mesma
ProcessoEntradaProdutoForm utilizada em:

- Entrada de Materia-Prima;
- Entrada de Produtos Quimicos.

Campos funcionais destinados ao SAP:

- Batch;
- ManufactureDate;
- ShelfLifeExpirationDate.

O pacote NAO:
- altera codigo C#;
- insere lotes;
- cria lotes ficticios para historico;
- altera lancamentos, itens ou pesagens existentes;
- cria rotas;
- cria permissoes de tela;
- acessa ou promove HML/PRD.

====================================================================
3. DIAGRAMA DAS RELACOES
====================================================================

desenvolvimento.entrada_produto_lancamento
    1
    |
    +---- N desenvolvimento.entrada_produto_item
                 1
                 |
                 +---- N desenvolvimento.entrada_produto_lote
                              1
                              |
                              +---- N desenvolvimento.entrada_produto_pesagem

FKs novas:

entrada_produto_lote.codigo_entrada_produto_item
    -> entrada_produto_item.codigo_entrada_produto_item
    ON DELETE RESTRICT

entrada_produto_pesagem.codigo_entrada_produto_lote
    -> entrada_produto_lote.codigo_entrada_produto_lote
    ON DELETE RESTRICT

O lancamento continua representando a entrada/pedido.
O item continua representando o item do pedido.
Um item pode possuir varios lotes.
Cada lote e unidade independente de pesagem, envio SAP, idempotencia,
erro, reprocessamento, documento e impressao.

====================================================================
4. MATRIZ DE COLUNAS - ENTRADA_PRODUTO_LOTE
====================================================================

Coluna                                  Tipo              Nulo  Regra
codigo_entrada_produto_lote             bigint identity   nao   PK
codigo_entrada_produto_item             bigint            nao   FK RESTRICT
numero_lote                             varchar(10)       nao   Batch SAP
data_fabricacao                         date               nao   ManufactureDate
data_vencimento                         date               nao   ShelfLifeExpirationDate
peso_liquido_total_kg                   numeric(14,3)      nao   default 0
status_lote                             varchar(30)       nao   status controlado
correlation_id                          uuid               nao   unique global
documento_material_sap                  varchar(20)       sim
exercicio_documento_material_sap        varchar(4)        sim
documento_material_item                 varchar(10)       sim
batch_retornado_sap                     varchar(10)       sim
quantidade_retorno_sap                  numeric(14,3)      sim
payload_enviado_json                    jsonb              sim
resposta_sap_json                       jsonb              sim
erro_sanitizado                         text               sim
criado_em                               timestamptz        nao   clock_timestamp()
criado_por                              varchar(80)       nao
confirmado_em                           timestamptz        sim
enviado_sap_em                          timestamptz        sim
confirmado_sap_em                       timestamptz        sim
alterado_em                             timestamptz        sim
alterado_por                            varchar(80)       sim

Tamanho do lote:
numero_lote e batch_retornado_sap usam varchar(10) como decisao tecnica desta
versao.

O documento de API fornecido confirma a existencia dos campos Batch,
ManufactureDate e ShelfLifeExpirationDate, mas nao informa o facet/tamanho do
Batch. A confirmacao contratual do limite permanece pendente com Ares/SAP.
Qualquer mudanca futura de tamanho exige novo incremental; este pacote nao deve
ser alterado manualmente.

====================================================================
5. MATRIZ DE COLUNAS NOVAS - ENTRADA_PRODUTO_PESAGEM
====================================================================

Coluna                         Tipo          Nulo
codigo_entrada_produto_lote    bigint        sim
numero_lote_snapshot           varchar(10)  sim
data_fabricacao_snapshot       date          sim
data_vencimento_snapshot       date          sim

Compatibilidade historica:
- as quatro colunas sao adicionadas como nullable;
- registros antigos permanecem com as quatro colunas NULL;
- nao existe backfill;
- nao sao criados lotes ficticios;
- o fluxo novo deve informar as quatro colunas em conjunto;
- a constraint condicionada aceita somente:
  a) todas NULL, para legado;
  b) todas preenchidas, para o fluxo versionado por lote.

====================================================================
6. STATUS DO LOTE
====================================================================

Valores permitidos:

AGUARDANDO_DADOS
LOTE_CONFIRMADO
PESANDO
FINALIZADO_LOCAL
ENVIANDO_SAP
CONFIRMADO_SAP
ERRO_SAP
CANCELADO

O status do lancamento nao foi reutilizado automaticamente.
A consolidacao do status do lancamento a partir dos lotes permanece
responsabilidade da aplicacao.

====================================================================
7. MATRIZ DE CONSTRAINTS
====================================================================

Tabela entrada_produto_lote:

pk_entrada_produto_lote
- PK identity.

fk_entrada_lote_item
- FK para entrada_produto_item;
- ON DELETE RESTRICT.

uq_entrada_lote_correlation_id
- correlation_id globalmente unico.

ck_entrada_lote_numero_nao_vazio
- bloqueia lote vazio apos trim.

ck_entrada_lote_datas
- data_vencimento >= data_fabricacao.

ck_entrada_lote_peso_total
- peso_liquido_total_kg >= 0.

ck_entrada_lote_status
- restringe aos oito status oficiais.

ck_entrada_lote_documento_conjunto
- documento, exercicio e item SAP sao todos NULL ou todos validos.

ck_entrada_lote_confirmado_sap_documento
- CONFIRMADO_SAP exige documento, exercicio, item e confirmado_sap_em.

ck_entrada_lote_erro_sap
- ERRO_SAP exige erro_sanitizado.

ck_entrada_lote_quantidade_retorno
- quantidade_retorno_sap NULL ou >= 0.

ck_entrada_lote_criado_por
ck_entrada_lote_alterado_por
- atores nao vazios.

ck_entrada_lote_enviado_em
- ENVIANDO_SAP/CONFIRMADO_SAP exige enviado_sap_em.

ck_entrada_lote_confirmado_em
- estados operacionais posteriores ao inicial exigem confirmado_em.

ck_entrada_lote_payload_sem_credencial
- bloqueia chaves JSON sensiveis conhecidas:
  Authorization, password, senha, token, connection string e client secret.

Tabela entrada_produto_pesagem:

fk_entrada_pesagem_lote
- FK nullable para entrada_produto_lote;
- ON DELETE RESTRICT.

ck_entrada_pesagem_lote_snapshot_conjunto
- legado: todos os campos de lote NULL;
- novo fluxo: FK e os tres snapshots preenchidos.

Regras adicionais por trigger:
- snapshot deve corresponder ao lote referenciado;
- lote e pesagem devem pertencer ao mesmo item;
- vinculo e snapshots tornam-se imutaveis;
- item/lote/datas do lote tornam-se imutaveis apos primeira pesagem ativa;
- peso nao pode mudar apos ENVIANDO_SAP ou CONFIRMADO_SAP;
- CONFIRMADO_SAP nao pode voltar para reenvio.

====================================================================
8. UNICIDADE E NORMALIZACAO
====================================================================

Agrupamento ativo unico:

codigo_entrada_produto_item
+ upper(trim(numero_lote))
+ data_fabricacao
+ data_vencimento

Filtro:
status_lote <> CANCELADO

Consequencias:
- bloqueia dois agrupamentos ativos identicos no mesmo item;
- considera diferencas apenas de caixa e espacos externos como o mesmo lote;
- permite o mesmo numero de lote em itens ou materiais diferentes;
- permite recriacao depois de CANCELADO, preservando o registro cancelado.

Documento SAP confirmado:
documento_material_sap + exercicio_documento_material_sap possui
unicidade parcial em CONFIRMADO_SAP.

documento_material_item permanece obrigatorio quando o documento estiver
preenchido, mas nao participa da unicidade. Assim, o mesmo documento e
exercicio nao podem ser associados a dois lotes, mesmo com itens SAP
diferentes.

====================================================================
9. ESTRATEGIA DE PESO CONSOLIDADO
====================================================================

Decisao:
peso_liquido_total_kg e uma projecao persistida, mantida transacionalmente
por trigger.

Fonte de verdade:
entrada_produto_pesagem.

Calculo:
soma de peso_liquido_kg somente quando:
- situacao_entrada_produto_pesagem = true;
- status_pesagem = VALIDA;
- codigo_entrada_produto_lote corresponde ao lote.

Justificativa:
- a tela precisa listar varios lotes com peso e status;
- o campo evita agregacoes repetidas em grids e filas de envio;
- a trigger recalcula a partir das pesagens, evitando incremento manual;
- update direto do peso total e bloqueado;
- nenhuma pesagem historica e alterada.

====================================================================
10. ESTRATEGIA DE IMUTABILIDADE
====================================================================

Trigger do lote, executada em BEFORE INSERT OR UPDATE:
- no INSERT, peso_liquido_total_kg deve ser obrigatoriamente zero;
- peso positivo ou negativo informado manualmente no INSERT e bloqueado;
- correlation_id e campos de criacao sempre imutaveis;
- depois da primeira pesagem ativa:
  - codigo_entrada_produto_item imutavel;
  - numero_lote imutavel;
  - data_fabricacao imutavel;
  - data_vencimento imutavel;
- peso total alterado somente pelo mecanismo interno de consolidacao;
- update direto do peso pela aplicacao e bloqueado;
- toda atualizacao define NEW.alterado_em = clock_timestamp(), ignorando
  timestamp fornecido pelo cliente;
- lote CONFIRMADO_SAP nao pode ser reaberto ou ter dados SAP substituidos.

Trigger da pesagem:
- valida item, lote e snapshots;
- bloqueia alteracao do vinculo e snapshots;
- bloqueia inclusao, exclusao ou mudanca operacional de peso em lote
  ENVIANDO_SAP ou CONFIRMADO_SAP.

Os campos de status, erro e retorno SAP continuam atualizaveis quando a
transicao for coerente e o lote ainda nao estiver confirmado definitivamente.

====================================================================
11. MATRIZ DE INDICES
====================================================================

Objeto                                      Finalidade
uq_entrada_lote_correlation_id              idempotencia global; criado pela unique
uq_entrada_lote_ativo_item_lote_datas       agrupamento ativo unico normalizado
uq_entrada_lote_documento_confirmado        documento + exercicio SAP unicos
ix_entrada_lote_item                        lotes por item
ix_entrada_lote_status                      fila e historico por status/data
ix_entrada_lote_numero                      diagnostico por Batch normalizado
ix_entrada_lote_pendente_envio              FINALIZADO_LOCAL e ERRO_SAP
ix_entrada_lote_erro_sap                    fila dedicada de erros
ix_entrada_pesagem_lote                     pesagens por lote

Nao foi criado indice separado para correlation_id porque a unique constraint
ja cria o indice necessario.

Nao foi criado indice comum adicional para documento SAP porque o indice
unico parcial atende o fluxo confirmado. Sua chave e exatamente:
- documento_material_sap;
- exercicio_documento_material_sap.
O documento_material_item nao participa do indice unico.

====================================================================
12. MATRIZ DE GRANTS
====================================================================

Objeto                         SELECT INSERT UPDATE DELETE TRUNCATE
entrada_produto_lote           sim    sim    sim    nao    nao
entrada_produto_pesagem        sim    sim    sim    nao    nao

Sequence entrada_produto_lote:
- USAGE: sim
- SELECT: sim
- UPDATE: nao

ALTER e DROP nao sao concedidos por grants de tabela.
O papel fugapet_dev_app nao deve ser proprietario dos objetos.

Os grants de entrada_produto_pesagem sao preservados no nivel da tabela.
No PostgreSQL, os grants de tabela incluem as novas colunas automaticamente.

====================================================================
13. PREFLIGHT
====================================================================

O PREFLIGHT:
- usa BEGIN + SET TRANSACTION READ ONLY + ROLLBACK;
- nao aceita PACOTE_COMPLETAMENTE_APLICADO apenas pela existencia dos nomes;
- valida definicoes reais com pg_get_constraintdef, pg_get_indexdef,
  pg_get_triggerdef e pg_get_functiondef;
- valida banco, schema e PostgreSQL;
- valida fugapet_dev_app, CONNECT e USAGE;
- valida as tres tabelas atuais da Entrada;
- valida colunas essenciais e FKs RESTRICT;
- registra quantidade historica;
- verifica homonimos;
- verifica aplicacao parcial;
- verifica as 23 colunas, tipos, tamanhos, nullability, identity e defaults;
- verifica expressoes reais de checks, PK, FKs e unique correlation_id;
- verifica colunas, expressoes, filtros e unicidade reais dos indices;
- restringe triggers as tabelas entrada_produto_lote e entrada_produto_pesagem;
- verifica eventos, timing, UPDATE OF e funcao vinculada dos triggers;
- verifica assinaturas, plpgsql, SECURITY DEFINER, search_path, owner,
  revogacao de EXECUTE de PUBLIC e protecoes do corpo das funcoes;
- verifica grants;
- classifica:
  PACOTE_NAO_APLICADO
  PACOTE_COMPLETAMENTE_APLICADO
  PACOTE_PARCIAL_INCOMPATIVEL.

====================================================================
14. PROPOSTA
====================================================================

A PROPOSTA:
- usa ON_ERROR_STOP;
- usa BEGIN/COMMIT;
- define lock_timeout e statement_timeout;
- exige pacote ainda nao aplicado;
- cria entrada_produto_lote;
- adiciona FK e snapshots nullable na pesagem;
- usa constraints NOT VALID + VALIDATE para as alteracoes na tabela historica;
- cria indices, funcoes, triggers e grants;
- nao executa UPDATE massivo;
- nao insere lote;
- nao altera status historico;
- termina com mensagem inequivoca de sucesso.

====================================================================
15. VALIDACAO
====================================================================

A VALIDACAO usa transacao e rollback interno para testar:

- lote valido;
- lote vazio bloqueado;
- vencimento anterior a fabricacao bloqueado;
- correlation_id duplicado bloqueado;
- mesmo lote/datas no mesmo item bloqueado;
- mesmo lote/datas em item diferente permitido;
- INSERT sem peso aceito e persistido com zero;
- peso positivo manual no INSERT bloqueado;
- peso negativo manual no INSERT bloqueado;
- update direto do peso bloqueado;
- CONFIRMADO_SAP sem documento bloqueado;
- payload com credencial bloqueado;
- pesagem vinculada ao lote;
- snapshot correspondente e preservado;
- consolidacao de peso;
- alteracao do lote apos pesagem bloqueada;
- alteracao de snapshot bloqueada;
- atualizacao coerente de status SAP permitida;
- reenvio de CONFIRMADO_SAP bloqueado;
- mesmo documento/ano com item SAP diferente bloqueado;
- alterado_em renovado em atualizacoes sucessivas;
- definicoes reais de indices confirmadas por pg_get_indexdef;
- definicoes reais das FKs confirmadas por pg_get_constraintdef;
- trigger do lote confirmada em BEFORE INSERT OR UPDATE;
- SECURITY DEFINER confirmado somente nas funcoes de consolidacao;
- EXECUTE de PUBLIC ausente nas quatro funcoes;
- FKs ON DELETE RESTRICT;
- grants minimos;
- zero residuos;
- ausencia de alteracao historica.

Requisito operacional para a validacao:
- deve existir pelo menos uma pesagem historica legada ainda sem lote;
- deve existir pelo menos um segundo item de entrada.
A validacao usa esses registros somente dentro da transacao e executa ROLLBACK.

====================================================================
16. ROLLBACK OFICIAL
====================================================================

O rollback:
- e separado;
- nunca e automatico;
- exige:
  CONFIRMAR_ROLLBACK_043=EU_CONFIRMO_ROLLBACK_043_DEV
- bloqueia se houver qualquer lote;
- bloqueia se houver pesagem vinculada ou snapshot preenchido;
- remove triggers, funcoes, constraint, indice e colunas do 043;
- remove entrada_produto_lote sem CASCADE;
- nao apaga lancamentos, itens ou pesagens;
- nao toca em integracoes anteriores.

Depois que o fluxo C# criar o primeiro lote, o rollback fica
intencionalmente bloqueado.

====================================================================
17. RISCOS E PENDENCIAS
====================================================================

1. Regras de obrigatoriedade SAP
A estrutura suporta Batch, ManufactureDate e ShelfLifeExpirationDate, mas
a fonte SAP que informa se cada material exige lote/validade continua sendo
contrato funcional da integracao e nao foi inventada no banco.

2. Aplicacao C#
O pacote de banco deve ser acompanhado pela alteracao controlada da tela,
servico, repositorio, payload SAP 101, etiqueta e reimpressao. O banco nao
ativa sozinho o novo fluxo.

3. Um documento por lote
O C# deve consolidar e enviar cada lote separadamente, com correlation_id
proprio. O status do lancamento passa a ser uma consolidacao dos lotes.

4. Concorrencia
A unique ativa e o correlation_id protegem a idempotencia no banco.
O C# ainda deve usar transacao para criar lote, vincular pesagens e mudar
status.

5. Dados SAP sensiveis
O check de JSON bloqueia chaves sensiveis conhecidas. A aplicacao tambem
deve sanitizar valores e logs; nao deve depender apenas da constraint.

6. Tamanho Batch
Foi adotado limite de 10 caracteres. Mudanca futura no contrato SAP exige
novo incremental, nunca alteracao manual deste pacote.

====================================================================
18. ORDEM CONTROLADA
====================================================================

1. Revisar o pacote com Michael Richard e Dedalo.
2. Autorizar e executar somente PREFLIGHT.
3. Revisar a evidencia.
4. Autorizar e executar PROPOSTA.
5. Revisar a evidencia.
6. Autorizar e executar VALIDACAO.
7. Somente depois desenvolver/validar o fluxo funcional.
8. Nao promover automaticamente para HML ou PRD.

====================================================================
19. CONTROLE FINAL DA PREPARACAO
====================================================================

SQL executado: nao.
DEV alterado: nao.
HML acessado/alterado: nao.
PRD acessado/alterado: nao.
Codigo C# alterado: nao.
Commit/push: nao realizado.
Dados produtivos inseridos: nao.
Registros historicos modificados: nao.


====================================================================
20. CORRECOES CONTROLADAS DA REVISAO
====================================================================

1. Unicidade do documento SAP
A chave unica parcial de CONFIRMADO_SAP passou a usar somente:
- documento_material_sap;
- exercicio_documento_material_sap.
O item SAP continua obrigatorio no documento completo, mas nao participa da
unicidade.

2. Peso total no INSERT e UPDATE
A trigger do lote executa em BEFORE INSERT OR UPDATE.
No INSERT, peso_liquido_total_kg diferente de zero e bloqueado.
No UPDATE, alteracao direta do peso e bloqueada; somente a atualizacao aninhada
originada pela trigger de consolidacao das pesagens e permitida.

3. alterado_em
Toda atualizacao executa:
NEW.alterado_em := clock_timestamp();
O timestamp informado pelo cliente nao e preservado.

4. PREFLIGHT e VALIDACAO endurecidos
As definicoes reais de constraints, indices, triggers e funcoes sao analisadas.
A existencia isolada de nomes nao caracteriza pacote completamente aplicado.

====================================================================
21. INTEGRIDADE CRIPTOGRAFICA DA ENTREGA
====================================================================

Todos os SQL possuem:
- primeira linha: \set ON_ERROR_STOP on
- codificacao: UTF-8 sem BOM
- terminacao de linha: LF

Os hashes dos quatro SQL sao registrados abaixo depois da finalizacao dos
arquivos.

O SHA-256 do proprio README e o SHA-256 do ZIP efetivamente entregue nao podem
ser embutidos dentro do mesmo README/ZIP sem alterar os bytes que estao sendo
calculados. Isso criaria uma autorreferencia criptografica impossivel de fechar
de forma confiavel. Por esse motivo:
- o README interno registra os hashes imutaveis dos quatro SQL;
- o manifesto SHA-256 destacado, entregue ao lado do ZIP, registra o hash real
  do ZIP e dos cinco arquivos, inclusive este README;
- o README de entrega externo repete todos os hashes reais.

- 043_entrada_produto_lote_DEV_PREFLIGHT_GAIA.sql: E4A3B231667507E19DCF93AB6193E9131BF5354789D08BA71B0B1DFD396506E6
- 043_entrada_produto_lote_DEV_PROPOSTA_GAIA.sql: BE773763476D718B65C17D850A77A4B0CE4768CDB523F59F3F1AC68A832C2704
- 043_entrada_produto_lote_DEV_VALIDACAO_GAIA.sql: 1B3BA6BE488D0FA0CDC5728423D8962751945FCE3403963C1C67A07869B4EEB4
- 043_entrada_produto_lote_DEV_ROLLBACK_GAIA.sql: 4CB597A293D4E09C97EE6D2DAA418E8BFBF23F45358152BEAFFB4BA52B1B3AD0
