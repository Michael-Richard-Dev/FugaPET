\set ON_ERROR_STOP on
-- ============================================================================
-- 043_entrada_produto_lote_DEV_VALIDACAO_GAIA.sql
-- Validacao estrutural e funcional transacional do incremental 043 DEV.
--
-- Usa lotes de teste com IDs negativos e uma pesagem historica temporariamente
-- vinculada dentro da transacao. Todo o cenario e descartado por ROLLBACK.
-- NAO avanca a sequence identity da tabela de lote.
-- ============================================================================

SET search_path TO desenvolvimento, public;

SELECT set_config(
    'fugapet_v043.lote_hash_antes',
    md5(COALESCE(
        string_agg(
            md5(row_to_json(t)::text),
            '' ORDER BY codigo_entrada_produto_lote
        ),
        ''
    )),
    false
)
FROM desenvolvimento.entrada_produto_lote t;

SELECT set_config(
    'fugapet_v043.pesagem_hash_antes',
    md5(COALESCE(
        string_agg(
            md5(row_to_json(t)::text),
            '' ORDER BY codigo_entrada_produto_pesagem
        ),
        ''
    )),
    false
)
FROM desenvolvimento.entrada_produto_pesagem t;

SELECT set_config(
    'fugapet_v043.item_hash_antes',
    md5(COALESCE(
        string_agg(
            md5(row_to_json(t)::text),
            '' ORDER BY codigo_entrada_produto_item
        ),
        ''
    )),
    false
)
FROM desenvolvimento.entrada_produto_item t;

SELECT set_config(
    'fugapet_v043.lancamento_hash_antes',
    md5(COALESCE(
        string_agg(
            md5(row_to_json(t)::text),
            '' ORDER BY codigo_entrada_produto_lancamento
        ),
        ''
    )),
    false
)
FROM desenvolvimento.entrada_produto_lancamento t;

SELECT set_config(
    'fugapet_v043.lote_qtd_antes',
    count(*)::text,
    false
)
FROM desenvolvimento.entrada_produto_lote;

DO $$
DECLARE
    v_colunas_lote integer;
    v_colunas_pesagem integer;
    v_constraints_lote integer;
    v_constraints_pesagem integer;
    v_indices integer;
    v_triggers integer;
    v_funcoes integer;
    v_fk_defs integer;
    v_index_defs integer;
    v_trigger_defs integer;
    v_function_defs integer;
BEGIN
    IF current_database() <> 'fuga_jales_local_desenvolvimento' THEN
        RAISE EXCEPTION
            'VALIDACAO 043: banco incorreto: %.',
            current_database();
    END IF;

    SELECT count(*) INTO v_colunas_lote
    FROM information_schema.columns
    WHERE table_schema = 'desenvolvimento'
      AND table_name = 'entrada_produto_lote';

    SELECT count(*) INTO v_colunas_pesagem
    FROM information_schema.columns
    WHERE table_schema = 'desenvolvimento'
      AND table_name = 'entrada_produto_pesagem'
      AND column_name IN (
          'codigo_entrada_produto_lote',
          'numero_lote_snapshot',
          'data_fabricacao_snapshot',
          'data_vencimento_snapshot'
      );

    SELECT count(*) INTO v_constraints_lote
    FROM pg_constraint
    WHERE conrelid =
          'desenvolvimento.entrada_produto_lote'::regclass
      AND conname IN (
          'pk_entrada_produto_lote',
          'fk_entrada_lote_item',
          'uq_entrada_lote_correlation_id',
          'ck_entrada_lote_numero_nao_vazio',
          'ck_entrada_lote_datas',
          'ck_entrada_lote_peso_total',
          'ck_entrada_lote_status',
          'ck_entrada_lote_documento_conjunto',
          'ck_entrada_lote_confirmado_sap_documento',
          'ck_entrada_lote_erro_sap',
          'ck_entrada_lote_quantidade_retorno',
          'ck_entrada_lote_criado_por',
          'ck_entrada_lote_alterado_por',
          'ck_entrada_lote_enviado_em',
          'ck_entrada_lote_confirmado_em',
          'ck_entrada_lote_payload_sem_credencial'
      );

    SELECT count(*) INTO v_constraints_pesagem
    FROM pg_constraint
    WHERE conrelid =
          'desenvolvimento.entrada_produto_pesagem'::regclass
      AND conname IN (
          'fk_entrada_pesagem_lote',
          'ck_entrada_pesagem_lote_snapshot_conjunto'
      );

    SELECT count(*) INTO v_indices
    FROM pg_indexes
    WHERE schemaname = 'desenvolvimento'
      AND indexname IN (
          'uq_entrada_lote_ativo_item_lote_datas',
          'uq_entrada_lote_documento_confirmado',
          'ix_entrada_lote_item',
          'ix_entrada_lote_status',
          'ix_entrada_lote_numero',
          'ix_entrada_lote_pendente_envio',
          'ix_entrada_lote_erro_sap',
          'ix_entrada_pesagem_lote'
      );

    SELECT count(*) INTO v_triggers
    FROM pg_trigger t
    JOIN pg_class rel ON rel.oid = t.tgrelid
    JOIN pg_namespace n ON n.oid = rel.relnamespace
    WHERE NOT t.tgisinternal
      AND n.nspname = 'desenvolvimento'
      AND rel.relname IN ('entrada_produto_lote', 'entrada_produto_pesagem')
      AND t.tgname IN (
          'trg_entrada_produto_lote_proteger_update',
          'trg_entrada_produto_pesagem_validar_lote',
          'trg_entrada_produto_pesagem_recalcular_lote'
      );

    SELECT count(*) INTO v_funcoes
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'desenvolvimento'
      AND p.proname IN (
          'fn_entrada_produto_lote_proteger_update',
          'fn_entrada_produto_pesagem_validar_lote_snapshot',
          'fn_entrada_produto_lote_recalcular_peso',
          'fn_entrada_produto_pesagem_recalcular_lote'
      );

    SELECT count(*) INTO v_fk_defs
    FROM pg_constraint c
    WHERE (
        c.conname = 'fk_entrada_lote_item'
        AND c.conrelid = 'desenvolvimento.entrada_produto_lote'::regclass
        AND c.confrelid = 'desenvolvimento.entrada_produto_item'::regclass
        AND c.confdeltype = 'r'
        AND position('ON DELETE RESTRICT' in upper(pg_get_constraintdef(c.oid, true))) > 0
    ) OR (
        c.conname = 'fk_entrada_pesagem_lote'
        AND c.conrelid = 'desenvolvimento.entrada_produto_pesagem'::regclass
        AND c.confrelid = 'desenvolvimento.entrada_produto_lote'::regclass
        AND c.confdeltype = 'r'
        AND position('ON DELETE RESTRICT' in upper(pg_get_constraintdef(c.oid, true))) > 0
    );

    WITH idx AS (
        SELECT
            ci.relname AS indexname,
            ct.relname AS tablename,
            i.indisunique,
            i.indnkeyatts,
            lower(regexp_replace(pg_get_indexdef(ci.oid), '[[:space:]]+', ' ', 'g')) AS def,
            lower(COALESCE(pg_get_expr(i.indpred, i.indrelid), '')) AS pred
        FROM pg_index i
        JOIN pg_class ci ON ci.oid = i.indexrelid
        JOIN pg_class ct ON ct.oid = i.indrelid
        JOIN pg_namespace n ON n.oid = ct.relnamespace
        WHERE n.nspname = 'desenvolvimento'
          AND ci.relname IN (
              'uq_entrada_lote_ativo_item_lote_datas',
              'uq_entrada_lote_documento_confirmado',
              'ix_entrada_lote_pendente_envio',
              'ix_entrada_lote_erro_sap'
          )
    )
    SELECT count(*) INTO v_index_defs
    FROM idx x
    WHERE
       (x.indexname = 'uq_entrada_lote_ativo_item_lote_datas'
        AND x.indisunique AND x.indnkeyatts = 4
        AND position('upper' in x.def) > 0
        AND position('btrim' in x.def) > 0
        AND position('numero_lote' in x.def) > 0
        AND position('cancelado' in x.pred) > 0)
    OR (x.indexname = 'uq_entrada_lote_documento_confirmado'
        AND x.indisunique AND x.indnkeyatts = 2
        AND position('documento_material_sap' in x.def) > 0
        AND position('exercicio_documento_material_sap' in x.def) > 0
        AND position('documento_material_item' in x.def) = 0
        AND position('confirmado_sap' in x.pred) > 0)
    OR (x.indexname = 'ix_entrada_lote_pendente_envio'
        AND NOT x.indisunique
        AND position('finalizado_local' in x.pred) > 0
        AND position('erro_sap' in x.pred) > 0)
    OR (x.indexname = 'ix_entrada_lote_erro_sap'
        AND NOT x.indisunique
        AND position('erro_sap' in x.pred) > 0);

    WITH trg AS (
        SELECT
            t.tgname,
            rel.relname AS tablename,
            t.tgtype,
            t.tgfoid,
            lower(regexp_replace(pg_get_triggerdef(t.oid, true), '[[:space:]]+', ' ', 'g')) AS def
        FROM pg_trigger t
        JOIN pg_class rel ON rel.oid = t.tgrelid
        JOIN pg_namespace n ON n.oid = rel.relnamespace
        WHERE NOT t.tgisinternal
          AND n.nspname = 'desenvolvimento'
          AND rel.relname IN ('entrada_produto_lote', 'entrada_produto_pesagem')
          AND t.tgname IN (
              'trg_entrada_produto_lote_proteger_update',
              'trg_entrada_produto_pesagem_validar_lote',
              'trg_entrada_produto_pesagem_recalcular_lote'
          )
    )
    SELECT count(*) INTO v_trigger_defs
    FROM trg t
    WHERE
       (t.tgname = 'trg_entrada_produto_lote_proteger_update'
        AND t.tablename = 'entrada_produto_lote'
        AND t.tgtype = 23
        AND t.tgfoid = 'desenvolvimento.fn_entrada_produto_lote_proteger_update()'::regprocedure
        AND position('before insert or update' in t.def) > 0)
    OR (t.tgname = 'trg_entrada_produto_pesagem_validar_lote'
        AND t.tablename = 'entrada_produto_pesagem'
        AND t.tgtype = 31
        AND t.tgfoid = 'desenvolvimento.fn_entrada_produto_pesagem_validar_lote_snapshot()'::regprocedure)
    OR (t.tgname = 'trg_entrada_produto_pesagem_recalcular_lote'
        AND t.tablename = 'entrada_produto_pesagem'
        AND t.tgtype = 29
        AND t.tgfoid = 'desenvolvimento.fn_entrada_produto_pesagem_recalcular_lote()'::regprocedure
        AND position('update of codigo_entrada_produto_lote, peso_liquido_kg, status_pesagem, situacao_entrada_produto_pesagem' in t.def) > 0);

    WITH fun AS (
        SELECT
            p.*,
            l.lanname,
            r.rolname AS owner_name,
            lower(regexp_replace(pg_get_functiondef(p.oid), '[[:space:]]+', ' ', 'g')) AS def,
            EXISTS (
                SELECT 1
                FROM unnest(COALESCE(p.proconfig, ARRAY[]::text[])) cfg
                WHERE replace(lower(cfg), ' ', '') = 'search_path=desenvolvimento,pg_temp'
            ) AS search_path_ok,
            NOT EXISTS (
                SELECT 1
                FROM aclexplode(COALESCE(p.proacl, acldefault('f', p.proowner))) a
                WHERE a.grantee = 0
                  AND a.privilege_type = 'EXECUTE'
            ) AS public_execute_revogado
        FROM pg_proc p
        JOIN pg_namespace n ON n.oid = p.pronamespace
        JOIN pg_language l ON l.oid = p.prolang
        JOIN pg_roles r ON r.oid = p.proowner
        WHERE n.nspname = 'desenvolvimento'
          AND p.proname IN (
              'fn_entrada_produto_lote_proteger_update',
              'fn_entrada_produto_pesagem_validar_lote_snapshot',
              'fn_entrada_produto_lote_recalcular_peso',
              'fn_entrada_produto_pesagem_recalcular_lote'
          )
    )
    SELECT count(*) INTO v_function_defs
    FROM fun f
    WHERE f.lanname = 'plpgsql'
      AND f.owner_name <> 'fugapet_dev_app'
      AND f.search_path_ok
      AND f.public_execute_revogado
      AND (
          (f.proname = 'fn_entrada_produto_lote_proteger_update'
           AND NOT f.prosecdef
           AND position('tg_op = ''insert''' in f.def) > 0
           AND position('peso_liquido_total_kg is distinct from 0' in f.def) > 0
           AND position('new.alterado_em := clock_timestamp()' in f.def) > 0)
       OR (f.proname = 'fn_entrada_produto_pesagem_validar_lote_snapshot'
           AND NOT f.prosecdef)
       OR (f.proname = 'fn_entrada_produto_lote_recalcular_peso'
           AND f.prosecdef)
       OR (f.proname = 'fn_entrada_produto_pesagem_recalcular_lote'
           AND f.prosecdef)
      );

    IF v_colunas_lote <> 23
       OR v_colunas_pesagem <> 4
       OR v_constraints_lote <> 16
       OR v_constraints_pesagem <> 2
       OR v_indices <> 8
       OR v_triggers <> 3
       OR v_funcoes <> 4
       OR v_fk_defs <> 2
       OR v_index_defs <> 4
       OR v_trigger_defs <> 3
       OR v_function_defs <> 4 THEN
        RAISE EXCEPTION
            'VALIDACAO 043 ESTRUTURA REPROVADA: colunas_lote=%, colunas_pesagem=%, constraints_lote=%, constraints_pesagem=%, indices=%, triggers=%, funcoes=%, fk_defs=%/2, index_defs=%/4, trigger_defs=%/3, function_defs=%/4.',
            v_colunas_lote,
            v_colunas_pesagem,
            v_constraints_lote,
            v_constraints_pesagem,
            v_indices,
            v_triggers,
            v_funcoes,
            v_fk_defs,
            v_index_defs,
            v_trigger_defs,
            v_function_defs;
    END IF;

    IF NOT has_table_privilege(
        'fugapet_dev_app',
        'desenvolvimento.entrada_produto_lote',
        'SELECT'
    )
    OR NOT has_table_privilege(
        'fugapet_dev_app',
        'desenvolvimento.entrada_produto_lote',
        'INSERT'
    )
    OR NOT has_table_privilege(
        'fugapet_dev_app',
        'desenvolvimento.entrada_produto_lote',
        'UPDATE'
    )
    OR has_table_privilege(
        'fugapet_dev_app',
        'desenvolvimento.entrada_produto_lote',
        'DELETE'
    )
    OR has_table_privilege(
        'fugapet_dev_app',
        'desenvolvimento.entrada_produto_lote',
        'TRUNCATE'
    ) THEN
        RAISE EXCEPTION
            'VALIDACAO 043: grants minimos da tabela de lote incompativeis.';
    END IF;

    RAISE NOTICE
        'VALIDACAO 043 ESTRUTURAL OK: definicoes reais de FKs, indices, triggers e funcoes confirmadas.';
END $$;

\echo 'VALIDACAO 043 - DEFINICOES REAIS CRITICAS'
SELECT c.conname, pg_get_constraintdef(c.oid, true) AS definicao
FROM pg_constraint c
WHERE c.conname IN ('fk_entrada_lote_item', 'fk_entrada_pesagem_lote')
ORDER BY c.conname;

SELECT ci.relname AS indice, pg_get_indexdef(ci.oid) AS definicao,
       pg_get_expr(i.indpred, i.indrelid) AS predicado
FROM pg_index i
JOIN pg_class ci ON ci.oid = i.indexrelid
JOIN pg_namespace n ON n.oid = ci.relnamespace
WHERE n.nspname = 'desenvolvimento'
  AND ci.relname IN (
      'uq_entrada_lote_ativo_item_lote_datas',
      'uq_entrada_lote_documento_confirmado',
      'ix_entrada_lote_pendente_envio',
      'ix_entrada_lote_erro_sap'
  )
ORDER BY ci.relname;

SELECT t.tgname, t.tgrelid::regclass AS tabela,
       pg_get_triggerdef(t.oid, true) AS definicao
FROM pg_trigger t
WHERE NOT t.tgisinternal
  AND t.tgrelid IN (
      'desenvolvimento.entrada_produto_lote'::regclass,
      'desenvolvimento.entrada_produto_pesagem'::regclass
  )
  AND t.tgname IN (
      'trg_entrada_produto_lote_proteger_update',
      'trg_entrada_produto_pesagem_validar_lote',
      'trg_entrada_produto_pesagem_recalcular_lote'
  )
ORDER BY t.tgname;


BEGIN;
SET LOCAL lock_timeout = '10s';
SET LOCAL statement_timeout = '5min';

DO $$
DECLARE
    v_pesagem bigint;
    v_item_1 bigint;
    v_item_2 bigint;
    v_peso_esperado numeric(14,3);
    v_peso_lote numeric(14,3);
    v_alterado_em_1 timestamp with time zone;
    v_alterado_em_2 timestamp with time zone;
    v_falhou boolean;
BEGIN
    SELECT
        p.codigo_entrada_produto_pesagem,
        p.codigo_entrada_produto_item,
        CASE
            WHEN p.situacao_entrada_produto_pesagem = true
             AND p.status_pesagem = 'VALIDA'
            THEN p.peso_liquido_kg
            ELSE 0
        END::numeric(14,3)
    INTO
        v_pesagem,
        v_item_1,
        v_peso_esperado
    FROM desenvolvimento.entrada_produto_pesagem p
    WHERE p.codigo_entrada_produto_lote IS NULL
      AND p.numero_lote_snapshot IS NULL
      AND p.data_fabricacao_snapshot IS NULL
      AND p.data_vencimento_snapshot IS NULL
    ORDER BY p.codigo_entrada_produto_pesagem
    LIMIT 1;

    IF v_pesagem IS NULL THEN
        RAISE EXCEPTION
            'VALIDACAO 043: nenhuma pesagem historica legada disponivel para teste transacional.';
    END IF;

    SELECT i.codigo_entrada_produto_item
      INTO v_item_2
      FROM desenvolvimento.entrada_produto_item i
     WHERE i.codigo_entrada_produto_item <> v_item_1
     ORDER BY i.codigo_entrada_produto_item
     LIMIT 1;

    IF v_item_2 IS NULL THEN
        RAISE EXCEPTION
            'VALIDACAO 043: necessario segundo item de entrada para testar mesmo lote em item diferente.';
    END IF;

    INSERT INTO desenvolvimento.entrada_produto_lote (
        codigo_entrada_produto_lote,
        codigo_entrada_produto_item,
        numero_lote,
        data_fabricacao,
        data_vencimento,
        status_lote,
        correlation_id,
        criado_por
    ) VALUES (
        -430001,
        v_item_1,
        'LT43001',
        DATE '2026-01-01',
        DATE '2027-01-01',
        'AGUARDANDO_DADOS',
        '04300000-0000-0000-0000-000000000001'::uuid,
        'VALIDADOR_043'
    );

    INSERT INTO desenvolvimento.entrada_produto_lote (
        codigo_entrada_produto_lote,
        codigo_entrada_produto_item,
        numero_lote,
        data_fabricacao,
        data_vencimento,
        status_lote,
        correlation_id,
        criado_por
    ) VALUES (
        -430002,
        v_item_2,
        'LT43001',
        DATE '2026-01-01',
        DATE '2027-01-01',
        'AGUARDANDO_DADOS',
        '04300000-0000-0000-0000-000000000002'::uuid,
        'VALIDADOR_043'
    );

    RAISE NOTICE
        'VALIDACAO 043 OK: mesmo lote/datas em item diferente permitido.';

    SELECT peso_liquido_total_kg
      INTO v_peso_lote
      FROM desenvolvimento.entrada_produto_lote
     WHERE codigo_entrada_produto_lote = -430001;

    IF v_peso_lote IS DISTINCT FROM 0::numeric THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: INSERT sem peso nao gravou zero; encontrado %.',
            v_peso_lote;
    END IF;

    RAISE NOTICE
        'VALIDACAO 043 OK: INSERT sem peso aceito e gravado com zero.';

    v_falhou := false;
    BEGIN
        INSERT INTO desenvolvimento.entrada_produto_lote (
            codigo_entrada_produto_lote,
            codigo_entrada_produto_item,
            numero_lote,
            data_fabricacao,
            data_vencimento,
            peso_liquido_total_kg,
            status_lote,
            correlation_id,
            criado_por
        ) VALUES (
            -430012,
            v_item_1,
            'LT43012',
            DATE '2026-01-01',
            DATE '2027-01-01',
            1,
            'AGUARDANDO_DADOS',
            '04300000-0000-0000-0000-000000000012'::uuid,
            'VALIDADOR_043'
        );
    EXCEPTION WHEN raise_exception THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: peso positivo manual no INSERT foi aceito.';
    END IF;

    RAISE NOTICE
        'VALIDACAO 043 OK: peso positivo manual no INSERT bloqueado.';

    v_falhou := false;
    BEGIN
        INSERT INTO desenvolvimento.entrada_produto_lote (
            codigo_entrada_produto_lote,
            codigo_entrada_produto_item,
            numero_lote,
            data_fabricacao,
            data_vencimento,
            status_lote,
            correlation_id,
            criado_por
        ) VALUES (
            -430003,
            v_item_1,
            '  ',
            DATE '2026-01-01',
            DATE '2027-01-01',
            'AGUARDANDO_DADOS',
            '04300000-0000-0000-0000-000000000003'::uuid,
            'VALIDADOR_043'
        );
    EXCEPTION WHEN check_violation THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: lote vazio foi aceito.';
    END IF;

    v_falhou := false;
    BEGIN
        INSERT INTO desenvolvimento.entrada_produto_lote (
            codigo_entrada_produto_lote,
            codigo_entrada_produto_item,
            numero_lote,
            data_fabricacao,
            data_vencimento,
            status_lote,
            correlation_id,
            criado_por
        ) VALUES (
            -430004,
            v_item_1,
            'LT43004',
            DATE '2027-01-01',
            DATE '2026-01-01',
            'AGUARDANDO_DADOS',
            '04300000-0000-0000-0000-000000000004'::uuid,
            'VALIDADOR_043'
        );
    EXCEPTION WHEN check_violation THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: vencimento anterior a fabricacao foi aceito.';
    END IF;

    v_falhou := false;
    BEGIN
        INSERT INTO desenvolvimento.entrada_produto_lote (
            codigo_entrada_produto_lote,
            codigo_entrada_produto_item,
            numero_lote,
            data_fabricacao,
            data_vencimento,
            status_lote,
            correlation_id,
            criado_por
        ) VALUES (
            -430005,
            v_item_1,
            'LT43005',
            DATE '2026-01-01',
            DATE '2027-01-01',
            'AGUARDANDO_DADOS',
            '04300000-0000-0000-0000-000000000001'::uuid,
            'VALIDADOR_043'
        );
    EXCEPTION WHEN unique_violation THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: correlation_id duplicado foi aceito.';
    END IF;

    v_falhou := false;
    BEGIN
        INSERT INTO desenvolvimento.entrada_produto_lote (
            codigo_entrada_produto_lote,
            codigo_entrada_produto_item,
            numero_lote,
            data_fabricacao,
            data_vencimento,
            status_lote,
            correlation_id,
            criado_por
        ) VALUES (
            -430006,
            v_item_1,
            ' lt43001 ',
            DATE '2026-01-01',
            DATE '2027-01-01',
            'AGUARDANDO_DADOS',
            '04300000-0000-0000-0000-000000000006'::uuid,
            'VALIDADOR_043'
        );
    EXCEPTION WHEN unique_violation THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: agrupamento ativo duplicado normalizado foi aceito.';
    END IF;

    v_falhou := false;
    BEGIN
        INSERT INTO desenvolvimento.entrada_produto_lote (
            codigo_entrada_produto_lote,
            codigo_entrada_produto_item,
            numero_lote,
            data_fabricacao,
            data_vencimento,
            peso_liquido_total_kg,
            status_lote,
            correlation_id,
            criado_por
        ) VALUES (
            -430007,
            v_item_1,
            'LT43007',
            DATE '2026-01-01',
            DATE '2027-01-01',
            -1,
            'AGUARDANDO_DADOS',
            '04300000-0000-0000-0000-000000000007'::uuid,
            'VALIDADOR_043'
        );
    EXCEPTION WHEN check_violation OR raise_exception THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: peso negativo foi aceito.';
    END IF;

    v_falhou := false;
    BEGIN
        INSERT INTO desenvolvimento.entrada_produto_lote (
            codigo_entrada_produto_lote,
            codigo_entrada_produto_item,
            numero_lote,
            data_fabricacao,
            data_vencimento,
            status_lote,
            correlation_id,
            confirmado_em,
            enviado_sap_em,
            confirmado_sap_em,
            criado_por
        ) VALUES (
            -430008,
            v_item_1,
            'LT43008',
            DATE '2026-01-01',
            DATE '2027-01-01',
            'CONFIRMADO_SAP',
            '04300000-0000-0000-0000-000000000008'::uuid,
            clock_timestamp(),
            clock_timestamp(),
            clock_timestamp(),
            'VALIDADOR_043'
        );
    EXCEPTION WHEN check_violation THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: CONFIRMADO_SAP sem documento foi aceito.';
    END IF;

    v_falhou := false;
    BEGIN
        INSERT INTO desenvolvimento.entrada_produto_lote (
            codigo_entrada_produto_lote,
            codigo_entrada_produto_item,
            numero_lote,
            data_fabricacao,
            data_vencimento,
            status_lote,
            correlation_id,
            payload_enviado_json,
            criado_por
        ) VALUES (
            -430009,
            v_item_1,
            'LT43009',
            DATE '2026-01-01',
            DATE '2027-01-01',
            'AGUARDANDO_DADOS',
            '04300000-0000-0000-0000-000000000009'::uuid,
            '{"Authorization":"Basic segredo"}'::jsonb,
            'VALIDADOR_043'
        );
    EXCEPTION WHEN check_violation THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: payload com credencial foi aceito.';
    END IF;

    UPDATE desenvolvimento.entrada_produto_pesagem
       SET codigo_entrada_produto_lote = -430001,
           numero_lote_snapshot = 'LT43001',
           data_fabricacao_snapshot = DATE '2026-01-01',
           data_vencimento_snapshot = DATE '2027-01-01'
     WHERE codigo_entrada_produto_pesagem = v_pesagem;

    SELECT peso_liquido_total_kg
      INTO v_peso_lote
      FROM desenvolvimento.entrada_produto_lote
     WHERE codigo_entrada_produto_lote = -430001;

    IF v_peso_lote IS DISTINCT FROM v_peso_esperado THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: total do lote %, esperado %.',
            v_peso_lote,
            v_peso_esperado;
    END IF;

    RAISE NOTICE
        'VALIDACAO 043 OK: pesagem vinculada, snapshot validado e peso consolidado pela fonte de verdade.';

    v_falhou := false;
    BEGIN
        UPDATE desenvolvimento.entrada_produto_lote
           SET peso_liquido_total_kg = peso_liquido_total_kg + 1
         WHERE codigo_entrada_produto_lote = -430001;
    EXCEPTION WHEN raise_exception THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: update direto do peso total foi aceito.';
    END IF;

    RAISE NOTICE
        'VALIDACAO 043 OK: update direto do peso bloqueado; consolidacao interna preservada.';

    v_falhou := false;
    BEGIN
        UPDATE desenvolvimento.entrada_produto_lote
           SET numero_lote = 'ALTERADO'
         WHERE codigo_entrada_produto_lote = -430001;
    EXCEPTION WHEN raise_exception THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: lote alterado apos pesagem.';
    END IF;

    v_falhou := false;
    BEGIN
        UPDATE desenvolvimento.entrada_produto_pesagem
           SET numero_lote_snapshot = 'ALTERADO'
         WHERE codigo_entrada_produto_pesagem = v_pesagem;
    EXCEPTION WHEN raise_exception THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: snapshot alterado.';
    END IF;

    UPDATE desenvolvimento.entrada_produto_lote
       SET status_lote = 'LOTE_CONFIRMADO',
           confirmado_em = clock_timestamp(),
           alterado_por = 'VALIDADOR_043'
     WHERE codigo_entrada_produto_lote = -430001;

    SELECT alterado_em
      INTO v_alterado_em_1
      FROM desenvolvimento.entrada_produto_lote
     WHERE codigo_entrada_produto_lote = -430001;

    PERFORM pg_sleep(0.01);

    UPDATE desenvolvimento.entrada_produto_lote
       SET alterado_por = 'VALIDADOR_043_SEGUNDA_ATUALIZACAO'
     WHERE codigo_entrada_produto_lote = -430001;

    SELECT alterado_em
      INTO v_alterado_em_2
      FROM desenvolvimento.entrada_produto_lote
     WHERE codigo_entrada_produto_lote = -430001;

    IF v_alterado_em_1 IS NULL
       OR v_alterado_em_2 IS NULL
       OR v_alterado_em_2 <= v_alterado_em_1 THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: alterado_em nao foi renovado; anterior=%, atual=%.',
            v_alterado_em_1,
            v_alterado_em_2;
    END IF;

    RAISE NOTICE
        'VALIDACAO 043 OK: alterado_em renovado pelo banco em toda atualizacao.';

    UPDATE desenvolvimento.entrada_produto_lote
       SET status_lote = 'ENVIANDO_SAP',
           confirmado_em = clock_timestamp(),
           enviado_sap_em = clock_timestamp(),
           alterado_por = 'VALIDADOR_043'
     WHERE codigo_entrada_produto_lote = -430002;

    UPDATE desenvolvimento.entrada_produto_lote
       SET status_lote = 'ERRO_SAP',
           erro_sanitizado = 'ERRO CONTROLADO DE VALIDACAO',
           alterado_por = 'VALIDADOR_043'
     WHERE codigo_entrada_produto_lote = -430002;

    RAISE NOTICE
        'VALIDACAO 043 OK: atualizacoes de status SAP permitidas quando coerentes.';

    INSERT INTO desenvolvimento.entrada_produto_lote (
        codigo_entrada_produto_lote,
        codigo_entrada_produto_item,
        numero_lote,
        data_fabricacao,
        data_vencimento,
        status_lote,
        correlation_id,
        documento_material_sap,
        exercicio_documento_material_sap,
        documento_material_item,
        confirmado_em,
        enviado_sap_em,
        confirmado_sap_em,
        criado_por
    ) VALUES (
        -430010,
        v_item_2,
        'LT43010',
        DATE '2026-01-01',
        DATE '2027-01-01',
        'CONFIRMADO_SAP',
        '04300000-0000-0000-0000-000000000010'::uuid,
        '4900000043',
        '2026',
        '0001',
        clock_timestamp(),
        clock_timestamp(),
        clock_timestamp(),
        'VALIDADOR_043'
    );

    v_falhou := false;
    BEGIN
        UPDATE desenvolvimento.entrada_produto_lote
           SET status_lote = 'ERRO_SAP',
               erro_sanitizado = 'TENTATIVA DE REENVIO',
               alterado_por = 'VALIDADOR_043'
         WHERE codigo_entrada_produto_lote = -430010;
    EXCEPTION WHEN raise_exception THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: reenvio de CONFIRMADO_SAP foi permitido.';
    END IF;

    v_falhou := false;
    BEGIN
        INSERT INTO desenvolvimento.entrada_produto_lote (
            codigo_entrada_produto_lote,
            codigo_entrada_produto_item,
            numero_lote,
            data_fabricacao,
            data_vencimento,
            status_lote,
            correlation_id,
            documento_material_sap,
            exercicio_documento_material_sap,
            documento_material_item,
            confirmado_em,
            enviado_sap_em,
            confirmado_sap_em,
            criado_por
        ) VALUES (
            -430011,
            v_item_1,
            'LT43011',
            DATE '2026-01-01',
            DATE '2027-01-01',
            'CONFIRMADO_SAP',
            '04300000-0000-0000-0000-000000000011'::uuid,
            '4900000043',
            '2026',
            '0002',
            clock_timestamp(),
            clock_timestamp(),
            clock_timestamp(),
            'VALIDADOR_043'
        );
    EXCEPTION WHEN unique_violation THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: mesmo documento/ano com item SAP diferente foi aceito.';
    END IF;

    v_falhou := false;
    BEGIN
        DELETE FROM desenvolvimento.entrada_produto_lote
        WHERE codigo_entrada_produto_lote = -430001;
    EXCEPTION WHEN foreign_key_violation THEN
        v_falhou := true;
    END;
    IF NOT v_falhou THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: ON DELETE RESTRICT do lote foi ignorado.';
    END IF;

    RAISE NOTICE
        'VALIDACAO 043 OK: documento/ano unico mesmo com item SAP diferente.';
    RAISE NOTICE
        'VALIDACAO 043 OK: constraints, idempotencia, peso, alterado_em, imutabilidade, snapshots, grants e FKs validados.';
END $$;

ROLLBACK;

\echo 'VALIDACAO 043 - POS-ROLLBACK'

SELECT
    current_setting('fugapet_v043.lote_qtd_antes')::bigint AS lotes_antes,
    (SELECT count(*) FROM desenvolvimento.entrada_produto_lote) AS lotes_depois;

DO $$
DECLARE
    v_lote_hash_depois text;
    v_pesagem_hash_depois text;
    v_item_hash_depois text;
    v_lancamento_hash_depois text;
    v_lote_qtd_depois bigint;
BEGIN
    SELECT md5(COALESCE(
        string_agg(
            md5(row_to_json(t)::text),
            '' ORDER BY codigo_entrada_produto_lote
        ),
        ''
    ))
    INTO v_lote_hash_depois
    FROM desenvolvimento.entrada_produto_lote t;

    SELECT md5(COALESCE(
        string_agg(
            md5(row_to_json(t)::text),
            '' ORDER BY codigo_entrada_produto_pesagem
        ),
        ''
    ))
    INTO v_pesagem_hash_depois
    FROM desenvolvimento.entrada_produto_pesagem t;

    SELECT md5(COALESCE(
        string_agg(
            md5(row_to_json(t)::text),
            '' ORDER BY codigo_entrada_produto_item
        ),
        ''
    ))
    INTO v_item_hash_depois
    FROM desenvolvimento.entrada_produto_item t;

    SELECT md5(COALESCE(
        string_agg(
            md5(row_to_json(t)::text),
            '' ORDER BY codigo_entrada_produto_lancamento
        ),
        ''
    ))
    INTO v_lancamento_hash_depois
    FROM desenvolvimento.entrada_produto_lancamento t;

    SELECT count(*)
      INTO v_lote_qtd_depois
      FROM desenvolvimento.entrada_produto_lote;

    IF v_lote_hash_depois
           <> current_setting('fugapet_v043.lote_hash_antes')
       OR v_pesagem_hash_depois
           <> current_setting('fugapet_v043.pesagem_hash_antes')
       OR v_item_hash_depois
           <> current_setting('fugapet_v043.item_hash_antes')
       OR v_lancamento_hash_depois
           <> current_setting('fugapet_v043.lancamento_hash_antes')
       OR v_lote_qtd_depois
           <> current_setting('fugapet_v043.lote_qtd_antes')::bigint THEN
        RAISE EXCEPTION
            'VALIDACAO 043 REPROVADA: residuos ou alteracao historica detectados.';
    END IF;

    RAISE NOTICE
        'VALIDACAO 043 OK: rollback interno confirmado e zero residuos.';
END $$;

\echo 'OK - persistencia por lote 043 validada (DEV)'
