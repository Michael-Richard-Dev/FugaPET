\set ON_ERROR_STOP on
-- ============================================================================
-- 043_entrada_produto_lote_DEV_PROPOSTA_GAIA.sql
-- Projeto: FugaPET_Dev
-- Banco esperado: fuga_jales_local_desenvolvimento
-- Schema: desenvolvimento
--
-- Cria persistencia por lote para Entrada de Materia-Prima e Quimicos.
-- NAO insere lotes, rotas, permissoes de tela ou dados produtivos.
-- NAO altera registros historicos.
-- ============================================================================

SET search_path TO desenvolvimento, public;

BEGIN;
SET LOCAL lock_timeout = '10s';
SET LOCAL statement_timeout = '5min';

DO $$
DECLARE
    v_tabelas_base integer;
    v_colunas_novas integer;
    v_objetos_043 integer;
BEGIN
    IF current_database() <> 'fuga_jales_local_desenvolvimento' THEN
        RAISE EXCEPTION
            'PROPOSTA 043: banco incorreto: %. Esperado fuga_jales_local_desenvolvimento.',
            current_database();
    END IF;

    IF to_regnamespace('desenvolvimento') IS NULL THEN
        RAISE EXCEPTION
            'PROPOSTA 043: schema desenvolvimento inexistente.';
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM pg_roles
        WHERE rolname = 'fugapet_dev_app'
          AND rolsuper = false
    ) THEN
        RAISE EXCEPTION
            'PROPOSTA 043: papel fugapet_dev_app inexistente ou superusuario.';
    END IF;

    IF NOT has_database_privilege(
        'fugapet_dev_app',
        current_database(),
        'CONNECT'
    )
    OR NOT has_schema_privilege(
        'fugapet_dev_app',
        'desenvolvimento',
        'USAGE'
    ) THEN
        RAISE EXCEPTION
            'PROPOSTA 043: CONNECT ou USAGE ausente para fugapet_dev_app.';
    END IF;

    SELECT count(*)
      INTO v_tabelas_base
      FROM information_schema.tables
     WHERE table_schema = 'desenvolvimento'
       AND table_name IN (
           'entrada_produto_lancamento',
           'entrada_produto_item',
           'entrada_produto_pesagem'
       );

    IF v_tabelas_base <> 3 THEN
        RAISE EXCEPTION
            'PROPOSTA 043: tabelas base da Entrada incompativeis.';
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint c
        WHERE c.contype = 'f'
          AND c.conrelid =
              'desenvolvimento.entrada_produto_pesagem'::regclass
          AND c.confrelid =
              'desenvolvimento.entrada_produto_item'::regclass
          AND c.confdeltype = 'r'
    ) THEN
        RAISE EXCEPTION
            'PROPOSTA 043: FK pesagem -> item com ON DELETE RESTRICT ausente.';
    END IF;

    IF NOT has_table_privilege(
        'fugapet_dev_app',
        'desenvolvimento.entrada_produto_pesagem',
        'SELECT'
    )
    OR NOT has_table_privilege(
        'fugapet_dev_app',
        'desenvolvimento.entrada_produto_pesagem',
        'INSERT'
    )
    OR NOT has_table_privilege(
        'fugapet_dev_app',
        'desenvolvimento.entrada_produto_pesagem',
        'UPDATE'
    )
    OR has_table_privilege(
        'fugapet_dev_app',
        'desenvolvimento.entrada_produto_pesagem',
        'DELETE'
    ) THEN
        RAISE EXCEPTION
            'PROPOSTA 043: grants atuais da pesagem incompativeis.';
    END IF;

    SELECT count(*)
      INTO v_colunas_novas
      FROM information_schema.columns
     WHERE table_schema = 'desenvolvimento'
       AND table_name = 'entrada_produto_pesagem'
       AND column_name IN (
           'codigo_entrada_produto_lote',
           'numero_lote_snapshot',
           'data_fabricacao_snapshot',
           'data_vencimento_snapshot'
       );

    SELECT
        (CASE WHEN to_regclass(
            'desenvolvimento.entrada_produto_lote'
        ) IS NOT NULL THEN 1 ELSE 0 END)
        + v_colunas_novas
        + (
            SELECT count(*)
            FROM pg_proc p
            JOIN pg_namespace n ON n.oid = p.pronamespace
            WHERE n.nspname = 'desenvolvimento'
              AND p.proname IN (
                  'fn_entrada_produto_lote_proteger_update',
                  'fn_entrada_produto_pesagem_validar_lote_snapshot',
                  'fn_entrada_produto_lote_recalcular_peso',
                  'fn_entrada_produto_pesagem_recalcular_lote'
              )
        )
        + (
            SELECT count(*)
            FROM pg_trigger t
            WHERE NOT t.tgisinternal
              AND t.tgname IN (
                  'trg_entrada_produto_lote_proteger_update',
                  'trg_entrada_produto_pesagem_validar_lote',
                  'trg_entrada_produto_pesagem_recalcular_lote'
              )
        )
    INTO v_objetos_043;

    IF v_objetos_043 <> 0 THEN
        RAISE EXCEPTION
            'PROPOSTA 043: PACOTE_PARCIAL_INCOMPATIVEL ou ja aplicado; objetos encontrados=%.
             Nao repetir automaticamente.',
            v_objetos_043;
    END IF;

    RAISE NOTICE
        'PROPOSTA 043 PRECHECK OK: base compativel e pacote nao aplicado.';
END $$;

CREATE TABLE desenvolvimento.entrada_produto_lote (
    codigo_entrada_produto_lote bigint
        GENERATED BY DEFAULT AS IDENTITY,
    codigo_entrada_produto_item bigint NOT NULL,
    numero_lote character varying(10) NOT NULL,
    data_fabricacao date NOT NULL,
    data_vencimento date NOT NULL,
    peso_liquido_total_kg numeric(14,3) NOT NULL DEFAULT 0,
    status_lote character varying(30) NOT NULL DEFAULT 'AGUARDANDO_DADOS',
    correlation_id uuid NOT NULL,
    documento_material_sap character varying(20),
    exercicio_documento_material_sap character varying(4),
    documento_material_item character varying(10),
    batch_retornado_sap character varying(10),
    quantidade_retorno_sap numeric(14,3),
    payload_enviado_json jsonb,
    resposta_sap_json jsonb,
    erro_sanitizado text,
    criado_em timestamp with time zone NOT NULL DEFAULT clock_timestamp(),
    criado_por character varying(80) NOT NULL,
    confirmado_em timestamp with time zone,
    enviado_sap_em timestamp with time zone,
    confirmado_sap_em timestamp with time zone,
    alterado_em timestamp with time zone,
    alterado_por character varying(80),

    CONSTRAINT pk_entrada_produto_lote
        PRIMARY KEY (codigo_entrada_produto_lote),

    CONSTRAINT fk_entrada_lote_item
        FOREIGN KEY (codigo_entrada_produto_item)
        REFERENCES desenvolvimento.entrada_produto_item (
            codigo_entrada_produto_item
        )
        ON DELETE RESTRICT,

    CONSTRAINT uq_entrada_lote_correlation_id
        UNIQUE (correlation_id),

    CONSTRAINT ck_entrada_lote_numero_nao_vazio
        CHECK (length(btrim(numero_lote)) > 0),

    CONSTRAINT ck_entrada_lote_datas
        CHECK (data_vencimento >= data_fabricacao),

    CONSTRAINT ck_entrada_lote_peso_total
        CHECK (peso_liquido_total_kg >= 0),

    CONSTRAINT ck_entrada_lote_status
        CHECK (
            status_lote IN (
                'AGUARDANDO_DADOS',
                'LOTE_CONFIRMADO',
                'PESANDO',
                'FINALIZADO_LOCAL',
                'ENVIANDO_SAP',
                'CONFIRMADO_SAP',
                'ERRO_SAP',
                'CANCELADO'
            )
        ),

    CONSTRAINT ck_entrada_lote_documento_conjunto
        CHECK (
            (
                documento_material_sap IS NULL
                AND exercicio_documento_material_sap IS NULL
                AND documento_material_item IS NULL
            )
            OR
            (
                documento_material_sap IS NOT NULL
                AND length(btrim(documento_material_sap)) > 0
                AND exercicio_documento_material_sap IS NOT NULL
                AND exercicio_documento_material_sap ~ '^[0-9]{4}$'
                AND documento_material_item IS NOT NULL
                AND length(btrim(documento_material_item)) > 0
            )
        ),

    CONSTRAINT ck_entrada_lote_confirmado_sap_documento
        CHECK (
            status_lote <> 'CONFIRMADO_SAP'
            OR (
                documento_material_sap IS NOT NULL
                AND exercicio_documento_material_sap IS NOT NULL
                AND documento_material_item IS NOT NULL
                AND confirmado_sap_em IS NOT NULL
            )
        ),

    CONSTRAINT ck_entrada_lote_erro_sap
        CHECK (
            status_lote <> 'ERRO_SAP'
            OR length(btrim(COALESCE(erro_sanitizado, ''))) > 0
        ),

    CONSTRAINT ck_entrada_lote_quantidade_retorno
        CHECK (
            quantidade_retorno_sap IS NULL
            OR quantidade_retorno_sap >= 0
        ),

    CONSTRAINT ck_entrada_lote_criado_por
        CHECK (length(btrim(criado_por)) > 0),

    CONSTRAINT ck_entrada_lote_alterado_por
        CHECK (
            alterado_por IS NULL
            OR length(btrim(alterado_por)) > 0
        ),

    CONSTRAINT ck_entrada_lote_enviado_em
        CHECK (
            status_lote NOT IN ('ENVIANDO_SAP', 'CONFIRMADO_SAP')
            OR enviado_sap_em IS NOT NULL
        ),

    CONSTRAINT ck_entrada_lote_confirmado_em
        CHECK (
            status_lote = 'AGUARDANDO_DADOS'
            OR status_lote = 'CANCELADO'
            OR confirmado_em IS NOT NULL
        ),

    CONSTRAINT ck_entrada_lote_payload_sem_credencial
        CHECK (
            payload_enviado_json IS NULL
            OR lower(payload_enviado_json::text) !~
                '"(authorization|password|senha|token|connectionstring|connection_string|clientsecret|client_secret)"[[:space:]]*:'
        )
);

CREATE UNIQUE INDEX uq_entrada_lote_ativo_item_lote_datas
    ON desenvolvimento.entrada_produto_lote (
        codigo_entrada_produto_item,
        upper(btrim(numero_lote)),
        data_fabricacao,
        data_vencimento
    )
    WHERE status_lote <> 'CANCELADO';

CREATE UNIQUE INDEX uq_entrada_lote_documento_confirmado
    ON desenvolvimento.entrada_produto_lote (
        documento_material_sap,
        exercicio_documento_material_sap
    )
    WHERE status_lote = 'CONFIRMADO_SAP';

CREATE INDEX ix_entrada_lote_item
    ON desenvolvimento.entrada_produto_lote (
        codigo_entrada_produto_item
    );

CREATE INDEX ix_entrada_lote_status
    ON desenvolvimento.entrada_produto_lote (
        status_lote,
        criado_em DESC
    );

CREATE INDEX ix_entrada_lote_numero
    ON desenvolvimento.entrada_produto_lote (
        upper(btrim(numero_lote))
    );

CREATE INDEX ix_entrada_lote_pendente_envio
    ON desenvolvimento.entrada_produto_lote (
        criado_em,
        codigo_entrada_produto_lote
    )
    WHERE status_lote IN ('FINALIZADO_LOCAL', 'ERRO_SAP');

CREATE INDEX ix_entrada_lote_erro_sap
    ON desenvolvimento.entrada_produto_lote (
        alterado_em DESC NULLS LAST,
        codigo_entrada_produto_lote
    )
    WHERE status_lote = 'ERRO_SAP';

ALTER TABLE desenvolvimento.entrada_produto_pesagem
    ADD COLUMN codigo_entrada_produto_lote bigint,
    ADD COLUMN numero_lote_snapshot character varying(10),
    ADD COLUMN data_fabricacao_snapshot date,
    ADD COLUMN data_vencimento_snapshot date;

ALTER TABLE desenvolvimento.entrada_produto_pesagem
    ADD CONSTRAINT fk_entrada_pesagem_lote
        FOREIGN KEY (codigo_entrada_produto_lote)
        REFERENCES desenvolvimento.entrada_produto_lote (
            codigo_entrada_produto_lote
        )
        ON DELETE RESTRICT
        NOT VALID;

ALTER TABLE desenvolvimento.entrada_produto_pesagem
    VALIDATE CONSTRAINT fk_entrada_pesagem_lote;

ALTER TABLE desenvolvimento.entrada_produto_pesagem
    ADD CONSTRAINT ck_entrada_pesagem_lote_snapshot_conjunto
        CHECK (
            (
                codigo_entrada_produto_lote IS NULL
                AND numero_lote_snapshot IS NULL
                AND data_fabricacao_snapshot IS NULL
                AND data_vencimento_snapshot IS NULL
            )
            OR
            (
                codigo_entrada_produto_lote IS NOT NULL
                AND numero_lote_snapshot IS NOT NULL
                AND length(btrim(numero_lote_snapshot)) > 0
                AND data_fabricacao_snapshot IS NOT NULL
                AND data_vencimento_snapshot IS NOT NULL
                AND data_vencimento_snapshot >= data_fabricacao_snapshot
            )
        )
        NOT VALID;

ALTER TABLE desenvolvimento.entrada_produto_pesagem
    VALIDATE CONSTRAINT ck_entrada_pesagem_lote_snapshot_conjunto;

CREATE INDEX ix_entrada_pesagem_lote
    ON desenvolvimento.entrada_produto_pesagem (
        codigo_entrada_produto_lote
    )
    WHERE codigo_entrada_produto_lote IS NOT NULL;

CREATE FUNCTION desenvolvimento.fn_entrada_produto_lote_proteger_update()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = desenvolvimento, pg_temp
AS $$
DECLARE
    v_pesagens_ativas bigint;
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW.peso_liquido_total_kg IS DISTINCT FROM 0::numeric THEN
            RAISE EXCEPTION
                'entrada_produto_lote: peso_liquido_total_kg deve ser zero no INSERT; a pesagem e a fonte da verdade.';
        END IF;

        RETURN NEW;
    END IF;

    IF NEW.codigo_entrada_produto_lote
       IS DISTINCT FROM OLD.codigo_entrada_produto_lote THEN
        RAISE EXCEPTION
            'entrada_produto_lote: codigo_entrada_produto_lote e imutavel.';
    END IF;

    IF NEW.correlation_id IS DISTINCT FROM OLD.correlation_id THEN
        RAISE EXCEPTION
            'entrada_produto_lote: correlation_id e imutavel.';
    END IF;

    IF NEW.criado_em IS DISTINCT FROM OLD.criado_em
       OR NEW.criado_por IS DISTINCT FROM OLD.criado_por THEN
        RAISE EXCEPTION
            'entrada_produto_lote: campos de criacao sao imutaveis.';
    END IF;

    SELECT count(*)
      INTO v_pesagens_ativas
      FROM desenvolvimento.entrada_produto_pesagem p
     WHERE p.codigo_entrada_produto_lote =
           OLD.codigo_entrada_produto_lote
       AND p.situacao_entrada_produto_pesagem = true;

    IF v_pesagens_ativas > 0
       AND (
           NEW.codigo_entrada_produto_item
               IS DISTINCT FROM OLD.codigo_entrada_produto_item
           OR NEW.numero_lote
               IS DISTINCT FROM OLD.numero_lote
           OR NEW.data_fabricacao
               IS DISTINCT FROM OLD.data_fabricacao
           OR NEW.data_vencimento
               IS DISTINCT FROM OLD.data_vencimento
       ) THEN
        RAISE EXCEPTION
            'entrada_produto_lote: item, lote e datas nao podem ser alterados apos a primeira pesagem ativa.';
    END IF;

    IF NEW.peso_liquido_total_kg
       IS DISTINCT FROM OLD.peso_liquido_total_kg
       AND pg_trigger_depth() <= 1 THEN
        RAISE EXCEPTION
            'entrada_produto_lote: peso total e mantido exclusivamente pela trigger interna de consolidacao das pesagens.';
    END IF;

    IF OLD.status_lote IN ('ENVIANDO_SAP', 'CONFIRMADO_SAP')
       AND NEW.peso_liquido_total_kg
           IS DISTINCT FROM OLD.peso_liquido_total_kg THEN
        RAISE EXCEPTION
            'entrada_produto_lote: peso nao pode mudar apos inicio do envio SAP.';
    END IF;

    IF OLD.status_lote = 'CONFIRMADO_SAP' THEN
        IF NEW.status_lote <> 'CONFIRMADO_SAP'
           OR NEW.codigo_entrada_produto_item
               IS DISTINCT FROM OLD.codigo_entrada_produto_item
           OR NEW.numero_lote
               IS DISTINCT FROM OLD.numero_lote
           OR NEW.data_fabricacao
               IS DISTINCT FROM OLD.data_fabricacao
           OR NEW.data_vencimento
               IS DISTINCT FROM OLD.data_vencimento
           OR NEW.documento_material_sap
               IS DISTINCT FROM OLD.documento_material_sap
           OR NEW.exercicio_documento_material_sap
               IS DISTINCT FROM OLD.exercicio_documento_material_sap
           OR NEW.documento_material_item
               IS DISTINCT FROM OLD.documento_material_item
           OR NEW.batch_retornado_sap
               IS DISTINCT FROM OLD.batch_retornado_sap
           OR NEW.quantidade_retorno_sap
               IS DISTINCT FROM OLD.quantidade_retorno_sap
           OR NEW.payload_enviado_json
               IS DISTINCT FROM OLD.payload_enviado_json
           OR NEW.resposta_sap_json
               IS DISTINCT FROM OLD.resposta_sap_json
           OR NEW.confirmado_sap_em
               IS DISTINCT FROM OLD.confirmado_sap_em THEN
            RAISE EXCEPTION
                'entrada_produto_lote: lote CONFIRMADO_SAP e imutavel para reenvio e dados SAP.';
        END IF;
    END IF;

    NEW.alterado_em := clock_timestamp();

    RETURN NEW;
END $$;

CREATE FUNCTION desenvolvimento.fn_entrada_produto_pesagem_validar_lote_snapshot()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = desenvolvimento, pg_temp
AS $$
DECLARE
    v_lote desenvolvimento.entrada_produto_lote%ROWTYPE;
    v_status_antigo character varying(30);
BEGIN
    IF TG_OP = 'DELETE' THEN
        IF OLD.codigo_entrada_produto_lote IS NOT NULL THEN
            SELECT status_lote
              INTO v_status_antigo
              FROM desenvolvimento.entrada_produto_lote
             WHERE codigo_entrada_produto_lote =
                   OLD.codigo_entrada_produto_lote;

            IF v_status_antigo IN ('ENVIANDO_SAP', 'CONFIRMADO_SAP') THEN
                RAISE EXCEPTION
                    'entrada_produto_pesagem: exclusao bloqueada para lote em envio ou confirmado SAP.';
            END IF;
        END IF;

        RETURN OLD;
    END IF;

    IF NEW.codigo_entrada_produto_lote IS NULL THEN
        IF NEW.numero_lote_snapshot IS NOT NULL
           OR NEW.data_fabricacao_snapshot IS NOT NULL
           OR NEW.data_vencimento_snapshot IS NOT NULL THEN
            RAISE EXCEPTION
                'entrada_produto_pesagem: snapshots exigem codigo_entrada_produto_lote.';
        END IF;

        RETURN NEW;
    END IF;

    SELECT *
      INTO v_lote
      FROM desenvolvimento.entrada_produto_lote
     WHERE codigo_entrada_produto_lote =
           NEW.codigo_entrada_produto_lote;

    IF NOT FOUND THEN
        RAISE EXCEPTION
            'entrada_produto_pesagem: lote % inexistente.',
            NEW.codigo_entrada_produto_lote;
    END IF;

    IF v_lote.codigo_entrada_produto_item
       <> NEW.codigo_entrada_produto_item THEN
        RAISE EXCEPTION
            'entrada_produto_pesagem: lote pertence a outro item de entrada.';
    END IF;

    IF NEW.numero_lote_snapshot IS NULL
       OR NEW.data_fabricacao_snapshot IS NULL
       OR NEW.data_vencimento_snapshot IS NULL THEN
        RAISE EXCEPTION
            'entrada_produto_pesagem: snapshots completos sao obrigatorios no fluxo por lote.';
    END IF;

    IF btrim(NEW.numero_lote_snapshot) <> btrim(v_lote.numero_lote)
       OR NEW.data_fabricacao_snapshot <> v_lote.data_fabricacao
       OR NEW.data_vencimento_snapshot <> v_lote.data_vencimento THEN
        RAISE EXCEPTION
            'entrada_produto_pesagem: snapshots divergem do lote referenciado.';
    END IF;

    IF TG_OP = 'UPDATE'
       AND OLD.codigo_entrada_produto_lote IS NOT NULL
       AND (
           NEW.codigo_entrada_produto_lote
               IS DISTINCT FROM OLD.codigo_entrada_produto_lote
           OR NEW.numero_lote_snapshot
               IS DISTINCT FROM OLD.numero_lote_snapshot
           OR NEW.data_fabricacao_snapshot
               IS DISTINCT FROM OLD.data_fabricacao_snapshot
           OR NEW.data_vencimento_snapshot
               IS DISTINCT FROM OLD.data_vencimento_snapshot
       ) THEN
        RAISE EXCEPTION
            'entrada_produto_pesagem: vinculo e snapshots de lote sao imutaveis.';
    END IF;

    IF v_lote.status_lote IN ('ENVIANDO_SAP', 'CONFIRMADO_SAP') THEN
        IF TG_OP = 'INSERT'
           OR (
               TG_OP = 'UPDATE'
               AND (
                   NEW.peso_liquido_kg
                       IS DISTINCT FROM OLD.peso_liquido_kg
                   OR NEW.status_pesagem
                       IS DISTINCT FROM OLD.status_pesagem
                   OR NEW.situacao_entrada_produto_pesagem
                       IS DISTINCT FROM OLD.situacao_entrada_produto_pesagem
                   OR NEW.codigo_entrada_produto_lote
                       IS DISTINCT FROM OLD.codigo_entrada_produto_lote
                   OR NEW.numero_lote_snapshot
                       IS DISTINCT FROM OLD.numero_lote_snapshot
                   OR NEW.data_fabricacao_snapshot
                       IS DISTINCT FROM OLD.data_fabricacao_snapshot
                   OR NEW.data_vencimento_snapshot
                       IS DISTINCT FROM OLD.data_vencimento_snapshot
               )
           ) THEN
            RAISE EXCEPTION
                'entrada_produto_pesagem: alteracao operacional bloqueada para lote em envio ou confirmado SAP.';
        END IF;
    END IF;

    RETURN NEW;
END $$;

CREATE FUNCTION desenvolvimento.fn_entrada_produto_lote_recalcular_peso(
    p_codigo_entrada_produto_lote bigint
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = desenvolvimento, pg_temp
AS $$
BEGIN
    IF p_codigo_entrada_produto_lote IS NULL THEN
        RETURN;
    END IF;

    UPDATE desenvolvimento.entrada_produto_lote l
       SET peso_liquido_total_kg = COALESCE(
               (
                   SELECT sum(p.peso_liquido_kg)
                   FROM desenvolvimento.entrada_produto_pesagem p
                   WHERE p.codigo_entrada_produto_lote =
                         p_codigo_entrada_produto_lote
                     AND p.situacao_entrada_produto_pesagem = true
                     AND p.status_pesagem = 'VALIDA'
               ),
               0
           )::numeric(14,3),
           alterado_em = clock_timestamp(),
           alterado_por = 'TRIGGER_PESO_LOTE'
     WHERE l.codigo_entrada_produto_lote =
           p_codigo_entrada_produto_lote;
END $$;

CREATE FUNCTION desenvolvimento.fn_entrada_produto_pesagem_recalcular_lote()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = desenvolvimento, pg_temp
AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        PERFORM desenvolvimento.fn_entrada_produto_lote_recalcular_peso(
            NEW.codigo_entrada_produto_lote
        );
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        PERFORM desenvolvimento.fn_entrada_produto_lote_recalcular_peso(
            OLD.codigo_entrada_produto_lote
        );
        RETURN OLD;
    END IF;

    IF NEW.codigo_entrada_produto_lote
       IS DISTINCT FROM OLD.codigo_entrada_produto_lote THEN
        PERFORM desenvolvimento.fn_entrada_produto_lote_recalcular_peso(
            OLD.codigo_entrada_produto_lote
        );
        PERFORM desenvolvimento.fn_entrada_produto_lote_recalcular_peso(
            NEW.codigo_entrada_produto_lote
        );
    ELSE
        PERFORM desenvolvimento.fn_entrada_produto_lote_recalcular_peso(
            NEW.codigo_entrada_produto_lote
        );
    END IF;

    RETURN NEW;
END $$;

REVOKE ALL
ON FUNCTION desenvolvimento.fn_entrada_produto_lote_proteger_update()
FROM PUBLIC;

REVOKE ALL
ON FUNCTION desenvolvimento.fn_entrada_produto_pesagem_validar_lote_snapshot()
FROM PUBLIC;

REVOKE ALL
ON FUNCTION desenvolvimento.fn_entrada_produto_lote_recalcular_peso(bigint)
FROM PUBLIC;

REVOKE ALL
ON FUNCTION desenvolvimento.fn_entrada_produto_pesagem_recalcular_lote()
FROM PUBLIC;

CREATE TRIGGER trg_entrada_produto_lote_proteger_update
BEFORE INSERT OR UPDATE
ON desenvolvimento.entrada_produto_lote
FOR EACH ROW
EXECUTE FUNCTION desenvolvimento.fn_entrada_produto_lote_proteger_update();

CREATE TRIGGER trg_entrada_produto_pesagem_validar_lote
BEFORE INSERT OR UPDATE OR DELETE
ON desenvolvimento.entrada_produto_pesagem
FOR EACH ROW
EXECUTE FUNCTION desenvolvimento.fn_entrada_produto_pesagem_validar_lote_snapshot();

CREATE TRIGGER trg_entrada_produto_pesagem_recalcular_lote
AFTER INSERT OR DELETE OR UPDATE OF
    codigo_entrada_produto_lote,
    peso_liquido_kg,
    status_pesagem,
    situacao_entrada_produto_pesagem
ON desenvolvimento.entrada_produto_pesagem
FOR EACH ROW
EXECUTE FUNCTION desenvolvimento.fn_entrada_produto_pesagem_recalcular_lote();

GRANT SELECT, INSERT, UPDATE
ON TABLE desenvolvimento.entrada_produto_lote
TO fugapet_dev_app;

REVOKE DELETE, TRUNCATE, REFERENCES, TRIGGER
ON TABLE desenvolvimento.entrada_produto_lote
FROM fugapet_dev_app;

GRANT SELECT, INSERT, UPDATE
ON TABLE desenvolvimento.entrada_produto_pesagem
TO fugapet_dev_app;

REVOKE DELETE, TRUNCATE
ON TABLE desenvolvimento.entrada_produto_pesagem
FROM fugapet_dev_app;

GRANT USAGE, SELECT
ON SEQUENCE desenvolvimento.entrada_produto_lote_codigo_entrada_produto_lote_seq
TO fugapet_dev_app;

REVOKE UPDATE
ON SEQUENCE desenvolvimento.entrada_produto_lote_codigo_entrada_produto_lote_seq
FROM fugapet_dev_app;

DO $$
DECLARE
    v_colunas_lote integer;
    v_colunas_pesagem integer;
    v_constraints_lote integer;
    v_constraints_pesagem integer;
    v_indices integer;
    v_triggers integer;
    v_funcoes integer;
BEGIN
    SELECT count(*) INTO v_colunas_lote
    FROM information_schema.columns
    WHERE table_schema = 'desenvolvimento'
      AND table_name = 'entrada_produto_lote';

    SELECT count(*) INTO v_colunas_pesagem
    FROM information_schema.columns
    WHERE table_schema = 'desenvolvimento'
      AND table_name = 'entrada_produto_pesagem'
      AND column_name IN (
          'codigo_entrada_produto_lote',
          'numero_lote_snapshot',
          'data_fabricacao_snapshot',
          'data_vencimento_snapshot'
      );

    SELECT count(*) INTO v_constraints_lote
    FROM pg_constraint
    WHERE conrelid =
          'desenvolvimento.entrada_produto_lote'::regclass
      AND conname IN (
          'pk_entrada_produto_lote',
          'fk_entrada_lote_item',
          'uq_entrada_lote_correlation_id',
          'ck_entrada_lote_numero_nao_vazio',
          'ck_entrada_lote_datas',
          'ck_entrada_lote_peso_total',
          'ck_entrada_lote_status',
          'ck_entrada_lote_documento_conjunto',
          'ck_entrada_lote_confirmado_sap_documento',
          'ck_entrada_lote_erro_sap',
          'ck_entrada_lote_quantidade_retorno',
          'ck_entrada_lote_criado_por',
          'ck_entrada_lote_alterado_por',
          'ck_entrada_lote_enviado_em',
          'ck_entrada_lote_confirmado_em',
          'ck_entrada_lote_payload_sem_credencial'
      );

    SELECT count(*) INTO v_constraints_pesagem
    FROM pg_constraint
    WHERE conrelid =
          'desenvolvimento.entrada_produto_pesagem'::regclass
      AND conname IN (
          'fk_entrada_pesagem_lote',
          'ck_entrada_pesagem_lote_snapshot_conjunto'
      );

    SELECT count(*) INTO v_indices
    FROM pg_indexes
    WHERE schemaname = 'desenvolvimento'
      AND indexname IN (
          'uq_entrada_lote_ativo_item_lote_datas',
          'uq_entrada_lote_documento_confirmado',
          'ix_entrada_lote_item',
          'ix_entrada_lote_status',
          'ix_entrada_lote_numero',
          'ix_entrada_lote_pendente_envio',
          'ix_entrada_lote_erro_sap',
          'ix_entrada_pesagem_lote'
      );

    SELECT count(*) INTO v_triggers
    FROM pg_trigger
    WHERE NOT tgisinternal
      AND tgname IN (
          'trg_entrada_produto_lote_proteger_update',
          'trg_entrada_produto_pesagem_validar_lote',
          'trg_entrada_produto_pesagem_recalcular_lote'
      );

    SELECT count(*) INTO v_funcoes
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'desenvolvimento'
      AND p.proname IN (
          'fn_entrada_produto_lote_proteger_update',
          'fn_entrada_produto_pesagem_validar_lote_snapshot',
          'fn_entrada_produto_lote_recalcular_peso',
          'fn_entrada_produto_pesagem_recalcular_lote'
      );

    IF v_colunas_lote <> 23
       OR v_colunas_pesagem <> 4
       OR v_constraints_lote <> 16
       OR v_constraints_pesagem <> 2
       OR v_indices <> 8
       OR v_triggers <> 3
       OR v_funcoes <> 4 THEN
        RAISE EXCEPTION
            'PROPOSTA 043 POSTCHECK REPROVADO: colunas_lote=%, colunas_pesagem=%, constraints_lote=%, constraints_pesagem=%, indices=%, triggers=%, funcoes=%.',
            v_colunas_lote,
            v_colunas_pesagem,
            v_constraints_lote,
            v_constraints_pesagem,
            v_indices,
            v_triggers,
            v_funcoes;
    END IF;

    IF NOT has_table_privilege(
        'fugapet_dev_app',
        'desenvolvimento.entrada_produto_lote',
        'SELECT'
    )
    OR NOT has_table_privilege(
        'fugapet_dev_app',
        'desenvolvimento.entrada_produto_lote',
        'INSERT'
    )
    OR NOT has_table_privilege(
        'fugapet_dev_app',
        'desenvolvimento.entrada_produto_lote',
        'UPDATE'
    )
    OR has_table_privilege(
        'fugapet_dev_app',
        'desenvolvimento.entrada_produto_lote',
        'DELETE'
    ) THEN
        RAISE EXCEPTION
            'PROPOSTA 043 POSTCHECK REPROVADO: grants da tabela de lote.';
    END IF;

    IF (
        SELECT count(*)
        FROM desenvolvimento.entrada_produto_lote
    ) <> 0 THEN
        RAISE EXCEPTION
            'PROPOSTA 043 POSTCHECK REPROVADO: lote inserido indevidamente.';
    END IF;

    RAISE NOTICE
        'PROPOSTA 043 OK: estrutura por lote criada sem inserir dados ou alterar historico.';
END $$;

COMMIT;

\echo 'OK - APLICACAO 043 DEV concluida'
