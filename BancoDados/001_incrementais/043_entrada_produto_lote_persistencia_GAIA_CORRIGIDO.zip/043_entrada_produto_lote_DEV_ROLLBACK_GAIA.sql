\set ON_ERROR_STOP on
-- ============================================================================
-- 043_entrada_produto_lote_DEV_ROLLBACK_GAIA.sql
-- ROLLBACK OFICIAL, SEPARADO E NUNCA AUTOMATICO.
--
-- Exige:
--   -v CONFIRMAR_ROLLBACK_043=EU_CONFIRMO_ROLLBACK_043_DEV
--
-- Bloqueia quando houver qualquer lote registrado ou pesagem vinculada.
-- NAO apaga lancamentos, itens ou pesagens historicas.
-- NAO toca em HML/PRD nem em integracoes anteriores.
-- ============================================================================

\if :{?CONFIRMAR_ROLLBACK_043}
\else
    \echo 'ROLLBACK 043 BLOQUEADO: informe -v CONFIRMAR_ROLLBACK_043=EU_CONFIRMO_ROLLBACK_043_DEV'
    \quit 43
\endif

SELECT
    :'CONFIRMAR_ROLLBACK_043' =
    'EU_CONFIRMO_ROLLBACK_043_DEV' AS confirmacao_ok
\gset

\if :confirmacao_ok
\else
    \echo 'ROLLBACK 043 BLOQUEADO: confirmacao explicita incorreta.'
    \quit 44
\endif

SET search_path TO desenvolvimento, public;

BEGIN;
SET LOCAL lock_timeout = '10s';
SET LOCAL statement_timeout = '5min';

DO $$
DECLARE
    v_tabela_lote integer;
    v_colunas_pesagem integer;
    v_lotes bigint;
    v_pesagens_vinculadas bigint;
BEGIN
    IF current_database() <> 'fuga_jales_local_desenvolvimento' THEN
        RAISE EXCEPTION
            'ROLLBACK 043: banco incorreto: %. Esperado fuga_jales_local_desenvolvimento.',
            current_database();
    END IF;

    SELECT count(*)
      INTO v_tabela_lote
      FROM information_schema.tables
     WHERE table_schema = 'desenvolvimento'
       AND table_name = 'entrada_produto_lote';

    SELECT count(*)
      INTO v_colunas_pesagem
      FROM information_schema.columns
     WHERE table_schema = 'desenvolvimento'
       AND table_name = 'entrada_produto_pesagem'
       AND column_name IN (
           'codigo_entrada_produto_lote',
           'numero_lote_snapshot',
           'data_fabricacao_snapshot',
           'data_vencimento_snapshot'
       );

    IF v_tabela_lote <> 1 OR v_colunas_pesagem <> 4 THEN
        RAISE EXCEPTION
            'ROLLBACK 043 BLOQUEADO: estrutura parcial ou incompativel; tabela_lote=%, colunas_pesagem=%/4.',
            v_tabela_lote,
            v_colunas_pesagem;
    END IF;

    SELECT count(*)
      INTO v_lotes
      FROM desenvolvimento.entrada_produto_lote;

    SELECT count(*)
      INTO v_pesagens_vinculadas
      FROM desenvolvimento.entrada_produto_pesagem
     WHERE codigo_entrada_produto_lote IS NOT NULL
        OR numero_lote_snapshot IS NOT NULL
        OR data_fabricacao_snapshot IS NOT NULL
        OR data_vencimento_snapshot IS NOT NULL;

    IF v_lotes <> 0 OR v_pesagens_vinculadas <> 0 THEN
        RAISE EXCEPTION
            'ROLLBACK 043 BLOQUEADO: lotes=% e pesagens vinculadas/snapshot=%.
             O rollback nao apaga dados produtivos.',
            v_lotes,
            v_pesagens_vinculadas;
    END IF;

    RAISE NOTICE
        'ROLLBACK 043 PRECHECK OK: sem lotes e sem pesagens vinculadas.';
END $$;

DROP TRIGGER trg_entrada_produto_pesagem_recalcular_lote
ON desenvolvimento.entrada_produto_pesagem;

DROP TRIGGER trg_entrada_produto_pesagem_validar_lote
ON desenvolvimento.entrada_produto_pesagem;

DROP TRIGGER trg_entrada_produto_lote_proteger_update
ON desenvolvimento.entrada_produto_lote;

DROP INDEX desenvolvimento.ix_entrada_pesagem_lote;

ALTER TABLE desenvolvimento.entrada_produto_pesagem
    DROP CONSTRAINT ck_entrada_pesagem_lote_snapshot_conjunto;

ALTER TABLE desenvolvimento.entrada_produto_pesagem
    DROP CONSTRAINT fk_entrada_pesagem_lote;

ALTER TABLE desenvolvimento.entrada_produto_pesagem
    DROP COLUMN data_vencimento_snapshot,
    DROP COLUMN data_fabricacao_snapshot,
    DROP COLUMN numero_lote_snapshot,
    DROP COLUMN codigo_entrada_produto_lote;

DROP FUNCTION desenvolvimento.fn_entrada_produto_pesagem_recalcular_lote();
DROP FUNCTION desenvolvimento.fn_entrada_produto_lote_recalcular_peso(bigint);
DROP FUNCTION desenvolvimento.fn_entrada_produto_pesagem_validar_lote_snapshot();
DROP FUNCTION desenvolvimento.fn_entrada_produto_lote_proteger_update();

DROP TABLE desenvolvimento.entrada_produto_lote;

DO $$
BEGIN
    IF to_regclass('desenvolvimento.entrada_produto_lote') IS NOT NULL THEN
        RAISE EXCEPTION
            'ROLLBACK 043 POSTCHECK: entrada_produto_lote ainda existe.';
    END IF;

    IF EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = 'desenvolvimento'
          AND table_name = 'entrada_produto_pesagem'
          AND column_name IN (
              'codigo_entrada_produto_lote',
              'numero_lote_snapshot',
              'data_fabricacao_snapshot',
              'data_vencimento_snapshot'
          )
    ) THEN
        RAISE EXCEPTION
            'ROLLBACK 043 POSTCHECK: colunas 043 ainda existem na pesagem.';
    END IF;

    IF to_regclass('desenvolvimento.entrada_produto_lancamento') IS NULL
       OR to_regclass('desenvolvimento.entrada_produto_item') IS NULL
       OR to_regclass('desenvolvimento.entrada_produto_pesagem') IS NULL THEN
        RAISE EXCEPTION
            'ROLLBACK 043 POSTCHECK: tabelas historicas da Entrada foram afetadas.';
    END IF;

    RAISE NOTICE
        'ROLLBACK 043 OK: somente objetos do incremental 043 removidos.';
END $$;

COMMIT;

\echo 'OK - ROLLBACK 043 DEV concluido'
